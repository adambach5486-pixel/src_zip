// ---
// ---
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "vVectorCG.h"
#include "vModelBufferController.h"

#include "vDisplayController.h"
#include "vDisplayController_001.h"
#include "vModelBufferController.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"
#include "jackson_animation_focus_003_02.h"
#include "jackson_animation_focus_003_03.h"
#include "jackson_animation_focus_003_04.h"

int Spin_Eye_thin_axex_bones_one_step ();

// 20250822
int Spin_Eye_thin_axex_bones_one_step () {
	int a;
	static int initialized = -1;
	vPoint* up = nullptr;
	printf("int Spin_Eye_thin_axex_bones () starts.\r\n");

	printf("initialized %d\r\n", initialized);

	if ( initialized == -1 ) {
		initialized = Initialize_Spin_Eye_thin_axex_bones ();
		initialized = 1;
	} else {
		a = Spin_Eye_thin_axex_bones_sub_level_002 ();
		a = Calculate_Screen_UV_sub_level_002 ();
	}
	up = memorizevPoint(0.0f, 1.0f, 0.0f);
	display_006_01.put_Up ( *up );
	display_006_01.Set_HowFarFromEye ( 320.0f );
	display_006_01.ConvertionBonesOntheFace ();
	a = Organize_Axex_Bones (1);

	printf("int Spin_Eye_thin_axex_bones () ends.\r\n");
	return 1;
}

