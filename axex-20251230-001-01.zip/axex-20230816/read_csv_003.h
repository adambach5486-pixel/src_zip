#ifndef _SETTLE_GRID_003_H_
#define _SETTLE_GRID_003_H_

extern int endline_003 ( char bc, char c) ;

#endif
