#ifndef _PARAM_SYNSE_H_
#define _PARAM_SYNSE_H_

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

//
#include "wTextarea.h"
#include "wTextareaController.h"

class ParamSynse_003 {

	public:
		wTextarea** box_param = nullptr;
		int box_param_num = 42;

	private:
		wTextarea textarea1;

	public:
		ParamSynse_003();

	private:
		int Initialization ();
		int Initialization_001 ();
		int Initialization_002 ();
} ;

#endif

