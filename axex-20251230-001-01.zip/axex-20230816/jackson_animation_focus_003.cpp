#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "vVectorCG.h"
#include "vModelBufferController.h"

#include "vDisplayController.h"
#include "vDisplayController_001.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "jackson_animation_focus_003.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_001.h"


ANIMATION_FOCUS_FRAME *p_jackson;
ANIMATION_FOCUS_FRAME m_jackson;

READ_PPM m_read_ppm;
READ_PPM m_read_ppm_002;

READ_PGM m_read_pgm;
READ_PGM m_read_pgm_002;

vModelBufferController display_006_01;

int debug_ppm[32];
Logging* logging;


// log
Logging log_001;
LOG_001* dlog_001;

int type_print_msg = 1;

static char* null_error =(char*) "-";

// 20250608
int debug_other_stack_killed = 4;

int set_log_001_jackson_animation (Logging* llog) ;

// basic
int call_draw_fucus_canvas_buffer_only () ;
int call_draw_fucus_canvas_buffer_only_001 () ;
int call_draw_canvas_all ();
ANIMATION_FOCUS_FRAME* get_jackson_pointer_animation_thread ();

int draw_number ();
int draw_effects ();
int draw_model_frame ();
int draw_grid ();
int initialize_parameters_all () ;


int brunch_functions_all ();

int initialize_ppm_fonts () ;
int initialize_ppm_fonts_debug () ;

int read_ppm_count (char* filename, READ_PPM* read_ppm, int* count) ;
int draw_canvas () ;
int draw_canvas_number ( char* str_number, READ_PPM* read_ppm ) ;

int initialize_media_tracker () ;

int read_ppm (char* filename, READ_PPM* read_ppm) ;
int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ;
int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ;
int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) ;

int sub_ppm_number () ;

// 20240128
int sub_fonts_number_focus_sheet ( int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ;
int sub_set_number_focus () ;

// 20240129
int initialize_fonts_param_sheet ();
int sub_fonts_number_focus_get_param_sheet () ;
int sub_fonts_number_focus_set_param_sheet () ;
int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y );
int sub_fonts_number_focus_set_param_sheet_basic () ;

// 20240207
int check_number_focus ();
int print_number_focus ();
int check_thumb_number_focus ();
int print_thumb_number_focus ();
int logging_thumb_number_focus () ;
int rand_print_thumb_number_focus ();

//20240208
int caribration_grid () ;
int caribration_grid_01_03 () ;

// 20240212
int Random_Work_Param ();
int Grid_Work_Param () ;
int Stored_Work_Param (char* file_name ) ;
int Check_Initialize_Param () ;
// 20240212
int Store_Work_Param (char* file_name ) ;
// 20240212
int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ;
// 20240212
int check_animation_focus(ANIMATION_FOCUS* focus) ;
int check_animation_focus_band(ANIMATION_FOCUS* focus) ;
// 20240212
int Resque_Initialize_Param ();

//20240219
int Save_Sound_Wave_Buffer () ;

//20240308
int is_initialized () ;

// 20240319
int sub_fonts_number_focus_set_param_sheet_result () ;
int set_number ();

// 20240322
int initialize_canvas () ;
// 20240321
int caribration_canvas () ;

// 20240324
int Resque_Number_Work_Param () ;
int Draw_Rigth_Top () ;
int Draw_Rigth_Top_001 () ;

// 20240330
int set_focus (int sx, int sy, int width, int height ) ;

// 20240404
int Draw_Focus_Number (int number_p ) ;
int Draw_Focus_Number_001 (int number_p ) ;
int Draw_Jackson_Focus_Number () ;
int Draw_Rigth_Top_004 (int number_p ) ;
int set_small_focus (int sx, int sy, int width, int height ) ;
int ascii_to_int ( char* num ) ;

int return_ppm_value ( int x, int y ) ;

int return_ppm_value_001 ( double x, double y ) ;
int return_ppm_value_002 ( double x, double y ) ;
int value_on_background ( int v1, int v2 ) ;

int set_font_background (int fbk_v) ;
int set_font_rasio (double fr_v) ;
int set_font_height_rasio (int height) ;

int read_pgm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ;
int read_pgm (char* filename, READ_PGM* read_ppm) ;
int read_pgm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ;

int Set_Font_Draw_Left_Top ( int x, int y ) ;
int Set_Font_Pix_Scale ( int scale ) ;
int Set_Font_Colour ( RGBT rgbt ) ;
int Set_Font_Height ( int height ) ;
int Set_Font_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;

int Set_Background_Colour ( RGBT rgbt ) ;
int Set_Grid_Colour ( RGBT rgbt ) ;
int Set_Grid_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;
int Set_Background_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;
int Set_Support_Number_001 (int num) ;
int Set_Support_Number (int num) ;
int Set_Background_Rect (int sx, int sy, int w, int h) ;
int Set_Foreground_Colour ( RGBT rgbt );

int Get_Background_Colour ( RGBT rgbt ) ;
int Get_Background_Colour_Rgb ( unsigned char *r, unsigned char *g, unsigned char *b ) ;



int Process_and_History (char* p_msg_string ) ;
int stack_msg_string (char* p_msg_string ) ;

int devide_num_history_focus_box (int num ) ;
int initialize_history_focus_box () ;

int initialize_pgm_fonts () ;

int Draw_Jackson_Focus_Circle () ;
int Draw_Jackson_Focus_Rectangle () ;
int Draw_Jackson_Focus_Triangle () ;

int Set_Foreground_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) ;


int Interface_Draw_Jackson (int* function_name () ) ;

int line_to (int x1, int y1, int x2, int y2, double a) ;
int Line_To (int x1, int y1, int x2, int y2) ;

int check_draw_line_to () ;
int check_draw_circle () ;
int check_break_draw_line_to () ;
int check_break_draw_circle () ;
int check_continue_draw_line_to () ;
int check_continue_draw_circle () ;

// 20240611
int check_draw_string () ;
int check_break_draw_string () ;
int check_continue_draw_string () ;

int create_draw_focus_circle ( ) ;
int inside_circle ( int i, int j ) ;

int Draw_Circle ( float x, float y, float r ) ;

int polygon_to (float x1, float y1, float x2, float y2, float x3, float y3 ) ;
int line_to_002_01 (float x1, float y1, float x2, float y2, int stack) ;
double distance_to (float x1, float y1, float x2, float y2) ;
int line_to_002 (float x1, float y1, float x2, float y2, double a, int stack ) ;
int line_stack (float x, float y, int num ) ;

// 20240625
int line_to_003 (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) ;
int Draw_Circle_Line (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;

// 20240711
int check_break_line_to_003_01 ( double i, double j, int flag, int x2, int y2 ) ;
int check_break_line_to_003_02 ( double i, double j, int flag, int cnt, int* skip ) ;

int draw_circle_line_to_003 ( double i, double j, float base, int skip, int type ) ;
int first_line_to_003 (float x1, float y1, float x2, float y2, double a, float base, int flag, int type, int first_type, int cnt, double *i, double *j ) ;

// 20240721
vReturnableParam* calculate_start_and_base_step ( float x1, float y1, float x2, float y2, double base ) ;
int Full_Triangle ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
double stepwork_rasio ( double i, double j, float x1, float y1, float x2, float y2, double* len2 ) ;
int stepwork_rasio_cursol ( double* i, double* j, float x1, float y1, float x2, float y2, double scale ) ;
int line_to_003_step_only (float x1, float y1, float x2, float y2, double a, float base, float length ) ;

// 20240721
int Full_Square ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
int line_to_003_step_only_full_square (float x1, float y1, float x2, float y2, double a, float base, float length ) ;
int line_to_003_step_only_full_square_01 (float x1, float y1, float x2, float y2, double a, float base, float length ) ;

int Full_Square_01 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
int Draw_Circle_Line (float base_x1, float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
int Draw_Circle_Line_grid (float base_x1, float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;

int line_to_003_step_only_full_square_01 (float x1, float y1, float x2, float y2, double a, float base, float length ) ;
int line_to_003_step_only_full_square_fix1 (float x1, float y1, float x2, float y2, double a, float base, float length ) ;
int line_to_003_step_only_full_square_fix2 (float x1, float y1, float x2, float y2, double a, float base, float length ) ;
int line_to_003_step_only_full_square_fix3 (float x1, float y1, float x2, float y2, double a, float base, float length ) ;

int Draw_Circle_Line_Fraction (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
int Full_Square_Fix1 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
int Full_Square_Fix2 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;
int Full_Square_Fix3 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) ;

int line_to_003_fraction (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) ;

int Get_Font_Colour ( RGBT *rgbt ) ;
int draw_circle_line_to_003_Normal ( double i, double j, float base, int skip, int type ) ;
int draw_circle_line_to_003_Normal_05 ( double i, double j, float base, int skip, int type ) ;
int draw_circle_line_to_fix1 ( double i, double j, float base, int skip, int type ) ;

// 20240903
int line_to_003_step_only_full_square_fix1_001 (float x1, float y1, float x2, float y2, double a, float base, float length ) ;
int Draw_Circle_Line_Power_Flag (float x1, float y1, float x2, float y2, float power, int flag, float bold, int type, int first_type ) ;

// 20240904
int Draw_Circle_Line_004 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;

// 20240917
int Load_Inifile_Jackson ( ) ;
int Read_Inifile_Jackson (char* inifile) ;

// 20240918
int is_alphabet(char c) ;
int is_end (FILE* fp, int start, int file_end, char c, char** result, int* end) ;
int is_start(char c1, char c2) ;

// 20240924
int Full_Box1 ( int x1, int y1, int width, int height) ;
int Full_Box2 ( int x1, int y1, int width, int height) ;
int Initialize_Full_Box_Ifnot () ;

//20240925
int File_Print_Function (char* file_name, int* point_func, int num, int max );
int File_Print_Function_Full_Box ();

// 20241008
int Read_Menufile_Jackson (char* menufile) ;
int Load_Menufile_Jackson ( ) ;

// 20241008
int stack_menu ( char* menu_001 );
int print_stack_menu ();

// 20241016
int file_print_stack_menu (char* file_print) ;
int File_Write_Stack_Menu ();
int file_code_stack_menu (char* file_code) ;
int File_Code_Stack_Menu ();

// 20241029
// 0/5
// 0|ini_filename_name|
int ini_filename_name ( ) ;
int ini_filename_name_continue ( ) ;
int ini_filename_name_break ( ) ;
int ini_filename_name_initialize ( char* returnable_file_name ) ;

// 1|asm_filename_name|
int asm_filename_name ( ) ;
int asm_filename_name_continue ( ) ;
int asm_filename_name_break ( ) ;
int asm_filename_name_initialize ( char* returnable_file_name ) ;

// 2|menu_filename_name|
int menu_filename_name ( ) ;
int menu_filename_name_continue ( ) ;
int menu_filename_name_break ( ) ;
int menu_filename_name_initialize ( char* returnable_file_name ) ;

// 3|menu_stack_print_filename_name|
int menu_stack_print_filename_name ( ) ;
int menu_stack_print_filename_name_continue ( ) ;
int menu_stack_print_filename_name_break ( ) ;
int menu_stack_print_filename_name_initialize ( char* returnable_file_name ) ;

// 4|menu_stack_code_filename_name|
int menu_stack_code_filename_name ( ) ;
int menu_stack_code_filename_name_continue ( ) ;
int menu_stack_code_filename_name_break ( ) ;
int menu_stack_code_filename_name_initialize ( char* returnable_file_name ) ;

// 20241101
int ini_block_stack (char* block_name);

// 20241111
int block_analysis (FILE* fp, int start, int file_end,  char** result, int* end);
int is_end_str (FILE* fp, int start, int file_end, char* str, char** result, int* end) ;
int block_analysis_sets (FILE* fp, int start, int file_end,  char** result, int* end, char*** h_name, char*** h_value, int* max_index, int* index ) ;
int block_analysis_display_colour_sets (FILE* fp, int start, int file_end,  char** result, int* end) ;
int block_analysis_rasio_sets (FILE* fp, int start, int file_end,  char** result, int* end);
int block_analysis_setup_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end);

// 20241115
// 20241117
int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index , char** result) ;
int block_analysis_display_colour_sets_extract_print (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index, char** result);
int block_analysis_display_colour_sets_extract_org1 (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_inde, char** result );

// 20241121

// 20241209
int block_analysis_display_colour_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ;
int set_rgbt_colour ( char* value, RGBT* col) ;
int print_rgbt_colour (RGBT* col) ;
int m_atoi(char* str) ;
int is_number_a (char c) ;

//20241211
int set_circle_r ( char* value, double* circle_r ) ;
double m_atof(char* str);

int block_analysis_rasio_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ;
int block_analysis_setup_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ;

// 20241222
char* to_semmi_colon (char* str_filename ) ;
char* m_trim_file_name (char* str_filename ) ;

// 20250108
int Background_Points_Sampling ();
int Background_Draw_Messages ();
int Background_Button_OK_Cancel ();

// 20250116
int set_draw_focus (int sx, int sy, int width, int height );

// 20250128
int Organize_Bones (int type);
int Initialize_Organize_Bones ();
int Release_Organize_Bones ();
int Draw_Organize_Bones (vPoint** points, int num);
int Print_Organize_Bones (vPoint** points, int num);


// 20250221
int Draw_Organize_Bones_Line (vPoint** points, int num);



// 20250301
int devide_focuses ();
int common_devide_focuses ();
int initialize_devide_focuses ();

// 20250317
ANIMATION_FOCUS **rect_focus;
int rects_focus_index = 0;
int rects_focus_max = 32;

// 20251226
int debug_small_area = 2;

// 20250317
int Initialize_Refresh_Focus_Focus_Rects ();
int Reinitialize_Refresh_Focus_Focus_Rects ();
int Stack_Focus_Rect (ANIMATION_FOCUS* r) ;
ANIMATION_FOCUS* Pop_Focus_Rect ();
int Print_Refresh_Focus_Focus_Rects ();

int Print_Refresh_Focus_Focus_Rects_001 ();

// 20250615
int print_set_focus ();
int print_set_draw_focus ();

// 20250916
int Reinitialize_Refresh_Several_Focus_001_01 ();
int Reinitialize_Refresh_Several_Focus_001_02 ();
int Reinitialize_Refresh_Several_Focus_001_03 ();
int Reinitialize_Refresh_Several_Focus_001_04 ();
int Reinitialize_Refresh_Several_Focus_001_05 ();
int Reinitialize_Refresh_Several_Focus_001_06 ();

// 20250924
int block_analysis_work_directory_sets (FILE* fp, int start, int file_end,  char** result, int* end) ;
int block_analysis_project_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) ;
int block_analysis_work_directory_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ;
int block_analysis_project_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ;

// 20251208
int Initialize_Map_Grid_Focus () ;

// 20251213
int Set_Map_Grid_Focus_xy ( int x, int y ) ;
int Free_Map_Grid_Focus () ;
int Initialize_xxxx_000_03 () ;
int Initialize_xxxx_000_04 () ;
int Initialize_xxxx_000_05 () ;
int Initialize_xxxx_000_06 () ;
int Initialize_xxxx_000_07 () ;
int Initialize_xxxx_000_08 () ;
int Initialize_xxxx_000_09 () ;
int Initialize_xxxx_000_10 () ;
int Initialize_xxxx_000_11 () ;
int Initialize_xxxx_000_12 () ;

// 20251213
int Release_Map_Grid_Focus () ;
int Release_xxxx_000_02 () ;
int Release_xxxx_000_03 () ;
int Release_xxxx_000_04 () ;
int Release_xxxx_000_05 () ;
int Release_xxxx_000_06 () ;
int Release_xxxx_000_07 () ;
int Release_xxxx_000_08 () ;
int Release_xxxx_000_09 () ;
int Release_xxxx_000_10 () ;
int Release_xxxx_000_11 () ;
int Release_xxxx_000_12 () ;

int Set_Drew_Map_Grid_Focus_xy ( int x, int y, unsigned char value );
// 20251218
int Set_Drew_Map_Grid_Focus_From_Image_xy ( int x, int y ) ;
// 20251226
int Get_Drew_Map_Grid_Focus_xy ( int x, int y, int* value );
int Get_Drew_Map_Grid_Focus_xy_with_sleep ( int x, int y, int* value );

int set_debug_small_area ( int val );

// --- EOH --- end of header ---

int set_debug_small_area ( int val ) {
	debug_small_area = val;
	printf("debug_small_area %d\r\n", debug_small_area);
	Sleep(5000);
	return 0;
}

// 20250317
int Print_Refresh_Focus_Focus_Rects_001 () {
	int i;

	if ( debug_print_msg_param () == 1 ) printf("int Print_Refresh_Focus_Focus_Rects_001 () starts.\r\n");

	if ( rect_focus == NULL ) {
		return -1;
	}

	for ( i = 0; i<rects_focus_index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("|%d|%p|\r\n", i, (ANIMATION_FOCUS*)rect_focus[i] );
	}

	if ( debug_print_msg_param () == 1 ) printf("int Print_Refresh_Focus_Focus_Rects_001 () ends.\r\n");
	return 0;
}



// 20250317
int Stack_Focus_Rect (ANIMATION_FOCUS* r) {
	int b;

	if ( debug_print_msg_param () == 1 ) printf("int Stack_Focus_Rect (ANIMATION_FOCUS* r) starts.\r\n");

	if ( debug_other_stack_killed <= 1 ) {
		printf("Stack_Focus_Rect: debug_other_stack_killed %d\r\n", debug_other_stack_killed);
		exit(-1);
	}

	if ( rect_focus == NULL ) {
		b = Initialize_Refresh_Focus_Focus_Rects ();
	}

	if ( rects_focus_index >= rects_focus_max )
		b = Reinitialize_Refresh_Focus_Focus_Rects ();

	rect_focus[rects_focus_index] = (ANIMATION_FOCUS*) r;
	rects_focus_index++;

	if ( debug_print_msg_param () == 1 ) printf("int Stack_Focus_Rect (ANIMATION_FOCUS* r) ends.\r\n");
	return 0;
}

// 20250317
ANIMATION_FOCUS* Pop_Focus_Rect () {
	int i;
	ANIMATION_FOCUS* result;

	if ( debug_print_msg_param () == 1 ) printf("ANIMATION_FOCUS* Pop_Focus_Rect () starts.\r\n");

	if ( rect_focus == NULL ) {
		return NULL;
	}

	result = rect_focus[0];
	for ( i=1; i<rects_focus_max; i++ ) {
		rect_focus[i - 1] = (ANIMATION_FOCUS*)rect_focus[i];
	}

	rects_focus_index--;

	if ( debug_print_msg_param () == 1 ) printf("ANIMATION_FOCUS* Pop_Focus_Rect () ends.\r\n");
	return result;
}

// 20250317
int Reinitialize_Refresh_Focus_Focus_Rects () {
	ANIMATION_FOCUS** a;
	int i, num, b;

	if ( debug_print_msg_param () == 1 ) printf("int Reinitialize_Refresh_Focus_Focus_Rects () starts.\r\n");

	a = (ANIMATION_FOCUS**)rect_focus;
	num = rects_focus_max;
	rects_focus_max *= 2;
	b = Initialize_Refresh_Focus_Focus_Rects () ;
	for ( i=0; i<num; i++ ) {
		rect_focus[i] = a[i];
	}

	free ( a );

	if ( debug_print_msg_param () == 1 ) printf("int Reinitialize_Refresh_Focus_Focus_Rects () ends.\r\n");
	return 0;
}

// 20250317
int Initialize_Refresh_Focus_Focus_Rects () {

	if ( debug_print_msg_param () == 1 ) printf("int Initialize_Refresh_Focus_Focus_Rects () starts.\r\n");

	rects_focus_max = 32;
	rects_focus_index = 0;

	rect_focus = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * rects_focus_max );
	if ( rect_focus == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("rect_focus is NULL.\r\n");
		exit(-1);
	}

	if ( debug_print_msg_param () == 1 ) printf("int Initialize_Refresh_Focus_Focus_Rects () ends.\r\n");
	return 0;
}

// 20250317
int Print_Refresh_Focus_Focus_Rects () {
	int i;

	if ( debug_print_msg_param () == 1 ) printf("int Print_Refresh_Focus_Focus_Rects () starts.\r\n");

	if ( rect_focus == NULL ) {
		return -1;
	}

	for ( i = 0; i<rects_focus_index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("|%d|%p|\r\n", i, (ANIMATION_FOCUS*)rect_focus[i] );
	}

	if ( debug_print_msg_param () == 1 ) printf("int Print_Refresh_Focus_Focus_Rects () ends.\r\n");
	return 0;
}




int devide_focuses () {
	int a;

	a = initialize_devide_focuses ();

	return 0;
}

int initialize_devide_focuses () {

	return 0;
}



int common_devide_focuses () {

	return 0;
}



// 20250128
int Organize_Bones (int type) {
	int a, num;
	vPoint** points = nullptr;
	if ( debug_print_msg_param () == 1 ) printf("int Organize_Bones () starts.\r\n");

	a = Initialize_Organize_Bones ();

//	display_006_01.SetBaseAxex ();
//	display_006_01.SetEye ( -1000.0f, 1000.0f, -1000.0f);
	display_006_01.CreateBones_call_one_time ();

	// get points
	points = (vPoint**)display_006_01.GetPoints (&num);

	// set points -> Draw points
	a = Print_Organize_Bones (points, num);
	a = Draw_Organize_Bones (points, num);
	a = Draw_Organize_Bones_Line (points, num);

	a = Release_Organize_Bones ();

	switch ( type ) {
	case 1:
		a = set_focus ( 0, 0, 640, 480);
		break;
	default:
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Organize_Bones () ends.\r\n");
	return 0;
}

// 20250128
int Initialize_Organize_Bones () {
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int Initialize_Organize_Bones () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("int Initialize_Organize_Bones () ends.\r\n");
	return 0;
}

// 20250128
int Release_Organize_Bones () {
	if ( debug_print_msg_param () == 1 ) printf("int Release_Organize_Bones () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("int Release_Organize_Bones () ends.\r\n");
	return 0;
}

// 20250128
int Draw_Organize_Bones (vPoint** points, int num) {
	int i, a, num3;
	float max_x, max_y, min_x, min_y;

	printf("Draw_Organize_Bones: |%p|%d| starts.\r\n", points, num );

	max_x = 0.0f;
	max_y = 0.0f;
	min_x = 99999.0f;
	min_y = 99999.0f;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Organize_Bones (vPoint** points, int num) starts.\r\n");

	//
	vPoint** points3 = (vPoint**)display_006_01.GetPoints3D (&num3);
	a = Print_Organize_Bones (points, num3);
	a = display_006_01.PrintEye ();

	printf("Loop: |%p|%d| starts.\r\n", points, num );
	for ( i = 0; i<num; i++ ) {
		printf("2D|%p|", points[i] );
		printf("[%d] x %0.3f y %0.3f\r\n", i, points[i]->x, points[i]->y );
	}
	printf("Loop: |%p|%d| ends.\r\n", points, num );

	printf("Loop2: |%p|%d| starts.\r\n", points, num );
	for ( i = 0; i<num; i++ ) {
		printf("|%p|", points[i] );
		a = Draw_Circle(points[i]->x, points[i]->y, 5.0f);
		if ( max_x < points[i]->x ) max_x = points[i]->x;
		if ( max_y < points[i]->y ) max_y = points[i]->y;
		if ( min_x > points[i]->x ) min_x = points[i]->x;
		if ( min_y > points[i]->y ) min_y = points[i]->y;
		printf("[%d] sx %0.3f sy %0.3f w %0.3f h %0.3f\r\n", i, min_x, min_y, (max_x - min_x), (max_x - min_x) );
	}
	printf("Loop2: |%p|%d| ends.\r\n", points, num );
	printf("sx %0.3f sy %0.3f w %0.3f h %0.3f\r\n", min_x, min_y, (max_x - min_x), (max_x - min_x) );

	a = set_focus ( (int)min_x, (int)min_y, (int)(max_x - min_x), (int)(max_y - min_y) );

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Organize_Bones (vPoint** points, int num) ends.\r\n");

	printf("Draw_Organize_Bones: |%p|%d| ends.\r\n", points, num );

	return 0;
}

// 20250128
int Draw_Organize_Bones_Line (vPoint** points, int num) {
	int i, a;
	RGBT rgbt;
	if ( debug_print_msg_param () == 1 ) printf("int Draw_Organize_Bones_Line (vPoint** points, int num) starts.\r\n");

	rgbt = p_jackson->fore_ground_colour;
	a = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );



	for ( i = 1; i<num; i++ ) {
		a =	Draw_Circle_Line ( points[i - 1]->x, points[i - 1]->y, points[i]->x, points[i]->y, 1.0, 2, 0 );
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Organize_Bones_Line (vPoint** points, int num) ends.\r\n");
	return 0;
}


// 20250128
int Print_Organize_Bones (vPoint** points, int num) {
	int i;
	vPoint* p = nullptr;
	if ( 1 ) printf("int Print_Organize_Bones (vPoint** points, int num) starts.\r\n");

	for ( i = 0; i<num; i++ ) {
		if ( 1 ) printf("point[%d]", i);
		p = (vPoint*) points[i];
		if ( 1 ) printf("|%p|", p);
		if ( p != nullptr )
			if ( 1 ) printf("(%0.3f,%0.3f,%0.3f)\r\n", p->x, p->y, p->z );
	}

	if ( 1 ) printf("int Print_Organize_Bones (vPoint** points, int num) ends.\r\n");
	return 0;
}


/*
	p_jackson->draw_focus.start_x = sx;
	p_jackson->draw_focus.start_y = sy;
	p_jackson->draw_focus.width   = width;
	p_jackson->draw_focus.height  = height;
*/

// 20250108
int Background_Points_Sampling () {
	int x, y, width, height, margin, cnt;
	float line_length, line_height, i, j;
	if ( debug_print_msg_param () == 1 ) printf("Background_Points_Sampling () starts.\r\n");
	x = p_jackson->draw_focus.start_x;
	y = p_jackson->draw_focus.start_y;
	width = p_jackson->draw_focus.width;
	height = p_jackson->draw_focus.height;
	margin = 5;
	line_length = 15.0f;
	line_height = sqrt(3.0f) * line_length/2.0f;
	cnt = 0;
	if ( debug_print_msg_param () == 1 ) printf("i %0.3f/%d, j %0.3f/%d\r\n", i, width, j, height);
	for ( j = y; j< y + height; j+=line_height ) {
		for ( i = x; i< x + width; i+=line_length ) {
			if ( debug_print_msg_param () == 1 ) printf("i %0.3f, j %0.3f\r\n", i, j);
			p_jackson->canvas[(int)i][(int)j] = 0;
			// C:\Users\Beneton\Documents\source\cg\axex-20230816
		}
		cnt++;
		if ( cnt % 2 == 1 ) x+= line_length / 2.0f;
		else x -= line_length / 2.0f;
 	}

	if ( debug_print_msg_param () == 1 ) printf("Background_Points_Sampling () ends.\r\n");
	return 0;
}

// 20250108
int Background_Draw_Messages () {
	return 0;
}

// 20250108
int Background_Button_OK_Cancel () {
	return 0;
}


// if ( debug_print_msg_param () == 1 ) printf ->  f_fp_rintf
// sif ( debug_print_msg_param () == 1 ) printf -> s_pr_intf
// if ( debug_print_msg_param () == 1 ) printf ->
// if ( debug_print_msg_param () == 1 ) printf
// f_fp_rintf -> if ( debug_print_msg_param () == 1 ) printf
// s_pr_intf -> sif ( debug_print_msg_param () == 1 ) printf
int ini_block_stack (char* block_name) {
	char** d_ini_block_name = NULL;
	int i;

	if ( debug_print_msg_param () == 1 ) printf("int ini_block_stack (char* block_name)  starts.\r\n");

	if ( p_jackson->ini_block_index == 0 )
		p_jackson->ini_block_name = (char**) malloc (sizeof(char*) * p_jackson->ini_block_index_max );

	p_jackson->ini_block_index++;

	if ( p_jackson->ini_block_index >= p_jackson->ini_block_index_max ) {
		p_jackson->ini_block_index_max *= 2;
		d_ini_block_name = (char**) malloc (sizeof(char*) * p_jackson->ini_block_index_max );
		for ( i = 0; i<p_jackson->ini_block_index; i++ ) {
			d_ini_block_name[i] = p_jackson->ini_block_name[i];
		}
		free(p_jackson->ini_block_name);
		p_jackson->ini_block_name = (char**)d_ini_block_name; 
	}


	p_jackson->ini_block_name[p_jackson->ini_block_index - 1 ] = copyof_012(block_name);

	if ( debug_print_msg_param () == 1 ) printf("int ini_block_stack (char* block_name)  ends.\r\n");

	return 0;
}


// code 0|ini_filename_name| 

int ini_filename_name ( ) {
	int a;
	char filename[255];

	a = ini_filename_name_initialize ( (char*)&filename );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("fail to open: filename: %s\r\n", filename);
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		return -1;
	}


 	return 0;

}



int ini_filename_name_continue ( ) {

 	return 0;

}



int ini_filename_name_break ( ) {

 	return 0;

}



int ini_filename_name_initialize ( char* returnable_file_name ) {
	char* current = ".";
	char* seperate = "\\";
	char* file_name = NULL;
	char* folder = "ini";

	if ( debug_print_msg_param () == 1 ) printf("int ini_filename_name_initialize ( char* returnable_file_name ) starts.\r\n");

	returnable_file_name = file_name;

	if ( debug_print_msg_param () == 1 ) printf("int ini_filename_name_initialize ( char* returnable_file_name ) ends.\r\n");

 	return 0;

}



// code 1|asm_filename_name| 

int asm_filename_name ( ) {

	int a;
	char filename[255];

	a = asm_filename_name_initialize ( (char*)&filename );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("fail to open: filename: %s\r\n", filename);
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		return -1;
	}


 	return 0;

}



int asm_filename_name_continue ( ) {

 	return 0;

}



int asm_filename_name_break ( ) {

 	return 0;

}



int asm_filename_name_initialize ( char* returnable_file_name ) {
	char* current = ".";
	char* seperate = "\\";
	char* file_name = NULL;
	char* folder = "asm";

	if ( debug_print_msg_param () == 1 ) printf("int asm_filename_name_initialize ( char* returnable_file_name ) starts.\r\n");


	returnable_file_name = file_name;


	if ( debug_print_msg_param () == 1 ) printf("int asm_filename_name_initialize ( char* returnable_file_name ) ends.\r\n");


 	return 0;

}



// code 2|menu_filename_name| 

 int menu_filename_name ( ) {

	int a;
	char filename[255];

	a = menu_filename_name_initialize ( (char*)&filename );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("fail to open: filename: %s\r\n", filename);
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		return -1;
	}



 	return 0;

}



int menu_filename_name_continue ( ) {

 	return 0;
}



int menu_filename_name_break ( ) {

 	return 0;

}



int menu_filename_name_initialize ( char* returnable_file_name ) {
	char* current = ".";
	char* seperate = "\\";
	char* file_name = NULL;
	char* folder = "Menu";

	if ( debug_print_msg_param () == 1 ) printf("int menu_filename_name_initialize ( char* returnable_file_name ) starts.\r\n");

	returnable_file_name = file_name;

	if ( debug_print_msg_param () == 1 ) printf("int menu_filename_name_initialize ( char* returnable_file_name ) ends.\r\n");

 	return 0;
}



// code 3|menu_stack_print_filename_name| 

 int menu_stack_print_filename_name ( ) {

	int a;
	char filename[255];

	a = menu_stack_print_filename_name_initialize ( (char*)&filename );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("fail to open: filename: %s\r\n", filename);
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		return -1;
	}


 	return 0;

}



int menu_stack_print_filename_name_continue ( ) {

 	return 0;
}



int menu_stack_print_filename_name_break ( ) {

 	return 0;

}



int menu_stack_print_filename_name_initialize ( char* returnable_file_name ) {
	char* current = ".";
	char* seperate = "\\";
	char* file_name = NULL;
	char* folder = "Menu";

	if ( debug_print_msg_param () == 1 ) printf("int menu_stack_print_filename_name_initialize ( char* returnable_file_name ) starts.\r\n");

	returnable_file_name = file_name;

	if ( debug_print_msg_param () == 1 ) printf("int menu_stack_print_filename_name_initialize ( char* returnable_file_name ) ends.\r\n");

 	return 0;
}



// code 4|menu_stack_code_filename_name| 

int menu_stack_code_filename_name ( ) {

	int a;
	char filename[255];

	a = menu_stack_code_filename_name_initialize ( (char*)&filename );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("fail to open: filename: %s\r\n", filename);
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		return -1;
	}


 	return 0;

}



int menu_stack_code_filename_name_continue ( ) {

 	return 0;

}



int menu_stack_code_filename_name_break ( ) {

 	return 0;

}



int menu_stack_code_filename_name_initialize ( char* returnable_file_name ) {
	char* current = ".";
	char* seperate = "\\";
	char* file_name = NULL;
	char* folder = "Menu";

	if ( debug_print_msg_param () == 1 ) printf("int menu_stack_code_filename_name_initialize ( char* returnable_file_name ) starts.\r\n");

	returnable_file_name = file_name;

	if ( debug_print_msg_param () == 1 ) printf("int menu_stack_code_filename_name_initialize ( char* returnable_file_name ) ends.\r\n");
 	return 0;

}



//
//
int File_Code_Stack_Menu () {
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int File_Code_Stack_Menu () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("open filename |%s|\r\n", p_jackson->menu_stack_code_filename_name);
	a = file_code_stack_menu ( p_jackson->menu_stack_code_filename_name );

	if ( debug_print_msg_param () == 1 ) printf("int File_Code_Stack_Menu () ends.\r\n");
}


//
// C:\Users\Beneton\Documents\source\cg\axex-20230816
// 
int file_code_stack_menu (char* file_code)  {
	int i;
	FILE *fp;
	char* ch_continue = (char*) "_continue";
	char* ch_break = (char*) "_break";
	char* ch_initialize = (char*) "_initialize";
	char* ch_hifun = (char*) "_";
	char* ch_left_brace = (char*) "(";
	char* ch_right_brace = (char*) ")";
	char* ch_comma = (char*) ";";
	char* ch_return = (char*) "int";
	char* ch_curry_left_brace = (char*) "{\r\n";
	char* ch_curry_right_brace = (char*) "}\r\n";
	char* ch_code = (char*) "	return 0;\r\n";

	if ( debug_print_msg_param () == 1 ) printf("int file_code_stack_menu () starts.\r\n");

	fp = fopen(file_code, "w");

	i = 0;
	if ( debug_print_msg_param () == 1 ) printf( "%d/%d\r\n", i, p_jackson->menu_num);
	if ( debug_print_msg_param () == 1 ) fprintf( fp, "// %d/%d\r\n", i, p_jackson->menu_num);
	for ( i = 0; i<p_jackson->menu_num; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf( "// %d|%s| ... ", i,  p_jackson->menu_name[i]);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "// %d|%s|\r\n", i,  p_jackson->menu_name[i]);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s\r\n", ch_return, p_jackson->menu_name[i], ch_left_brace, ch_right_brace, ch_comma);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s\r\n", ch_return, m_concat( p_jackson->menu_name[i], ch_continue) , ch_left_brace, ch_right_brace, ch_comma);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s\r\n", ch_return, m_concat( p_jackson->menu_name[i], ch_break) , ch_left_brace, ch_right_brace, ch_comma);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s\r\n", ch_return, m_concat( p_jackson->menu_name[i], ch_initialize) , ch_left_brace, ch_right_brace, ch_comma);
		if ( debug_print_msg_param () == 1 ) printf( " O.K.\r\n");
	}

	for ( i = 0; i<p_jackson->menu_num; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf( "// code %d|%s| ... ", i,  p_jackson->menu_name[i]);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "// code %d|%s| \r\n ", i,  p_jackson->menu_name[i]);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s %s%s\r\n", ch_return, p_jackson->menu_name[i], ch_left_brace, ch_right_brace, ch_curry_left_brace, ch_code, ch_curry_right_brace);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s %s%s\r\n", ch_return, m_concat( p_jackson->menu_name[i], ch_continue) , ch_left_brace, ch_right_brace, ch_curry_left_brace, ch_code, ch_curry_right_brace);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s %s%s\r\n", ch_return, m_concat( p_jackson->menu_name[i], ch_break) , ch_left_brace, ch_right_brace, ch_curry_left_brace, ch_code, ch_curry_right_brace);
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%s %s %s %s %s %s%s\r\n", ch_return, m_concat( p_jackson->menu_name[i], ch_initialize) , ch_left_brace, ch_right_brace, ch_curry_left_brace, ch_code, ch_curry_right_brace);
		if ( debug_print_msg_param () == 1 ) printf( " O.K.\r\n");
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int file_code_stack_menu () ends.\r\n");
	return 0;
}


//
//
int File_Write_Stack_Menu () {
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int File_Write_Stack_Menu () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("open filename |%s|\r\n", p_jackson->menu_stack_print_filename_name );
	a = file_print_stack_menu ( p_jackson->menu_stack_print_filename_name );

	if ( debug_print_msg_param () == 1 ) printf("int File_Write_Stack_Menu () ends.\r\n");
}


//
// C:\Users\Beneton\Documents\source\cg\axex-20230816
// 
int file_print_stack_menu (char* file_print)  {
	int i;
	FILE *fp;

	if ( debug_print_msg_param () == 1 ) printf("int file_print_stack_menu () starts.\r\n");

	fp = fopen(file_print, "w");

	if ( debug_print_msg_param () == 1 ) fprintf( fp, "%d/%d\r\n", i, p_jackson->menu_num);
	for ( i = 0; i<p_jackson->menu_num; i++ ) {
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "%d|%s|\r\n", i,  p_jackson->menu_name[i]);
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int file_print_stack_menu () ends.\r\n");
	return 0;
}

int print_stack_menu () {
	int i;

	if ( debug_print_msg_param () == 1 ) printf("int print_stack_menu () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("%d/%d\r\n", i, p_jackson->menu_num);

	for ( i = 0; i<p_jackson->menu_num; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("%d|%s|\r\n", i,  p_jackson->menu_name[i]);
	}
	if ( debug_print_msg_param () == 1 ) printf("int print_stack_menu () ends.\r\n");
}

int stack_menu ( char* menu_001 ) {
	char** d_menu_name = NULL;
	int i;
	if ( debug_print_msg_param () == 1 ) printf("int stack_menu ( char* menu_001 ) starts.\r\n");

	if ( p_jackson->menu_num == 0 )
		p_jackson->menu_name = (char**) malloc (sizeof(char*) * p_jackson->menu_num_max );

	p_jackson->menu_num++;

	if ( p_jackson->menu_num >= p_jackson->menu_num_max ) {
		p_jackson->menu_num_max *= 2;
		d_menu_name = (char**) malloc (sizeof(char*) * p_jackson->menu_num_max );
		for ( i = 0; i<p_jackson->menu_num; i++ ) {
			d_menu_name[i] = p_jackson->menu_name[i];
		}
		free(p_jackson->menu_name);
		p_jackson->menu_name = (char**)d_menu_name;
	}

	p_jackson->menu_name[p_jackson->menu_num - 1 ] = copyof_012(menu_001);

	if ( debug_print_msg_param () == 1 ) printf("int stack_menu ( char* menu_001 ) ends.\r\n");
	return 1;
}

// l -> m
// 20241O08
int Load_Menufile_Jackson ( ) {
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int Load_Menufile_Jackson ( ) starts.\r\n");

	if ( p_jackson ==NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("int Load_Menufile_Jackson ( ) return -1.\r\n");
		return -1;
	}

	a = Read_Menufile_Jackson (p_jackson->button_ok_cancel);
	a = print_stack_menu ();

	if ( debug_print_msg_param () == 1 ) printf("int Load_Menufile_Jackson ( ) ends.\r\n");
	return 0;
}


//
// 20241O08
int Read_Menufile_Jackson (char* menufile) {
	FILE *fp;
	int i;
	char dummy[255];
	char c;
	int a, ac;
	int file_end;
	char* result;
	int ii;
	aToken *iToken = nullptr;
	char* a_token = NULL;
	int mode = 0;

	if ( debug_print_msg_param () == 1 ) printf("int Read_Menufile_Jackson (char* menufile) starts.\r\n");

	iToken = new aToken ();

	fp = fopen(menufile, "rb");
	file_end = filesize_004 (fp);

	for ( i =0; i<file_end; i++ ) {
		fread( dummy, 1, 1, fp );
		c = dummy[0];
		if ( debug_print_msg_param () == 1 ) printf("c|%c| ", c );

		a_token = (char*) iToken->put_token( c ) ;

		if ( debug_print_msg_param () == 1 ) printf("000 ");

		if ( mode==0 && iToken->last_token( (char*) "//" ) == 1 ) {
			mode = 1;
		}

		if ( debug_print_msg_param () == 1 ) printf("001 ");

		if ( mode == 1 && iToken->last_token( (char*) "\r\n" ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("|%s| ", iToken->token );
			iToken->clear_token ();
			mode = 0;
			if ( debug_print_msg_param () == 1 ) printf("continue... %d/%d clear token|%s|\r\n", i, file_end, iToken->token );
			if ( debug_print_msg_sleep () == 1 ) Sleep(250);
			continue;
		}

		if ( debug_print_msg_param () == 1 ) printf("002 ");

		if ( mode == 0 && iToken->last_token( (char*) "\r\n" ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("|%s|\r\n", iToken->token );
			ac = array_count( iToken->token );
			stack_menu ( m_substring( iToken->token, 0, ac -2 ) );
			iToken->clear_token ();
			if ( debug_print_msg_param () == 1 ) printf("continue... %d/%d clear token|%s|\r\n", i, file_end, iToken->token );
			if ( debug_print_msg_sleep () == 1 ) Sleep(250);
			continue;
		}

		if ( debug_print_msg_param () == 1 ) printf("003\r\n");

	}

	if ( debug_print_msg_param () == 1 ) printf("004\r\n");
	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int Read_Menufile_Jackson (char* menufile) ends.\r\n");
	return 0;
}



//
//
//



// l -> n -> p
int File_Print_Function_Full_Box () {
	int a;
	int num;
	if ( debug_print_msg_param () == 1 ) printf("int File_Print_Function_Full_Box () starts.\r\n");

	num = (int*)p_jackson->Full_Box2 - (int*)p_jackson->Full_Box1;
	num = abs(num) / 4;
	a = File_Print_Function ( p_jackson->asm_filename_name, (int*) p_jackson->Full_Box1, num, num - 1 );

	if ( debug_print_msg_param () == 1 ) printf("int File_Print_Function_Full_Box () ends.\r\n");
	return 0;
}

//
int File_Print_Function (char* file_name, int* point_func, int num, int max ) {
	int i;
	FILE *fp;
	int* cur;
	RGBT* col;
	RGBT* value;
	int int_value;

	if ( debug_print_msg_param () == 1 ) printf("int File_Print_Function (char* file_name, int* point_func, int num, int max ) starts.\r\n");

	fp = fopen(file_name, "ab");

	if ( debug_print_msg_param () == 1 ) printf( "print_lines %d / %d:\r\n", num, max);
	if ( debug_print_msg_param () == 1 ) fprintf( fp, "print_lines %d / %d:\r\n", num, max);

	cur = (int*) point_func;
	for ( i=0; i<max && i<num && type_print_msg == 1 ; i++ ) {
		col = (RGBT*) cur;
		int_value = (int) *cur;
		value = (RGBT*) &int_value;

		if ( debug_print_msg_param () == 1 ) printf( "|%04d|%016d|%03d|%03d|%03d|%03d|\r\n", i, cur, col->r, col->g, col->b, col->t );
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "|%04d|%p|%03d|%03d|%03d|%03d| ", i, cur, col->r, col->g, col->b, col->t );
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "|%p| ", (int)int_value );
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "|%03d|%03d|%03d|%03d| ", (value->r), (value->g), (value->b), (value->t) );

		if ( is_alphabet(col->r) == 1 ) if ( debug_print_msg_param () == 1 ) fprintf(fp,"|%03c|", col->r );
		else if ( debug_print_msg_param () == 1 ) fprintf(fp,"|%03d|", col->r );
		if ( is_alphabet(col->g) == 1 ) if ( debug_print_msg_param () == 1 ) fprintf(fp,"%03c|", col->g );
		else if ( debug_print_msg_param () == 1 ) fprintf(fp,"%03d|", col->g );
		if ( is_alphabet(col->b) == 1 ) if ( debug_print_msg_param () == 1 ) fprintf(fp,"%03c|", col->b );
		else if ( debug_print_msg_param () == 1 ) fprintf(fp,"%03d|", col->b );
		if ( is_alphabet(col->t) == 1 ) if ( debug_print_msg_param () == 1 ) fprintf(fp,"%03c|\r\n", col->t );
		else if ( debug_print_msg_param () == 1 ) fprintf(fp,"%03d|\r\n", col->t );
		cur++;
	}

	if ( debug_print_msg_param () == 1 ) fprintf(fp,"|%d|%c| -> |%d|%c|\r\n", 'A', 'A', 'z', 'z' );

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int File_Print_Function (char* file_name, int* point_func, int num, int max ) ends.\r\n");
	return 0;
}
// |65|A| -> |122|z|

// 	p_jackson->canvas_focus.width = 640;
//	p_jackson->canvas_focus.height = 480;
//
// press l -> n
//
int Full_Box1 ( int x1, int y1, int width, int height)  {
	int a, i, j;
	RGBT* col;
	FILE* fp;

	if ( debug_print_msg_param () == 1 ) printf("int Full_Box1 ( int x1, int y1, int width, int height) starts.\r\n");

	a = Initialize_Full_Box_Ifnot ();
	if ( a < 0 ) return a;

	if ( debug_print_msg == 1 ) {
		fp = fopen(p_jackson->asm_filename_name, "wb");
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "func|%p|param|%p|%p|%p|%p|debug_print_msg|%p|\r\n", p_jackson->Full_Box1, &x1, &y1, &width, &height, &debug_print_msg );
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "p_jackson->canvas[0][0]|%p| p_jackson->canvas[%d][%d]|%p|\r\n", &(p_jackson->canvas[0][0]), p_jackson->canvas_focus.width, p_jackson->canvas_focus.height, &(p_jackson->canvas[p_jackson->canvas_focus.width - 1][p_jackson->canvas_focus.height - 1]) );
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "type_print_msg|%p|v|%d|\r\n", &type_print_msg, type_print_msg );

		i = (int) (int*)&x1;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "x1|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );
		i = (int) (int*)&y1;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "y1|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );
		i = (int) (int*)&width;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "width|%03d|%03d|%03d|%03d\r\n", col->r, col->g, col->b, col->t );
		i = (int) (int*)&height;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "height|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );
		i = (int) (int*)&p_jackson->canvas[0][0];
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "p_jackson->canvas[0][0]|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );

		i = (int) (int*)&debug_print_msg;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "debug_print_msg|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );

		i = (int) (int*)&type_print_msg;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "type_print_msg|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );

		i = (int) (int*)&p_jackson->fore_ground_colour;
		col = (RGBT*) &i;
		if ( debug_print_msg_param () == 1 ) fprintf( fp, "p_jackson->fore_ground_colour|%03d|%03d|%03d|%03d|\r\n", col->r, col->g, col->b, col->t );
		fclose( fp );
	}

	col = (RGBT*) &(p_jackson->fore_ground_colour);

	for ( j=0; j<height; j++ )
	for ( i=0; i<width; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("(%d,%d) = (%d,%d,%d)\r\n", x1 +i, y1 +j, col->r, col->g, col->b);
		p_jackson->canvas[x1 + i][y1 + j] = (int)*((int*) (col));
	}
	if ( debug_print_msg_param () == 1 ) printf("int Full_Box1 ( int x1, int y1, int width, int height) ends.\r\n");
	return 0;
}

//
int Full_Box2 ( int x1, int y1, int width, int height)  {
	int a, i, j;
	RGBT* col;
	if ( debug_print_msg_param () == 1 ) printf("int Full_Box2 ( int x1, int y1, int width, int height) starts.\r\n");

	a = Initialize_Full_Box_Ifnot ();
	if ( a < 0 ) return a;

	col = (RGBT*) &(p_jackson->fore_ground_colour);

	if ( debug_print_msg_param () == 1 ) printf("x %d y %d w %d h %d\r\n", x1, y1, width, height);

	for ( j=y1 + height; j>=y1; j-- )
	for ( i=x1 + width; i>=x1; i--) {
		if ( debug_print_msg_param () == 1 ) printf("(%d,%d) = (%d,%d,%d)\r\n", i, j, col->r, col->g, col->b);
		p_jackson->canvas[i][j] = (int)*((int*) (col));
	}

	if ( debug_print_msg_param () == 1 ) printf("int Full_Box2 ( int x1, int y1, int width, int height) ends.\r\n");
	return 0;
}

// log_001
//
int Initialize_Full_Box_Ifnot () {
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int Initialize_Full_Box_Ifnot () starts.\r\n");

	// initialized already.
	if ( p_jackson->initialized == 1 ) {
		if ( debug_print_msg_param () == 1 ) printf("int Initialize_Full_Box_Ifnot () p_jackson->initialized |%d| return 1.\r\n", p_jackson->initialized);
		return 1;
	}

	p_jackson = (ANIMATION_FOCUS_FRAME*) get_jackson_pointer_animation_thread ();
	a = Set_Param_005a_log (&log_001);
	a = set_log_001_jackson_animation( &log_001 ); 
	a = Random_Work_Param () ;
	a = Check_Initialize_Param ();
	a = initialize_ppm_fonts ();
	a = Set_Background_Colour_Rgb ( 255, 128, 128 );
	a = initialize_canvas ();
	a = Set_Background_Colour_Rgb ( 223, 223, 223 );
	a = Set_Background_Rect ( 330, 190, 300, 160 ) ;
	a = set_focus ( 320, 180, 320, 180 );
	a = Set_Grid_Colour_Rgb ( 255, 64, 64 );
	a = p_jackson->draw_grid();
	a = Set_Support_Number_001 (52);
	a = set_number();
	a = set_font_rasio( 0.8 );
	a = Set_Font_Pix_Scale ( 30 );
	a = set_font_background( 1 );
	a = Set_Font_Colour_Rgb ( 0, 0, 128 );
	a = Set_Font_Draw_Left_Top ( 440, 270 );
	a = Draw_Jackson_Focus_Number();
	p_jackson->initialized = 1;

	if ( debug_print_msg_param () == 1 ) printf("int Initialize_Full_Box_Ifnot () ends.\r\n");
	return 0;
}

// 20240918
int is_alphabet(char c) {

	// |65|A| -> |122|z|
	if ( c >='A' && c <='z' ) return 1;

	return 0;
}

// 20240918
int is_start(char c1, char c2) {
	if ( c1 == c2 ) return 1;
	return 0;
}

// 20240918
// char* result;
//
// a = is_end( fp, i, file_end,']', &result, &ii ) ;
//
int is_end (FILE* fp, int start, int file_end, char c, char** result, int* end) {
	int i;
	char c2;
	char dummy[255];
	char put_dummy[4];
	char *str_result = NULL;

	if ( debug_print_msg_param () == 1 ) printf("int is_end (FILE* fp, int start, int file_end, char c, char** result, int* end) starts.\r\n");

	for ( i = start; i<file_end; i++ ) {
		fread( dummy, 1, 1, fp );
		c2 = dummy[0];
		if ( c == c2 ) {
			*end = i;
			*result = (char*)str_result;
			if ( debug_print_msg_param () == 1 ) printf("end char|%c| end %d\r\n", c2, *end);
			if ( debug_print_msg_param () == 1 ) printf("return result |%s| end_index %d\r\n", (char*) *result, *end );
			if ( debug_print_msg_param () == 1 ) printf("int is_end (FILE* fp, int start, int file_end, char c, char** result, int* end) return 1.\r\n");
			return 1;
		}
		put_dummy[0] = c2;
		put_dummy[1] = 0;
		str_result = m_concat (str_result, put_dummy);
		if ( debug_print_msg_param () == 1 ) printf("i %d / %d c|%c| %s |\r\n", i, file_end, c2, str_result );
	}

	*result = (char*)str_result;
	*end = i;

	if ( debug_print_msg_param () == 1 ) printf("return result |%s| end_index %d\r\n", (char*) *result, *end );
	if ( debug_print_msg_param () == 1 ) printf("int is_end (FILE* fp, int start, int file_end, char c, char** result, int* end) ends.\r\n");
	exit(-1);
	return 0;
}


// 20241111
// char* result;
//
// a = is_end_str( fp, i, file_end, "", &result, &ii ) ;
//
int is_end_str (FILE* fp, int start, int file_end, char* str, char** result, int* end) {
	int i;
	char c2;
	char dummy[255];
	char* str_result = NULL;
	int num_str = 0;
	aToken iToken;
	char* a_token = NULL;

	if ( debug_print_msg_param () == 1 ) printf("int is_end_str (FILE* fp, int start, int file_end, char* str, char** result, int* end) starts.\r\n");

	num_str = array_count ( str );

	for ( i = start; i<file_end; i++ ) {
		fread( dummy, 1, 1, fp );
		c2 = dummy[0];
		a_token = (char*) iToken.put_token( c2 ) ;

		if ( iToken.last_token( (char*) str ) == 1 ) {
			*end = i;
			*result = (char*)str_result;
			if ( debug_print_msg_param () == 1 ) printf("end str|%s| end %d\r\n", dummy, *end);
			if ( debug_print_msg_param () == 1 ) printf("return result |%s| end_index %d\r\n", (char*) *result, *end );
			if ( debug_print_msg_param () == 1 ) printf("int is_end_str (FILE* fp, int start, int file_end, char* str, char** result, int* end) return 1.\r\n");
			return 1;
		}

		if ( debug_print_msg_param () == 1 ) printf("i %d / %d c|%c| %s |\r\n", i, file_end, c2, str_result );
	}

	*result = (char*)str_result;
	*end = i;

	if ( debug_print_msg_param () == 1 ) printf("return result |%s| end_index %d\r\n", (char*) *result, *end );
	if ( debug_print_msg_param () == 1 ) printf("int is_end_str (FILE* fp, int start, int file_end, char* str, char** result, int* end) ends.\r\n");

	exit(-1);
	return 0;
}


// l -> m
// 20240917
int Load_Inifile_Jackson ( ) {
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int Load_Inifile_Jackson ( ) starts.\r\n");

	if ( p_jackson ==NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("int Load_Inifile_Jackson ( ) return -1.\r\n");
		return -1;
	}

	a = Read_Inifile_Jackson (p_jackson->ini_filename_name);

	if ( debug_print_msg_param () == 1 ) printf("int Load_Inifile_Jackson ( ) ends.\r\n");
	return 0;
}

//
// https://en.wikipedia.org/wiki/Bracket
//
// 20240917
int Read_Inifile_Jackson (char* inifile) {
	FILE *fp;
	int i;
	char dummy[255];
	char c;
	int a;
	int file_end;
	char* result;
	int ii;
	int mode;
	if ( debug_print_msg_param () == 1 ) printf("int Read_Inifile_Jackson (char* inifile) starts.\r\n");

	fp = fopen(inifile, "rb");
	file_end = filesize_004 (fp);
	mode = 0;

	if ( debug_print_msg_param () == 1 ) printf("%s| file_end %d\r\n", inifile, file_end );

	for ( i =0; i<file_end; i++ ) {	
		if ( mode == 0 ) {
			fread( dummy, 1, 1, fp );
			c = dummy[0];
			dummy[1] = '\0';
			if ( debug_print_msg_param () == 1 ) printf("c|%c|\r\n", c );
		}

		if ( mode == 2 ) {
			if ( debug_print_msg_param () == 1 ) printf("mode %d c|%c| -> ", mode, c );
			mode = 0; // c='['
			if ( debug_print_msg_param () == 1 ) printf("mode %d c|%c|", mode, c );
			if ( debug_print_msg_param () == 1 ) printf(" ---> O.K.\r\n");
			if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		}

		if ( mode == 0 && is_start( c, '[') == 1 ) {
			a = is_end( fp, i, file_end,']', &result, &ii ) ;
			if ( debug_print_msg_param () == 1 ) printf("result|%s|\r\n", (char*)result);
			ini_block_stack ( (char*)result );
			mode = 1;
			continue;
		}

		if ( mode == 1 ) {
			a = block_analysis ( fp, i, file_end, &result, &i);
			if ( a == 2 ) {
				mode = 2;  // c='['
				if ( debug_print_msg_param () == 1 ) printf("mode %d c|%c|", mode, c );
				if ( debug_print_msg_param () == 1 ) printf(" ---> O.K.\r\n");
			}
		}

	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int Read_Inifile_Jackson (char* inifile) ends.\r\n");
	return 0;
}


//
int block_analysis_sets (FILE* fp, int start, int file_end,  char** result, int* end, char*** h_name, char*** h_value, int* max_index, int* index ) {
	int i;
	char dummy[255];
	char c;
	int a;
	int ii;
	char* param;
	aToken iToken;
	char* a_token = NULL;
	int mode = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_sets (FILE* fp, int start, int file_end,  char** result, int* end, char*** h_name, char*** h_value ) starts.\r\n");

	if ( *max_index == 0 || h_name[0] == NULL || h_value[0] == NULL ) {
		*max_index = 8;
		*index = 0;
		h_name[0] = (char**) malloc (sizeof(char* ) * *max_index );
		h_value[0] = (char**) malloc (sizeof(char* ) * *max_index );
	}
	
	if ( h_name[0] == NULL || h_value[0] == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("h_value[0] and h_name[0] are not.\r\n");
		exit(-1);
	}

	for( i = *index; i< *max_index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("param[%d]=", i );
		h_name[0][i] = null_error;
		h_value[0][i] = null_error;
		if ( debug_print_msg_param () == 1 ) printf("|%s|%s|\r\n", (char*)h_name[0][i], (char*)h_value[0][i] );
	}

	for ( i = start; i<file_end; i++ ) {
		fread( dummy, 1, 1, fp );
		c = dummy[0];
		dummy[1] = '\0';
		if ( debug_print_msg_param () == 1 ) printf("c|%c|\r\n", c );

		if ( c == '[' ) {
			if ( debug_print_msg_param () == 1 ) printf("c|%c| , so, return 2.\r\n", c);
			*end = i;
			if ( debug_print_msg_param () == 1 ) printf("int block_analysis_sets (FILE* fp, int start, int file_end,  char** result, int* end, char*** h_name, char*** h_value, int* max_index, int* index ) return 2.\r\n");
			return 2;
		}

		if ( mode == 0 && is_alphabet ( c ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("c:|%c|\r\n", c );
			a = is_end( fp, i, file_end, '=', &param, &ii ) ;
			param = m_concat ( dummy, param); // c is as same as dummy[0].
			param = m_trim (param);
			mode = 1;
			if ( debug_print_msg_param () == 1 ) printf("Param|%s|\r\n", (char*)param);
			if ( debug_print_msg_param () == 1 ) printf("Param|%s|\r\n", (char*)param);
			continue;
		}

		if ( mode == 1 )
			a_token = (char*) iToken.put_token( c ) ;

		if ( mode == 1 && iToken.last_token( (char*) "\r\n" ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("Value|%s|\r\n", (char*)a_token);
			a = block_analysis_display_colour_sets_extract ( (char*)a_token, (char*)param, &h_name[0], &h_value[0], index, max_index , result );
			iToken.clear_token();
			mode = 0;
		}


	}
	*end = i;
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_sets (FILE* fp, int start, int file_end,  char** result, int* end, char*** h_name, char*** h_value, int* max_index, int* index ) ends.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("block_analysis_sets return 0.\r\n");
	return 0;
}


// int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* max_index ) ;
//
// hash
int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index , char** result) {
	int i = 0;
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index ) starts.\r\n");

	a = block_analysis_display_colour_sets_extract_print ( line_token, param, h_name, h_value, index, max_index, result );

	if ( *max_index <= *index ) {
		if ( debug_print_msg_param () == 1 ) printf("reallocation -> From %d to %d\r\n", *index, *max_index );
		if ( *max_index == 0 ) *max_index = 8;
		else *max_index *= 2;

		if ( debug_print_msg_param () == 1 ) printf("reallocation -> From %d to %d h_name[0]|%p| h_value[0]|%p|\r\n", *index, *max_index, h_name[0] , h_value[0]);
		h_name[0] = (char**) realloc ( (char**) h_name[0], (*max_index) * sizeof(char*) );
		h_value[0] = (char**) realloc((char**) h_value[0], (*max_index) * sizeof(char*) );
		if ( debug_print_msg_param () == 1 ) printf("O.K.\r\n");

		if ( debug_print_msg_param () == 1 ) printf("print array from %d to %d -> \r\n", (*index), (*max_index));
		if ( debug_print_msg_param () == 1 ) printf("|%p|%p| -> \r\n", (char**)h_name[0], (char**)h_value[0] );

		for( i = (*index); i< (*max_index); i++ ) {
			h_name[0][i] = null_error;
			h_value[0][i] = null_error;
			if ( debug_print_msg_param () == 1 ) printf ("param[%d]|%s|%s|\r\n", i, (char*)h_name[0][i], (char*)h_value[0][i] );
		}

		for( i = 0; i< (*index); i++ ) {
			if ( debug_print_msg_param () == 1 ) printf ("param[%d]|%s|%s|\r\n", i, (char*)h_name[0][i], (char*)h_value[0][i] );
		}

		if ( debug_print_msg_param () == 1 ) printf("O.K.\r\n");
	}

	h_name[0][(*index)] = copyof_012(param);
	h_value[0][(*index)] = copyof_012(line_token);
	(*index)++;


	a = block_analysis_display_colour_sets_extract_print ( line_token, param, h_name, h_value, index, max_index, result );

	if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
	if ( debug_print_msg_param () == 1 ) printf(" ---> O.K.\r\n");
	if ( debug_print_msg_sleep () == 1 ) Sleep(250);

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index ) ends.\r\n");
	return 0;
}

// hash
int block_analysis_display_colour_sets_extract_org1 (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_inde, char** result ) {
	int i = 0;
	int a;
	char** ch_name;
	char** ch_value;
/*
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index ) starts.\r\n");

	a = block_analysis_display_colour_sets_extract_print ( line_token, param, h_name, h_value, index, max_index, result );

	ch_name = h_name[0];
	ch_value = h_value[0];

	if ( *max_index <= *index ) {
		if ( debug_print_msg_param () == 1 ) printf("reallocation -> From %d to %d\r\n ", *max_index, *index );
		if ( *max_index == 0 ) *max_index = 8;
		else *max_index *= 2;

		if ( debug_print_msg_param () == 1 ) printf("reallocation -> From %d to %d\r\n ", *max_index, *index );
		ch_name = (char**) realloc ( ch_name, (*max_index) * sizeof(char*) );
		ch_value = (char**) realloc ( ch_value, (*max_index) * sizeof(char*) );
		if ( debug_print_msg_param () == 1 ) printf("O.K.\r\n");

		if ( debug_print_msg_param () == 1 ) printf("print array from %d to %d -> \r\n", (*index), (*max_index));
		if ( debug_print_msg_param () == 1 ) printf("|%p|%p| -> \r\n", (char**)ch_name, (char**)ch_value );

		for( i = (*index); i< (*max_index); i++ ) {
			ch_name[i] = null_error;
			ch_value[i] = null_error;
			if ( debug_print_msg_param () == 1 ) printf ("param[%d]|%s|%s|\r\n", i, (char*)ch_name[i], (char*)ch_value[i] );
		}

		for( i = 0; i< (*index); i++ ) {
			if ( debug_print_msg_param () == 1 ) printf ("param[%d]|%s|%s|\r\n", i, (char*)ch_name[i], (char*)ch_value[i] );
		}

		if ( debug_print_msg_param () == 1 ) printf("O.K.\r\n");
	}

	h_name[0] = ch_name;
	h_value[0]= ch_value;

	// Not *index but (*index)
	// *index -> (*index)
	if ( debug_print_msg_param () == 1 ) printf("setvalue index %d ", *index);
	if ( debug_print_msg_param () == 1 ) printf("|%p|%p| -> ", (char**)ch_name, (char**)ch_value );
	if ( debug_print_msg_param () == 1 ) printf("|%p|%p| -> ", (char**)h_name[0], (char**)h_value[0] );
	if ( debug_print_msg_param () == 1 ) printf("|%s|%s| -> ", (char*)ch_name[(*index)] , (char*)ch_value[(*index)] );
	if ( debug_print_msg_param () == 1 ) printf("O.K.\r\n");

	ch_name[(*index)] = copyof_012(param);
	ch_value[(*index)] = copyof_012(line_token);

	if ( debug_print_msg_param () == 1 ) printf("|%p|%p| -> ", (char**)&h_name[0][(*index)], (char**)&h_value[0][(*index)] );
	if ( debug_print_msg_param () == 1 ) printf("O.K.\r\n");

	(*index)++;

	a = block_analysis_display_colour_sets_extract_print ( line_token, param, h_name, h_value, index, max_index, result );

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets_extract (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index ) ends.\r\n");
*/
	return 0;
}



//
int block_analysis_display_colour_sets_extract_print (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index, char** result) {
	int i = 0;
	char* c_name;
	char* c_value;
	char** ch_name;
	char** ch_value;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets_extract_print (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index )  starts.\r\n");

	ch_name = h_name[0];
	ch_value = h_value[0];

	if ( debug_print_msg_param () == 1 ) printf( "|%p|%p|%p|%p|%p|%p|", line_token, param, h_name, h_value, index, max_index);
	if ( debug_print_msg_param () == 1 ) printf( " -> |%s|%s|%p|%p|index %d|max_index %d|\r\n", line_token, param, h_name, h_value, *index, *max_index);
	if ( debug_print_msg_param () == 1 ) printf( " -> |%p|%p|\r\n", ch_name, ch_value );
	if ( debug_print_msg_param () == 1 ) printf( " -> |%p|%p|\r\n", h_name[0], h_value[0] );
	if ( debug_print_msg_param () == 1 ) printf( " -> result: |%s|\r\n", *result);

	for( i = 0; i<*max_index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("param[%d]", i );
		c_name = (char*)h_name[0][i];
		c_value = (char*)h_value[0][i];
		if ( debug_print_msg_param () == 1 ) printf ("|%s|%s|\r\n", (char*)c_name, (char*)c_value );
	}

	if ( debug_print_msg_param () == 1 ) printf(" -> O.K.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets_extract_print (char* line_token, char* param, char*** h_name, char*** h_value, int* index, int* max_index )  ends.\r\n");

	return 0;
}

int block_analysis_display_colour_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) {
	int i, a;
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) starts.\r\n");

	for ( i=0; i<*index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("analyze handle[%d]:\r\n|%s|\r\n", i, h_name[0][i] );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		if ( m_compare( "Back_Ground_Colour", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			a = set_rgbt_colour ( (char*) h_value[0][i], &p_jackson->back_ground_colour);
			if ( debug_print_msg_param () == 1 ) printf("\=|%s| index %d/%d\r\n", h_value[0][i], i, *index);
		} else if ( m_compare( "Fore_Ground_Colour", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			a = set_rgbt_colour ( (char*) h_value[0][i], &p_jackson->fore_ground_colour);
			if ( debug_print_msg_param () == 1 ) printf("\=|%s| index %d/%d\r\n", h_value[0][i], i, *index);
		} else if ( m_compare( "Circle_r", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			a = set_circle_r ( (char*) h_value[0][i], &p_jackson->circle_r );
			if ( debug_print_msg_param () == 1 ) printf("\=|%s| index %d/%d circle_r %f\r\n", h_value[0][i], i, *index, p_jackson->circle_r);
		}

	}

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ends.\r\n");
	return 0;
}

int set_circle_r ( char* value, double* circle_r ) {
	int a, ac;
	char* an;

	a = m_last_with ( value, (char*) "\r\n");
	if ( a > 0 ) {
		ac = array_count(value);
		an = m_substring( value, 0, ac -2 );
	} else {
		an = value;
	}

	*circle_r = m_atof(an);

	if ( debug_print_msg_param () == 1 ) printf("circle_r|%p|=%f\r\n", circle_r, *circle_r);
	return 0;
}

//
int set_rgbt_colour ( char* value, RGBT* col) {
	int ac, i;
	char c;
	aToken itoken;
	char* a_token = NULL;
	int cnt = 0;
	char* an;
	int num;

	if ( debug_print_msg_param () == 1 ) printf("int set_rgbt_colour ( char* value, RGBT* col) starts.\r\n");

	ac = array_count (value);
	for ( i = 0; i<ac; i++ ) {
		c = value[i];
		a_token = (char*) itoken.put_token(c) ;
		switch(c){
		case '<':
			if ( debug_print_msg_param () == 1 ) printf("|%s|\r\n", a_token);
			itoken.clear_token();
			break;
		case '>':
			num = array_count(a_token);
			an = m_substring( a_token, 0, num -1 );
			if ( debug_print_msg_param () == 1 ) printf ("cnt %d |%s|\r\n", cnt, an);
			switch(cnt) {
			case 2:
				col->b = atoi(an);
				break;
			case 3:
				col->t = atoi(an);
				break;
			}
			i = ac; //end
			itoken.clear_token();
			break;
		case '\,':
			num = array_count(a_token);
			an = m_substring( a_token, 0, num -1 );
			if ( debug_print_msg_param () == 1 ) printf ("cnt %d |%s|\r\n", cnt, an);
			switch(cnt) {
			case 0:
				col->r = m_atoi(an);
				break;
			case 1:
				col->g = m_atoi(an);
				break;
			case 2:
				col->b = m_atoi(an);
				break;
			}
			cnt++;		
			itoken.clear_token();
			break;
		}
	}
	print_rgbt_colour (col);

	if ( debug_print_msg_param () == 1 ) printf("int set_rgbt_colour ( char* value, RGBT* col) ends.\r\n");

	return 0;
}


//
double m_atof(char* str) {
	int ac, i;
	char c;
	char* c_str =NULL;
	if ( debug_print_msg_param () == 1 ) printf ("int m_atof(char* str) starts.\r\n");
	c_str = (char*) m_trim(str);
	ac = array_count (c_str);
	if ( debug_print_msg_param () == 1 ) printf("|%s| to cnt %d\r\n", c_str, ac);
	for ( i=0; i<ac; i++ ){
		c = c_str[i];
		if ( debug_print_msg_param () == 1 ) printf("|%c| i %d\r\n", c, i);
	}

	if ( debug_print_msg_param () == 1 ) printf ("int m_atof(char* str) ends.\r\n");
	return atof(c_str);
}

//
int m_atoi(char* str) {
	int ac, i;
	char c;
	char *c_str =NULL;
	if ( debug_print_msg_param () == 1 ) printf ("int m_atoi(char* str) starts.\r\n");
	c_str = (char*) m_trim(str);
	ac = array_count (c_str);
	for ( i=0; i<ac; i++ ){
		c = c_str[i];
		if ( debug_print_msg_param () == 1 ) printf("|%c| i %d\r\n", c, i);
		if ( is_number_a(c) == -1 ) {
			exit(-1);
		}
	}

	if ( debug_print_msg_param () == 1 ) printf ("int m_atoi(char* str) ends.\r\n");
	return atoi(str);
}


// is_number is in numbering.cpp
//
int is_number_a (char c) {
	if ( '0' <=c && c <= '9' ) return 1;

	return -1;
}


int print_rgbt_colour (RGBT* col) {
	if ( debug_print_msg_param () == 1 ) printf("rgbt %d %d %d %d\r\n", col->r, col->g, col->b, col->t);
	return 0;
}


int block_analysis_setup_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) {
	int i, a;
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_setup_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("index %d\r\n", *index);

	for ( i=0; i<*index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("analyze handle[%d]:\r\n|%s|\r\n", i, h_name[0][i] );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		if ( m_compare( "aaaa", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
		} else if ( m_compare( "menu_stack_code_filename_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->menu_stack_code_filename_name = m_trim_file_name ( h_value[0][i] );
		} else if ( m_compare( "menu_filename_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->menu_filename_name = m_trim_file_name ( h_value[0][i] );
		} else if ( m_compare( "menu_stack_print_filename_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->menu_stack_print_filename_name = m_trim_file_name ( h_value[0][i] );
		} else if ( m_compare( "font_filename_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->font_filename_name = m_trim_file_name ( h_value[0][i] );
		}

	}

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_setup_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ends.\r\n");
	return 0;
}


// 20250924
int block_analysis_project_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) {
	int i, a;
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_project_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("index %d\r\n", *index);

	for ( i=0; i<*index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("analyze handle[%d]:\r\n|%s|\r\n", i, h_name[0][i] );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		if ( m_compare( "aaaa", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
		} else if ( m_compare( "project_directory_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->project_directory_name = m_trim_file_name ( h_value[0][i] );
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_project_fie_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ends.\r\n");
	return 0;
}

// 20250924
int block_analysis_work_directory_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) {
	int i, a;
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_work_directory_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("index %d\r\n", *index);

	for ( i=0; i<*index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("analyze handle[%d]:\r\n|%s|\r\n", i, h_name[0][i] );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		if ( m_compare( "aaaa", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
		} else if ( m_compare( "work_directory_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->work_directory_name = m_trim_file_name ( h_value[0][i] );
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_work_directory_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ends.\r\n");
	return 0;
}



char* m_trim_file_name (char* str_filename ) {
	int number;
	char* str2 = NULL;
	char** match = NULL;
	int i;

	str2 = to_semmi_colon (str_filename);
	match = split( str2, '"', &number );

	if ( number <= 0 ) exit(-1);
	for ( i = 0; i<number; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("|%d|%s|\r\n", i, match[i] );
	}
	
	return match[1];
}

//
char* to_semmi_colon (char* str_filename ) {
	int number;
	char** match = NULL;

	match = split( str_filename, ';', &number );

	return match[0];
}





int block_analysis_rasio_value_sets (char*** h_name, char*** h_value, int* index, int* max_index) {
	int i, a;
	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_rasio__value_sets (char*** h_name, char*** h_value, int* index, int* max_index) starts.\r\n");

	for ( i=0; i<*index; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("analyze handle[%d]:\r\n|%s|\r\n", i, h_name[0][i] );
		if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
		if ( m_compare( "aaaa", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
		} else if ( m_compare( "menu_stack_code_filename_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->menu_stack_code_filename_name = h_value[0][i];
		} else if ( m_compare( "menu_filename_name", h_name[0][i] ) == 1 ) {
			if ( debug_print_msg_param () == 1 ) printf("\=|%s|\r\n", h_value[0][i]);
			p_jackson->menu_filename_name = h_value[0][i];
		}

	}

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_rasio__value_sets (char*** h_name, char*** h_value, int* index, int* max_index) ends.\r\n");
	return 0;
}

//
int block_analysis_display_colour_sets (FILE* fp, int start, int file_end,  char** result, int* end) {
	int a, b;
	char** h_name;
	char** h_value;
	int index = 0;
	int max_index = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets (FILE* fp, int start, int file_end,  char** result, int* end) starts.\r\n");

	// 20241209
	a = block_analysis_sets ( fp, start, file_end, result, end, &h_name, &h_value, &max_index, &index );

	if ( debug_print_msg_sleep () == 1 ) Sleep(3000);
	b = block_analysis_display_colour_value_sets ( &h_name, &h_value, &index, &max_index );

//	if ( debug_print_msg_param () == 1 ) printf ("block_analysis_sets exit(-1)\r\n");
//	exit(-1);

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_display_colour_sets (FILE* fp, int start, int file_end,  char** result, int* end) returns %d. \r\n", a);
	return a;
}

//
int block_analysis_rasio_sets (FILE* fp, int start, int file_end,  char** result, int* end) {
	int a, b;
	char** h_name;
	char** h_value;
	int index = 0;
	int max_index = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_rasio_sets (FILE* fp, int start, int file_end,  char** result, int* end) starts.\r\n");

	a = block_analysis_sets ( fp, start, file_end, result, end, &h_name, &h_value, &index, &max_index );

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_rasio_sets (FILE* fp, int start, int file_end,  char** result, int* end) returns %d. \r\n", a);
	return a;
}

//
int block_analysis_setup_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) {
	int a, b;
	char** h_name;
	char** h_value;
	int index = 0;
	int max_index = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_setup_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) starts.\r\n");

	a = block_analysis_sets ( fp, start, file_end, result, end, &h_name, &h_value, &index, &max_index );
	// 20241220
	b = block_analysis_setup_fie_value_sets ( &h_name, &h_value, &index, &max_index );


	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_setup_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) returns %d. \r\n", a);

	return a;
}


//
int block_analysis_project_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) {
	int a, b;
	char** h_name;
	char** h_value;
	int index = 0;
	int max_index = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_project_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) starts.\r\n");

	a = block_analysis_sets ( fp, start, file_end, result, end, &h_name, &h_value, &index, &max_index );

	// 20250924
	b = block_analysis_project_fie_value_sets ( &h_name, &h_value, &index, &max_index );

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_project_fie_sets (FILE* fp, int start, int file_end,  char** result, int* end) returns %d. \r\n", a);

	return a;
}

//
int block_analysis_work_directory_sets (FILE* fp, int start, int file_end,  char** result, int* end) {
	int a, b;
	char** h_name;
	char** h_value;
	int index = 0;
	int max_index = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_work_directory_sets (FILE* fp, int start, int file_end,  char** result, int* end) starts.\r\n");

	a = block_analysis_sets ( fp, start, file_end, result, end, &h_name, &h_value, &index, &max_index );

	// 20250924
	b = block_analysis_work_directory_value_sets ( &h_name, &h_value, &index, &max_index );

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis_work_directory_sets (FILE* fp, int start, int file_end,  char** result, int* end) returns %d. \r\n", a);

	return a;
}



//
int block_analysis (FILE* fp, int start, int file_end,  char** result, int* end) {
	int a;
	char** h_name;
	char** h_value;
	int index = 0;
	int max_index = 0;

	if ( debug_print_msg_param () == 1 ) printf("int block_analysis (FILE* fp, int start, int file_end,  char** result, int* end) starts.\r\n");

	*result = m_trim ( *result );
	if ( debug_print_msg_param () == 1 ) printf("trim result |%s|\r\n", *result );

	if ( m_compare( "Display Colour Sets", *result ) == 1 )  {
		a = block_analysis_display_colour_sets ( fp, start, file_end, result, end );
		return a;
	}

	if ( m_compare( "Rasio", *result  ) == 1 )  {
		a = block_analysis_rasio_sets ( fp, start, file_end, result, end );
		if ( debug_print_msg_param () == 1 ) printf("block_analysis_rasio_sets returns  %d\r\n", a );
		return a;
	}

	if ( m_compare( "Setup File", *result  ) == 1 )  {
		a = block_analysis_setup_fie_sets ( fp, start, file_end, result, end );
		if ( debug_print_msg_param () == 1 ) printf("block_analysis_fie_sets returns  %d\r\n", a );
		return a;
	}

	if ( m_compare( "Project File", *result  ) == 1 )  {
		a = block_analysis_project_fie_sets ( fp, start, file_end, result, end );
		if ( debug_print_msg_param () == 1 ) printf("block_analysis_project_fie_sets returns  %d\r\n", a );
		return a;
	}

	if ( m_compare( "Work Directory", *result  ) == 1 )  {
		a = block_analysis_work_directory_sets ( fp, start, file_end, result, end );
		if ( debug_print_msg_param () == 1 ) printf("block_analysis_work_directory_sets returns  %d\r\n", a );
		return a;
	}


	if ( debug_print_msg_param () == 1 ) printf("int block_analysis (FILE* fp, int start, int file_end,  char** result, int* end) ends.\r\n");
	return 0;
}

//
//
//
// type: 5
// type: 4
// type: 3
// type: 2
// type: 1
// type: 0
int draw_circle_line_to_fix1 ( double i, double j, float base, int skip, int type )  {
	int aa;

	if ( type > 4 )
		aa = draw_circle_line_to_003_Normal_05 ( (double) i, (double) j, (float) base, skip, type  - 4 ) ;
	else if ( type > 2 )
		aa = draw_circle_line_to_003_Normal ( (double) i, (double) j, (float) base, skip, type  - 2 ) ;
	else
		aa = draw_circle_line_to_003 ( (double) i, (double) j, (float) base, skip, type ) ;

	// type: 0
	// type: 1

	return 0;
}

//
// fore_ground_colour
int Get_Font_Colour ( RGBT *rgbt ) {
	if ( p_jackson ==NULL ) return -1;

	rgbt->r = p_jackson->fore_ground_colour.r;
	rgbt->g = p_jackson->fore_ground_colour.g;
	rgbt->b = p_jackson->fore_ground_colour.b;
	rgbt->t = p_jackson->fore_ground_colour.t;

	return 0;
}

/*
//
int Get_Background_Colour ( RGBT *rgbt ) {
	if ( p_jackson ==NULL ) return -1;

	rgbt->r = p_jackson->back_ground_colour.r;
	rgbt->g = p_jackson->back_ground_colour.g;
	rgbt->b = p_jackson->back_ground_colour.b;
	rgbt->t = p_jackson->back_ground_colour.t;

	return 0;
}
*/

/*
//
int Get_Background_Colour_Rgb ( unsigned char *r, unsigned char *g, unsigned char *b ) {

	return 0;
}
*/

//
int Get_Background_Colour ( RGBT *rgbt ) {
	if ( p_jackson ==NULL ) return -1;

	rgbt->r = p_jackson->back_ground_colour.r;
	rgbt->g = p_jackson->back_ground_colour.g;
	rgbt->b = p_jackson->back_ground_colour.b;
	rgbt->t = p_jackson->back_ground_colour.t;

	return 0;
}

//
int Get_Background_Colour_Rgb ( unsigned char *r, unsigned char *g, unsigned char *b ) {

	return 0;
}

//
//      p1
//
//    p2
//                p3
//
//
//
int Full_Square_01 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y2 ) / (double)( x3 - x2 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs ( a2 ) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs ( a2 ) > 1.0 ) flip = 0;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.0f a2 %0.0f length %0.3f\r\n", a1, a2, length);
//	exit(-1);

	switch (flip) {
	case 0:
		value = line_to_003_step_only_full_square ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only_full_square ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}


//
//      p1
//
//    p2
//                p3
//
//
//
int Full_Square ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y2 ) / (double)( x3 - x2 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs ( a2 ) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs ( a2 ) > 1.0 ) flip = 0;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.0f a2 %0.0f length %0.3f\r\n", a1, a2, length);
//	exit(-1);

	switch (flip) {
	case 0:
		value = line_to_003_step_only_full_square ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only_full_square ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}

//
//      p1
//
//    p2
//                p3
//
//
//
int Full_Square_Fix2 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y2 ) / (double)( x3 - x2 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs ( a2 ) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs ( a2 ) > 1.0 ) flip = 0;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.0f a2 %0.0f length %0.3f\r\n", a1, a2, length);
//	exit(-1);

	switch (flip) {
	case 0:
		value = line_to_003_step_only_full_square_fix2 ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only_full_square_fix2 ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}

//
//      p1
//
//    p2
//                p3
//
//
//
int Full_Square_Fix1 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;
	double fa1, fa2;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y1 ) / (double)( x3 - x1 );

	fa1 = a1;
	fa2 = a2;
	if ( fabs(a1) > 1.0 ) fa1 = 1.0/a1;
	if ( fabs(a2) > 1.0 ) fa1 = 1.0/a2;

	if ( fabs( a1 * a2 ) < 1.0 ) flip = 1;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.3f a2 %0.3f length %0.3f flip %d\r\n", a1, a2, length, flip);
//	exit(-1);

	// 20240903
	switch (flip) {
	case 0:
		value = line_to_003_step_only_full_square_fix1 ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only_full_square_fix1 ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}

//
//      p1
//
//    p2
//                p3
//
//
//
int Full_Square_Fix1_org ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y2 ) / (double)( x3 - x2 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs ( a2 ) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs ( a2 ) > 1.0 ) flip = 0;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.3f a2 %0.3f length %0.3f\r\n", a1, a2, length);
//	exit(-1);

	switch (flip) {
	case 0:
		value = line_to_003_step_only_full_square_fix1 ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only_full_square_fix1 ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}



//
//      p1
//
//    p2
//                p3
//
//
//
int Full_Square_Fix3 ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y2 ) / (double)( x3 - x2 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs ( a2 ) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs ( a2 ) > 1.0 ) flip = 0;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.0f a2 %0.0f length %0.3f\r\n", a1, a2, length);
//	exit(-1);

	switch (flip) {
	case 0:
		value = line_to_003_step_only_full_square_fix3 ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only_full_square_fix3 ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}



//
int stepwork_rasio_cursol ( double* i, double* j, float x1, float y1, float x2, float y2, double scale ) {
	double unit_slope, u1, v1;

	if ( debug_print_msg_param () == 1 ) printf("int stepwork_rasio_cursol ( double* i, double* j, float x1, float y1, float x2, float y2, double scale ) starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("scale %0.3f\r\n", scale);

	unit_slope = sqrt(x1*x1 + y1*y1);
	if ( debug_print_msg_param () == 1 ) printf("unit_slope %0.3f\r\n", unit_slope);

	u1 = x1 / unit_slope;
	v1 = y1 / unit_slope;

	if ( debug_print_msg_param () == 1 ) printf(" u, v -> %0.3f, %0.3f \r\n", u1, v1 );

	*i = u1 * scale + x2;
	*j = v1 * scale + y2;

	if ( debug_print_msg_param () == 1 ) printf("int stepwork_rasio_cursol ( double* i, double* j, float x1, float y1, float x2, float y2, double scale ) ends.\r\n");
	return 0;
}

//
//       p1
//
//    p2
//                  p3
//
//
//
//
//
double stepwork_rasio ( double i, double j, float x1, float y1, float x2, float y2, double* len2 ) {
	double len1, result;

	if ( debug_print_msg_param () == 1 ) printf("%0.3f %0.3f %0.3f %0.3f %0.3f %0.3f\r\n", i, j, x1, y1, x2, y2);

	len1 =  distance_to (  i,  j, x1, y1 ) ;
	*len2 = distance_to ( x1, y1, y2, y2 ) ;

	result = len1 / *len2;

	if ( debug_print_msg_param () == 1 ) printf("len1 %0.3f len2 %0.3f result %0.3f\r\n", len1, *len2, result );
	return result;
}


//
//       p1
//
//    p2
//                  p3
//
//
//
int Full_Triangle ( float x1, float y1, float x2, float y2, float x3, float y3, float base ) {
	double a1, a2, a3;
	int flip = 0;
	int value;
	double length;

	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );

	a2 = (double)( y3 - y2 ) / (double)( x3 - x2 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs ( a2 ) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs ( a2 ) > 1.0 ) flip = 0;

	// To full polygon p1, p2, and p3,
	// from shortest line p1 to longest one p2
	// the slope is from p2 to p3.
	// 

	length = distance_to ( x1, y1, x3, y3 );

	if ( debug_print_msg_param () == 1 ) printf("a1 %0.0f a2 %0.0f length\r\n", a1, a2, length);
//	exit(-1);

	switch (flip) {
	case 0:
		value = line_to_003_step_only ( x1, y1, x2, y2, a2, base, length);
		break;
	case 1:
		value = line_to_003_step_only ( x2, y2, x1, y1, a2, base, length);
		break;
	}

	return 1;
}

//
//
//
int line_to_003_step_only (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	flag = 0;
	power = 0;
	b_power = 0;
	i = x1;
	j = y1;
	cnt = 0;

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	//
	while(1) {

		t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
		aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length * ( 1.0 - t ) ) ;

		if ( debug_print_msg_param () == 1 ) printf(" i %0.3f, j %0.3f, cur_x %0.3f, cur_y %0.3f len %0.3f t %0.3f base %0.3f a %0.3f length %0.3f\r\n", i, j, cur_x, cur_y, len, t, base, a, length );

		if ( cnt != 0 && abs( b_power - power ) >= 1  ) {
			aa = Draw_Circle_Line ( i, j, cur_x, cur_y,  5.0, 1, 1 );
		} else {
			aa = Draw_Circle_Line ( i, j, cur_x, cur_y,  5.0, 1, 0 );
		}

		if (flag == 1 ) {
			j += base;
			i += a * base;
		} else {
			i += base;
			j += a * base;
		}

		b_power = power;
		if ( flag == 1 ) {
			power = (int)i;
		} else {
			power = (int)j;
		}
		cnt++;
		if ( cnt > 10 ) break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}


//
//
//
int line_to_003_step_only_full_square (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	int abs_pow, abs_base_pow;
	FILE *fp = NULL;
	double a_m_base;
	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	flag = 0;
	power = 0;
	b_power = 0;
	i = x1;
	j = y1;
	cnt = 0;

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	fp = fopen ( "001-line_to_003_step_only_full_square-001\.txt" ,"a" );

	if ( flag == 1 ) {
		power = (int)i;
	} else {
		power = (int)j;
	}
	b_power = power;
	a_m_base = a * base;

	//
	while(1) {

		t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
		aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length * ( 1.0 - t ) ) ;

		if ( debug_print_msg_param () == 1 ) printf(" i %0.3f, j %0.3f, cur_x %0.3f, cur_y %0.3f len %0.3f t %0.3f base %0.3f a %0.3f length %0.3f\r\n", i, j, cur_x, cur_y, len, t, base, a, length );

		abs_pow = abs( b_power - power );
		abs_base_pow = (int) ( (double)abs_pow/ (double)base);

		if ( debug_print_msg_param () == 1 ) fprintf( fp, "cnt|%4d| ( %4.3f, %4.3f ) -> ( %4.3f, %4.3f ) length %4.3f flag %2d b_power %d power %d abs_power %4d abs_base_power %4d\r\n", cnt, i, j, cur_x, cur_y, length, flag, b_power, power, abs_pow, abs_base_pow );

		if ( cnt != 0 && abs_base_pow >= 1  ) {
			if (flag == 1 ) {
				aa = Draw_Circle_Line ( (float)power, j, cur_x, cur_y,  5.0, 1, 1 );
			} else {
				aa = Draw_Circle_Line ( i, (float)power, cur_x, cur_y,  5.0, 1, 1 );
			}
		} else {
			if (flag == 1 ) {
				aa = Draw_Circle_Line ( (float)power, j, cur_x, cur_y,  5.0, 1, 0 );
			} else {
				aa = Draw_Circle_Line ( i, (float)power, cur_x, cur_y,  5.0, 1, 0 );
			}
		}

		if (flag == 1 ) {
			j += base;
			i += a_m_base;
		} else {
			i += base;
			j += a_m_base;
		}

		if ( abs_pow >= base) b_power = power;
		if ( flag == 1 ) {
			power = (int)i;
		} else {
			power = (int)j;
		}

		cnt++;
		if ( cnt > 10 ) break;
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}


//
//
int line_to_003_step_only_full_square_fix2 (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	int abs_pow, abs_base_pow;
	FILE *fp = NULL;
	double a_m_base;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix2 (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	flag = 0;
	power = 0;
	b_power = 0;
	i = x1;
	j = y1;
	cnt = 0;

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	fp = fopen ( "001-line_to_003_step_only_full_square_fraction_line-001\.txt" ,"a" );

	if ( flag == 1 ) {
		power = (int)i;
	} else {
		power = (int)j;
	}
	b_power = power;

	a_m_base = a * base;
	//
	while(1) {

		t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
		aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length ) ;

		if ( debug_print_msg_param () == 1 ) printf(" i %0.3f, j %0.3f, cur_x %0.3f, cur_y %0.3f len %0.3f t %0.3f base %0.3f a %0.3f length %0.3f\r\n", i, j, cur_x, cur_y, len, t, base, a, length );

		abs_pow = abs( b_power - power );
		abs_base_pow = (int) ( (double)abs_pow/ (double)base);

		if ( debug_print_msg_param () == 1 ) fprintf( fp, "cnt|%4d| ( %4.3f, %4.3f ) -> ( %4.3f, %4.3f ) length %4.3f flag %2d b_power %d power %d abs_power %4d abs_base_power %4d\r\n", cnt, i, j, cur_x, cur_y, length, flag, b_power, power, abs_pow, abs_base_pow );

		if ( cnt != 0 && abs_base_pow >= 1  ) {
			if (flag == 1 ) {
				aa = Draw_Circle_Line_Fraction ( (float)power, j, cur_x, cur_y,  5.0, 1, 1 );
			} else {
				aa = Draw_Circle_Line_Fraction ( i, (float)power, cur_x, cur_y,  5.0, 1, 1 );
			}
		} else {
			if (flag == 1 ) {
				aa = Draw_Circle_Line_Fraction ( (float)power, j, cur_x, cur_y,  5.0, 1, 0 );
			} else {
				aa = Draw_Circle_Line_Fraction ( i, (float)power, cur_x, cur_y,  5.0, 1, 0 );
			}
		}

		if (flag == 1 ) {
			j += base;
			i += a_m_base;
		} else {
			i += base;
			j += a_m_base;
		}

		if ( abs_pow >= base) b_power = power;
		if ( flag == 1 ) {
			power = (int)i;
		} else {
			power = (int)j;
		}

		cnt++;
		if ( cnt > 10 ) break;
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix2 (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}

// 20240903
//
int line_to_003_step_only_full_square_fix1_001 (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	int abs_pow, abs_base_pow;
	FILE *fp = NULL;
	double a_m_base, a1;
	int x_flip = 0;
	int first = 0;
	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix1_001 (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	// flag
	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );
	if ( fabs(a1) > 1.0 ) { flag = 1; a1 = 1.0 / a1; }

	i = x1;
	j = y1;

	// X flip
	if ( x2 < x1 ) x_flip = 1;
	if ( x_flip == 1 ) base *= -1.0;


	// Set
	first = 0;
	t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
	aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length ) ;

	// Set Power
	if ( flag == 1 ) 
		power = (int)i;
	else 
		power = (int)j;

	// flag draw
	// int Draw_Circle_Line_Power_Flag (float x1, float y1, float x2, float y2, float power, int flag, float bold, int type, int first_type ) ;
	aa = Draw_Circle_Line_Power_Flag ( i, j, cur_x, cur_y, (float)power, flag, base/2.0, 3, first );

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix1_001 (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}

//
//
int line_to_003_step_only_full_square_fix1 (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	int abs_pow, abs_base_pow;
	FILE *fp = NULL;
	double a_m_base, a1;
	int x_flip = 0;
	int y_flip = 0;
	int first = 0;
	double a_len, a_step, bottom_length;
	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix1 (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	flag = 0;
	power = 0;
	b_power = 0;
	i = x1;
	j = y1;
	cnt = 0;

	// a1
	a1 = (double)( y2 - y1 ) / (double)( x2 - x1 );
	if ( fabs(a1) > 1.0 ) { flag = 1; a1 = 1.0 / a1; }

	if ( x2 < x1 ) x_flip = 1;
	if ( y2 < y1 ) y_flip = 1;

	if ( flag == 0 && x_flip == 1 ) base *= -1.0;
	if ( flag == 1 && y_flip == 1 ) base *= -1.0;

	a_step = base;
	a_m_base = ( a1 * base );
	a_len = distance_to ( 0.0, 0.0, base, a_m_base );
	a_len *= 1.001;

	a_m_base /= a_len;
	a_step /=  a_len;

	a_m_base *= fabs(base);
	a_step *=  fabs(base);

	bottom_length = distance_to ( x1, y1, x2, y2 );

	fp = fopen ( "001-line_to_003_step_only_full_square-001\.txt" ,"w" );

	if ( flag == 1 ) {
		power = (int)i;
	} else {
		power = (int)j;
	}
	b_power = power;

	if ( debug_print_msg_param () == 1 ) fprintf( fp, "x_flip=%d y_flip=%d flag %d a_m_base %0.3f base %0.3f a1 %0.3f, bottom_length %0.3f\r\n", x_flip, y_flip, flag, a_m_base, base, a1, bottom_length );
	if ( debug_print_msg_param () == 1 ) fprintf( fp, "a_step %0.3f a_m_base %0.3f\r\n", a_step, a_m_base );
	if ( debug_print_msg_param () == 1 ) fprintf( fp, "(%0.3f, %0.3f) <- 1.(%0.3f, %0.3f) , 2.(%0.3f, %0.3f) \r\n", i, j, x1, y1, x2, y2 );

	//
	while(1) {

		// 20240902
		if ( x_flip == 0 &&  i > x2  ) break;
		if ( x_flip == 1 &&  i < x2  ) break;
		if ( y_flip == 0 &&  j > y2  ) break;
		if ( y_flip == 1 &&  j < y2  ) break;

		first = 0;
		t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
		aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length ) ;

		if ( debug_print_msg_param () == 1 ) printf(" i %0.3f, j %0.3f, cur_x %0.3f, cur_y %0.3f len %0.3f t %0.3f base %0.3f a %0.3f length %0.3f\r\n", i, j, cur_x, cur_y, len, t, base, a, length );

		abs_pow = abs( b_power - power );
		abs_base_pow = (int) ( (double)abs_pow/ (double)fabs(base));

		if ( cnt != 0 && abs_base_pow >= 1  )
			first = 1;

		// 20240903
//		aa = Draw_Circle_Line_Power_Flag ( i, j, cur_x, cur_y, (float)power, flag, base/2.0, 3, 0 );
//		aa = Draw_Circle_Line ( i, j, cur_x, cur_y,  fabs(base)/2.0, 3, 0 );
		// 20240904
		aa = Draw_Circle_Line_004 ( i, j, cur_x, cur_y,  fabs(base)/2.0, 0, first );

		if ( debug_print_msg_param () == 1 ) fprintf( fp, "cnt|%4d| ( %4.3f, %4.3f ) -> ( %4.3f, %4.3f ) first %d length %4.3f flag %2d b_power %d power %d abs_power %4d abs_base_power %4d\r\n", cnt, i, j, cur_x, cur_y, first, length, flag, b_power, power, abs_pow, abs_base_pow );

		if (flag == 1 ) {
			j += a_step;
			i += a_m_base;
		} else {
			i += a_step;
			j += a_m_base;
		}

		if ( abs_pow >= base) b_power = power;

		if ( flag == 1 ) {
			power = (int) ( i/ base ) * base ;
		} else {
			power = (int) ( j/ base ) * base ;
		}

		cnt++;
//		if ( cnt >= 12 ) break;
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix1 (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}

//
//
int line_to_003_step_only_full_square_fix3 (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	int abs_pow, abs_base_pow;
	FILE *fp = NULL;
	double a_m_base;
	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix3 (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	flag = 0;
	power = 0;
	b_power = 0;
	i = x1;
	j = y1;
	cnt = 0;

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	fp = fopen ( "001-line_to_003_step_only_full_square-001\.txt" ,"a" );

	if ( flag == 1 ) {
		power = (int)i;
	} else {
		power = (int)j;
	}
	b_power = power;
	a_m_base = a * base;

	//
	while(1) {

		t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
		aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length ) ;

		if ( debug_print_msg_param () == 1 ) printf(" i %0.3f, j %0.3f, cur_x %0.3f, cur_y %0.3f len %0.3f t %0.3f base %0.3f a %0.3f length %0.3f\r\n", i, j, cur_x, cur_y, len, t, base, a, length );

		abs_pow = abs( b_power - power );
		abs_base_pow = (int) ( (double)abs_pow/ (double)base);

		if ( debug_print_msg_param () == 1 ) fprintf( fp, "cnt|%4d| ( %4.3f, %4.3f ) -> ( %4.3f, %4.3f ) length %4.3f flag %2d b_power %d power %d abs_power %4d abs_base_power %4d\r\n", cnt, i, j, cur_x, cur_y, length, flag, b_power, power, abs_pow, abs_base_pow );

		if ( cnt != 0 && abs_base_pow >= 1  ) {
			if (flag == 1 ) {
				aa = Draw_Circle_Line ( (float)power, j, cur_x, cur_y,  base, 5, 1 );
			} else {
				aa = Draw_Circle_Line ( i, (float)power, cur_x, cur_y,  base, 5, 1 );
			}
		} else {
			if (flag == 1 ) {
				aa = Draw_Circle_Line ( (float)power, j, cur_x, cur_y,  base, 5, 0 );
			} else {
				aa = Draw_Circle_Line ( i, (float)power, cur_x, cur_y,  base, 5, 0 );
			}
		}

		if (flag == 1 ) {
			j += base;
			i += a_m_base;
		} else {
			i += base;
			j += a_m_base;
		}

		if ( abs_pow >= base) b_power = power;
		if ( flag == 1 ) {
			power = (int)i;
		} else {
			power = (int)j;
		}

		cnt++;
		if ( cnt > 10 ) break;
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square_fix3 (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}


//
//
//
int line_to_003_step_only_full_square_01 (float x1, float y1, float x2, float y2, double a, float base, float length ) {
	double i, j, t, len, cur_x, cur_y;
	int aa, power, b_power, cnt, flag;
	int abs_pow, abs_base_pow;
	FILE *fp = NULL;
	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square (float x1, float y1, float x2, float y2, double a, float base ) starts.\r\n");

	flag = 0;
	power = 0;
	b_power = 0;
	i = x1;
	j = y1;
	cnt = 0;

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	fp = fopen ( "001-line_to_003_step_only_full_square-001\.txt" ,"a" );

	if ( flag == 1 ) {
		power = (int)i;
	} else {
		power = (int)j;
	}
	b_power = power;

	//
	while(1) {

		t = stepwork_rasio ( i, j, x1, y1, x2, y2, &len ) ;
		aa = stepwork_rasio_cursol ( &cur_x, &cur_y, base, base * a, i, j, length * ( 1.0 - t ) ) ;

		if ( debug_print_msg_param () == 1 ) printf(" i %0.3f, j %0.3f, cur_x %0.3f, cur_y %0.3f len %0.3f t %0.3f base %0.3f a %0.3f length %0.3f\r\n", i, j, cur_x, cur_y, len, t, base, a, length );

		abs_pow = abs( b_power - power );
		abs_base_pow = (int) ( (double)abs_pow/ (double)base);

		if ( debug_print_msg_param () == 1 ) fprintf( fp, "cnt|%4d| ( %4.3f, %4.3f ) -> ( %4.3f, %4.3f ) length %4.3f flag %2d b_power %d power %d abs_power %4d abs_base_power %4d\r\n", cnt, i, j, cur_x, cur_y, length, flag, b_power, power, abs_pow, abs_base_pow );

		if ( cnt != 0 && abs_base_pow >= 1  ) {
			if (flag == 1 ) {
				aa = Draw_Circle_Line ( (float)power, j, cur_x, cur_y,  5.0, 1, 1 );
			} else {
				aa = Draw_Circle_Line ( i, (float)power, cur_x, cur_y,  5.0, 1, 1 );
			}
		} else {
			if (flag == 1 ) {
				aa = Draw_Circle_Line ( (float)power, j, cur_x, cur_y,  5.0, 1, 0 );
			} else {
				aa = Draw_Circle_Line ( i, (float)power, cur_x, cur_y,  5.0, 1, 0 );
			}
		}

		if (flag == 1 ) {
			j += base;
			i += a * base;
		} else {
			i += base;
			j += a * base;
		}

		if ( abs_pow >= base) b_power = power;
		if ( flag == 1 ) {
			power = (int)i;
		} else {
			power = (int)j;
		}

		cnt++;
		if ( cnt > 10 ) break;
	}

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_step_only_full_square (float x1, float y1, float x2, float y2, double a, float base ) ends.\r\n");
	return 0;
}


//20240720
vReturnableParam* calculate_start_and_base_step ( float x1, float y1, float x2, float y2, double base ) {
	vCalculation calc;
	vPoint* p1;
	vPoint* p2;
	vPoint* base_p1;

	p1 = (vPoint*) memorizevPoint( x1, y1, 0.0f );
	p2 = (vPoint*) memorizevPoint( x2, y2, 0.0f );

	base_p1 = (vPoint*) calc.subtract ( p2, p1 );
//	base_p1 = (vPoint*) calc.Normal ( base_p1 );
	base_p1 = (vPoint*) calc.scalize ( base_p1, (double)base );

	// Set returnable values
	vReturnableParam* result = new vReturnableParam ();
	result->point_num = 2;
	result->points = (vPoint**) malloc ( sizeof(vPoint*) * result->point_num );
	if ( result->points == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf ("result->points is NULL.\r\n");
		exit(-1);
	}
	result->points[0] = (vPoint*) p1;
	result->points[1] = (vPoint*) base_p1;

	return result;
}


// 20240610
int caribration_grid () {
	int a;
	char	a_h[1][255];

	if ( debug_print_msg_param () == 1 ) printf("int caribration_grid () starts.\r\n");
	a = sub_fonts_number_focus_set_param_sheet_basic () ;

	a = Get_Param_005ah ( "number_height", (char**)&a_h[0][0] );
	a = Get_Param_005ah ( "number_height", (char**)a_h );

	if ( debug_print_msg_param () == 1 ) printf("int caribration_grid () ends.\r\n");
	return 0;
}

//
int caribration_grid_01_03 () {
	int a;
	char	a_h[1][255];

	if ( debug_print_msg_param () == 1 ) printf("int caribration_grid () starts.\r\n");
	a = sub_fonts_number_focus_set_param_sheet_basic () ;

	Set_Param_index ( 6 );
	a = Get_Param_005a ( 1, 3, (char**)&a_h[0][0] );

	Set_Param_index ( 7 );
	a = Get_Param_005a ( 1, 3, (char**)&a_h[0][0] );

	if ( debug_print_msg_param () == 1 ) printf("int caribration_grid () ends.\r\n");
	return 0;
}


// https://www.geeksforgeeks.org/generating-random-number-range-c/
int rand_print_thumb_number_focus () {
	int a;
	srand(time(NULL));   // Initialization, should only be called once.
	int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
	float rand_a = ((double)r) / RAND_MAX;

	if ( rand_a < 1.1f ) {
		a = logging_thumb_number_focus();
	}

	return 0;
}

int check_thumb_number_focus () {
	if ( debug_print_msg_param () == 1 ) printf("int check_thumb_number_focus () starts.\r\n");
	if ( p_jackson->number_focus.start_x < 0 ) return -1;
	if ( p_jackson->number_focus.start_y < 0 ) return -1;
	if ( p_jackson->number_focus.width <= 0 ) return -1;
	if ( p_jackson->number_focus.height <= 0 ) return -1;

	if ( debug_print_msg_param () == 1 ) printf("int check_thumb_number_focus () ends.\r\n");
	return 0;
}

int print_thumb_number_focus () {

	if ( debug_print_msg_param () == 1 ) printf("start x %d ", p_jackson->number_focus.start_x);
	if ( debug_print_msg_param () == 1 ) printf("start y %d ", p_jackson->number_focus.start_y);
	if ( debug_print_msg_param () == 1 ) printf("font_width %d ", p_jackson->number_focus.width);
	if ( debug_print_msg_param () == 1 ) printf("font_height %d\r\n", p_jackson->number_focus.height);

	return 0;
}

int logging_thumb_number_focus () {
	char msg[255];
	dlog_001 = logging->update_log ("int logging_thumb_number_focus () starts.\0");

	if ( debug_print_msg_param () == 1 ) sprintf(msg,"start x %d\0", p_jackson->number_focus.start_x);
	dlog_001 = logging->update_log (msg);
	if ( debug_print_msg_param () == 1 ) sprintf(msg,"start y %d\0", p_jackson->number_focus.start_y);
	dlog_001 = logging->update_log (msg);
	if ( debug_print_msg_param () == 1 ) sprintf(msg,"font_width %d\0", p_jackson->number_focus.width);
	dlog_001 = logging->update_log (msg);
	if ( debug_print_msg_param () == 1 ) sprintf(msg,"font_height %d\0", p_jackson->number_focus.height);
	dlog_001 = logging->update_log (msg);

	dlog_001 = logging->update_log ("int logging_thumb_number_focus () ends.\0");
	return 0;
}


int check_number_focus () {
	int i;
	if ( debug_print_msg_param () == 1 ) printf("int check_number_focus () starts.\r\n");
	for ( i=0; i<10; i++ ) {
		if ( p_jackson->fonts_focus[i].start_x < 0 ) return -1;
		if ( p_jackson->fonts_focus[i].start_y < 0 ) return -1;
		if ( p_jackson->fonts_focus[i].width <= 0 ) return -1;
		if ( p_jackson->fonts_focus[i].height <= 0 ) return -1;

	}
	if ( debug_print_msg_param () == 1 ) printf("int check_number_focus () ends.\r\n");
	return 0;
}

int print_number_focus () {
	int i;

	if ( p_jackson->initialized != 1 ) return -1;

	if ( debug_print_msg_param () == 1 ) printf("fc start x %d ", p_jackson->paint_focus[0].start_x);
	if ( debug_print_msg_param () == 1 ) printf("start y %d ", p_jackson->paint_focus[0].start_y);
	if ( debug_print_msg_param () == 1 ) printf("font_width %d ", p_jackson->paint_focus[0].width);
	if ( debug_print_msg_param () == 1 ) printf("font_height %d\r\n", p_jackson->paint_focus[0].height);

	if ( debug_print_msg_param () == 1 ) printf("nf start x %d ", p_jackson->number_focus.start_x);
	if ( debug_print_msg_param () == 1 ) printf("start y %d ", p_jackson->number_focus.start_y);
	if ( debug_print_msg_param () == 1 ) printf("font_width %d ", p_jackson->number_focus.width);
	if ( debug_print_msg_param () == 1 ) printf("font_height %d\r\n", p_jackson->number_focus.height);

	for ( i=0; i<10; i++ ) {
		if ( debug_print_msg_param () == 1 ) printf("i %03d ", i );
		if ( debug_print_msg_param () == 1 ) printf("start x %d ", p_jackson->fonts_focus[i].start_x);
		if ( debug_print_msg_param () == 1 ) printf("start y %d ", p_jackson->fonts_focus[i].start_y);
		if ( debug_print_msg_param () == 1 ) printf("font_width %d ", p_jackson->fonts_focus[i].width);
		if ( debug_print_msg_param () == 1 ) printf("font_height %d ", p_jackson->fonts_focus[i].height);
		if ( debug_print_msg_param () == 1 ) printf("margin x %d ", p_jackson->fonts_focus[i].margin_x);
		if ( debug_print_msg_param () == 1 ) printf("margin y %d \r\n", p_jackson->fonts_focus[i].margin_y);
	}

	if ( debug_print_msg_param () == 1 ) printf("small start x %d ", p_jackson->small_focus.start_x);
	if ( debug_print_msg_param () == 1 ) printf("start y %d ", p_jackson->small_focus.start_y);
	if ( debug_print_msg_param () == 1 ) printf("font_width %d ", p_jackson->small_focus.width);
	if ( debug_print_msg_param () == 1 ) printf("font_height %d ", p_jackson->small_focus.height);
	if ( debug_print_msg_param () == 1 ) printf("margin x %d ", p_jackson->small_focus.margin_x);
	if ( debug_print_msg_param () == 1 ) printf("margin y %d \r\n", p_jackson->small_focus.margin_y);

	return 0;
}

ANIMATION_FOCUS_FRAME* get_jackson_pointer_animation_thread () {
	int a;

	if ( p_jackson == NULL ) {
		a = brunch_functions_all ();
	}

	return p_jackson;
}

//
int brunch_functions_all () {
	p_jackson = &m_jackson;
	p_jackson->draw_number = &draw_number;
	p_jackson->draw_effects =&draw_effects;
	p_jackson->draw_model_frame = &draw_model_frame;
	p_jackson->draw_grid = &draw_grid;

	p_jackson->call_draw_fucus_canvas_buffer_only = &call_draw_fucus_canvas_buffer_only_001;
//	p_jackson->call_draw_canvas_all = &call_draw_fucus_canvas_buffer_only_001;


	p_jackson->initialize_parameters_all= &initialize_parameters_all;


	p_jackson->Full_Box1 = &Full_Box1 ;
	p_jackson->Full_Box2 = &Full_Box2 ;
// x	p_jackson->Full_Box1 = &Full_Box1 ( int x1, int y1, int width, int height) ;
// x	p_jackson->Full_Box1 = &Full_Box1 ( 0, 0, 80, 80 ) ;

	return 0;
}

//
int initialize_ppm_fonts_debug () {

	debug_ppm[0] = 0;
	debug_ppm[1] = 0;
	debug_ppm[2] = 0;
	debug_ppm[3] = 0;

	debug_ppm[4] = 0;
	debug_ppm[5] = 0;
	debug_ppm[6] = 0;
	debug_ppm[7] = 1;
	debug_ppm[8] = 0;
	debug_ppm[9] = 0;
	debug_ppm[10] = 0;
	debug_ppm[11] = 1;
	debug_ppm[12] = 0;
	debug_ppm[13] = 0;
	debug_ppm[14] = 0;

	debug_ppm[15] = 0;
	debug_ppm[16] = 1;
	debug_ppm[17] = 1;
	debug_ppm[18] = 1;
	debug_ppm[19] = 1; // -
	debug_ppm[20] = 1;
	debug_ppm[21] = 1;

	return 0;
}

int initialize_ppm_fonts () {
	int a;

	a = initialize_ppm_fonts_debug () ;

	char* str_numbered_ppm = (char*)p_jackson->font_filename_name;
	a = read_ppm ( (char*) str_numbered_ppm, &m_read_ppm) ;

	return 0;
}


//	p_jackson->canvas[0][0] = (int)*((int*) (col));
int caribration_canvas () {
	if ( debug_print_msg_param () == 1 ) printf("int caribration_canvas () starts.\r\n");

	p_jackson->canvas[0][0] = 256*256 -1;
	RGBT* col = (RGBT*)&(p_jackson->canvas[0][0]);

	if ( debug_print_msg_param () == 1 ) printf("(256*256 -1) %d -> r %d g %d b %d \r\n", p_jackson->canvas[0][0], col->r, col->g, col->b );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	p_jackson->canvas[0][0] = (int)255;
	col = (RGBT*)&(p_jackson->canvas[0][0]);
	if ( debug_print_msg_param () == 1 ) printf("255 -> r %d g %d b %d \r\n", col->r, col->g, col->b );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	col->r = 255;
	col->g = 255;
	col->b = 255;
	col->t = 255;

	p_jackson->canvas[0][0] = (int)*((int*) (col));
	if ( debug_print_msg_param () == 1 ) printf("p_jackson->canvas[0][0] %d <- r %d g %d b %d t %d p|%p|\r\n", p_jackson->canvas[0][0], col->r, col->g, col->b, col->t, col );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	p_jackson->canvas[0][0] -= 1;
	col = (RGBT*)&(p_jackson->canvas[0][0]);
	if ( debug_print_msg_param () == 1 ) printf("p_jackson->canvas[0][0] - 1 = %d -> r %d g %d b %d t %d p|%p|\r\n", p_jackson->canvas[0][0], col->r, col->g, col->b,  col->t, col );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	col->r = 255;
	col->g = 255;
	col->b = 255;
	col->t = 254;

	p_jackson->canvas[0][0] = (int)*((int*) (col));
	if ( debug_print_msg_param () == 1 ) printf("p_jackson->canvas[0][0] %d <- r %d g %d b %d t %d p|%p|\r\n", p_jackson->canvas[0][0], col->r, col->g, col->b, col->t, col );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	col = (RGBT*)&(p_jackson->canvas[0][0]);
	if ( debug_print_msg_param () == 1 ) printf("p_jackson->canvas[0][0] %d -> r %d g %d b %d t %d p|%p|\r\n", p_jackson->canvas[0][0], col->r, col->g, col->b, col->t, col );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	if ( debug_print_msg_param () == 1 ) printf("number x %d y %d w %d h %d \r\n", p_jackson->number_focus.start_x, p_jackson->number_focus.start_y, p_jackson->number_focus.width, p_jackson->number_focus.height );
	if ( debug_print_msg_sleep () == 1 ) Sleep(2500);

	if ( debug_print_msg_param () == 1 ) printf("int caribration_canvas () ends.\r\n");
	return 0;
}


int initialize_canvas () {
	int i, j;
	int a;
	int* hh;

	if ( debug_print_msg_param () == 1 ) printf("int initialize_canvas () starts.\r\n");

	p_jackson->canvas_focus.start_x = 0;
	p_jackson->canvas_focus.start_y = 0;
	p_jackson->canvas_focus.width = 640;
	p_jackson->canvas_focus.height = 480;

	if ( p_jackson->canvas_focus.width < 5 ) return -1;
	if ( p_jackson->canvas_focus.height < 5 ) return -1;

	if ( p_jackson->canvas == NULL ) {
		p_jackson->canvas = (int**)malloc (sizeof(int) * p_jackson->canvas_focus.width );
		if ( p_jackson->canvas == NULL ) {
			if ( debug_print_msg_param () == 1 ) printf("p_jackson->canvas is NULL\r\n.");
			exit(-1);
		}
	}

	for ( i= p_jackson->canvas_focus.start_x; i<p_jackson->canvas_focus.width; i++ ) {
		p_jackson->canvas[i] = (int*)malloc (sizeof(int) * p_jackson->canvas_focus.height);
		if ( p_jackson->canvas[i] == NULL ) {
			if ( debug_print_msg_param () == 1 ) printf("p_jackson->canvas[%d]", i );
			if ( debug_ppm[0] == 1) exit(-1);
		}
	}

	hh = (int*) &(p_jackson->back_ground_colour);

	for ( j= p_jackson->canvas_focus.start_y; j<p_jackson->canvas_focus.height; j++ )
	for ( i= p_jackson->canvas_focus.start_x; i<p_jackson->canvas_focus.width; i++ ) {
		p_jackson->canvas[i][j] = (int) *hh;
//		p_jackson->canvas[i][j] = 256*4 -1;
//		p_jackson->canvas[i][j] = 0;
	}

	if ( debug_print_msg_param () == 1 ) printf("int initialize_canvas () ends.\r\n");
	return 0;
}

//
int initialize_parameters_all () {
	int i, j;
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int initialize_parameters_all () starts.\r\n");


	p_jackson->thread_sleep_real_animation = 33;
	p_jackson->thread_animation_times = 60;

	a = initialize_fonts_param_sheet ();

	a = sub_fonts_number_focus_set_param_sheet_result ();

	a = initialize_canvas ();

	if ( debug_print_msg_param () == 1 ) printf("int initialize_parameters_all () ends.\r\n");
//	return (void*);
	return 0;
}


int is_initialized () {
	if ( p_jackson->char_str_number == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("p_jackson->char_str_number is null.\r\n");
		return -1;
	}

	return 1;
}

// change
// m_read_ppm. ->
//
int draw_number () {
	static int i, j, k;
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int draw_number () starts.\r\n");

	if ( debug_ppm[20] == 1 ) {
		if ( debug_print_msg_param () == 1 ) printf("debug_ppm[20] %d\r\n", debug_ppm[20]);
		exit(-1);
	}

	if ( check_draw_string  () != 1 ) {
		if ( debug_print_msg_param () == 1 ) printf("... is not initialized.\r\n");
		return -1;
	}

	a = rand_print_thumb_number_focus();

	if ( check_thumb_number_focus () < 0 ) {
		a =	print_thumb_number_focus ();
		if ( debug_print_msg_param () == 1 ) printf("check_thumb_number_focus is not well for print.\r\n");
		exit(-1);
	}

	if ( check_number_focus () < 0 ) {
		a =	print_number_focus ();
		if ( debug_print_msg_param () == 1 ) printf("check_number_focus is not well for print.\r\n");
		exit(-1);
	} 

	k = 2;
	for ( j = p_jackson->fonts_focus[k].start_y; j<p_jackson->fonts_focus[k].height; j++ ) {
		for ( i = p_jackson->fonts_focus[k].start_x; i<p_jackson->fonts_focus[k].width; i++ ) {
			int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
			p_jackson->canvas[ p_jackson->number_focus.start_x + i][ p_jackson->number_focus.start_y + j] = (int)*h;
		}
	}

	if ( debug_ppm[19] == 1 ) {
		if ( debug_print_msg_param () == 1 ) printf("debug_ppm[19] %d\r\n", debug_ppm[19]);
		exit(-1);
	}

	if ( debug_print_msg_param () == 1 ) printf("int draw_number () ends.\r\n");
	return 0;
}

int sub_set_number_focus () {
	int i;
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;

	sub_fonts_number_focus_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );	

	for ( i=0; i<10; i++ ) {
		p_jackson->fonts_focus[i].start_x =  fonts_start_x;
		p_jackson->fonts_focus[i].start_y =  fonts_start_x;
		p_jackson->fonts_focus[i].width = fonts_width ;
		p_jackson->fonts_focus[i].height = fonts_height ;
		fonts_start_x += fonts_width;
	}
}

//
int sub_ppm_number () {
	static int i, j;
	for ( j = p_jackson->number_focus.start_y; j<p_jackson->number_focus.height; j++ ) {
		for ( i = p_jackson->number_focus.start_x; i<p_jackson->number_focus.width; i++ ) {
			// x (20240111)
			// x p_jackson->canvas[i][j] = (int)m_read_ppm.ppm_canvas[i][j];
			// x p_jackson->canvas[i][j] = (int)( m_read_ppm.ppm_canvas[i][j] );
			int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
			p_jackson->canvas[i][j] = (int)*h;
		}
	}

	return 0;
}

int sub_fonts_number_focus_sheet ( int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) {
	*fonts_width = 0;
	*fonts_height = 0;
	*fonts_start_x = 0;
	*fonts_start_y = 0;
	return 0;
}




int draw_effects () {
	int i, j, h;
	RGBT* col;
	if ( debug_print_msg_param () == 1 ) printf("int draw_effects () starts.\r\n");


	if ( debug_print_msg_param () == 1 ) printf("int draw_effects () ends.\r\n");
	return 0;
}

int draw_model_frame () {
	if ( debug_print_msg_param () == 1 ) printf("int draw_model_frame () starts.\r\n");
//	return (void*);
	if ( debug_print_msg_param () == 1 ) printf("int draw_model_frame () ends.\r\n");
	return 0;
}

int draw_grid () {
	int i, j, h;
	RGBT* col;
	if ( debug_print_msg_param () == 1 ) printf("int draw_grid () starts.\r\n");

	h = 0;
	col = (RGBT*)&h;
	col->r = p_jackson->grid_colour.r;
	col->g = p_jackson->grid_colour.g;
	col->b = p_jackson->grid_colour.b;
	col->t = 255;

	for ( j=0; j<p_jackson->canvas_focus.height; j+=10)
	for ( i=0; i<p_jackson->canvas_focus.width; i++ ) {
			p_jackson->canvas[i][j] = h;
	}

	for ( j=0; j<p_jackson->canvas_focus.height; j++ )
	for ( i=0; i<p_jackson->canvas_focus.width; i+=10 ) {
			p_jackson->canvas[i][j] = h;
	}

	if ( debug_print_msg_param () == 1 ) printf("int draw_grid () ends.\r\n");
	return 0;
}


//
// Draw to focus canvas buffer only
int call_draw_fucus_canvas_buffer_only_001 () {
	int a;
	static int model_changed = 0;
	int mode;

	if ( debug_print_msg_param () == 1 ) printf("int call_draw_fucus_canvas_buffer_only_001 () starts.\r\n");

	model_changed++;
	mode = model_changed  % 5 + 1;

	if ( debug_print_msg_param () == 1 ) printf("mode %d model_changed %d p_jackson|%p|\r\n", mode, model_changed, p_jackson );

	switch ( mode ) {
	case 0:
		break;
	case 1:
		p_jackson->draw_number();
		break;
	case 2:
		p_jackson->draw_effects();
		break;
	case 3:
		p_jackson->draw_model_frame();
		break;
	case 4:
		p_jackson->draw_grid();
		break;
	case 5:
		a = Draw_Rigth_Top_001 ();
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int call_draw_fucus_canvas_buffer_only_001 () ends.\r\n");
	return 0;
}

//
// Draw to focus canvas buffer only
int call_draw_fucus_canvas_buffer_only () {
	int a;
	static int model_changed = 0;
	int mode;

	if ( debug_print_msg_param () == 1 ) printf("int call_draw_fucus_canvas_buffer_only () starts.\r\n");

	model_changed++;
	mode = model_changed  % 4 + 1;

	if ( debug_print_msg_param () == 1 ) printf("mode %d model_changed %d p_jackson|%p|\r\n", mode, model_changed, p_jackson );

	if ( debug_ppm[21] == 1 ) {
		if ( debug_print_msg_param () == 1 ) printf("debug_ppm[21] %d\r\n", debug_ppm[21]);
		exit(-1);
	}

	switch ( mode ) {
	case 0:
		break;
	case 1:
		p_jackson->draw_number();
		break;
	case 2:
		p_jackson->draw_effects();
		break;
	case 3:
		p_jackson->draw_model_frame();
		break;
	case 4:
		p_jackson->draw_grid();
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int call_draw_fucus_canvas_buffer_only () ends.\r\n");
	return 0;
}

//
int Draw_Rigth_Top () {
	int i, j, k;
	RGBT* col;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Rigth_Top () starts.\r\n");
	for ( j = p_jackson->number_focus.start_y; j<p_jackson->number_focus.height; j++ ) {
		for ( i = p_jackson->number_focus.start_x; i<p_jackson->number_focus.width; i++ ) {

			k = 2;
			for ( j = p_jackson->fonts_focus[k].start_y; j<p_jackson->fonts_focus[k].height; j++ ) {
				for ( i = p_jackson->fonts_focus[k].start_x; i<p_jackson->fonts_focus[k].width; i++ ) {
					int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
					p_jackson->canvas[i][j] = (int)*h;
				}
			}

		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Rigth_Top () ends.\r\n");
	return 0;
}

//
int Draw_Rigth_Top_001 () {
	int i, j, k;
	RGBT* col;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Rigth_Top_001 () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Rigth_Top_001 () ends.\r\n");
	return 0;
}


//
//
//
int call_draw_canvas_all () {
	int i, j;

/*	for ( j= p_jackson->number_focus.start_y; j<p_jackson->number_focus.height; j++ )
	for ( i= p_jackson->number_focus.start_x; i<p_jackson->number_focus.width; i++ ) {
		p_jackson->canvas[i][j];
	}
*/
	return 0;
}

//20240319
int set_number () {
	static char num_str[255];
	if ( debug_print_msg_param () == 1 ) printf("int set_number () starts.\r\n");
	p_jackson->char_str_number = itoa( p_jackson->number, num_str, 10 );
	if ( debug_print_msg_param () == 1 ) printf("int set_number () ends.\r\n");
	return 0;
}


int initialize_media_tracker () {
	return 0;
}


int read_ppm_thread_initialize (){return 0;}
int read_ppm_thread_process (){return 0;}
int read_ppm_thread_pose (){return 0;}
int read_ppm_thread_outbyend (){return 0;}
int read_ppm_thread_close (){return 0;}


int animation_fonts_frame_thread_initialize (){return 0;}
int animation_fonts_frame_thread_process (){return 0;}
int animation_fonts_frame_thread_pose (){return 0;}
int animation_fonts_frame_thread_outbyend (){return 0;}
int animation_fonts_frame_thread_close (){return 0;}


int animation_focus_frame_thread_initialize (){return 0;}
int animation_focus_frame_thread_process (){return 0;}
int animation_focus_frame_thread_pose (){return 0;}
int animation_focus_frame_thread_outbyend (){return 0;}
int animation_focus_frame_thread_close (){return 0;}


// 20240129
int initialize_fonts_param_sheet () {
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int initialize_fonts_param_sheet () starts.\r\n");

	a = sub_fonts_number_focus_get_param_sheet ();

	if ( debug_print_msg_param () == 1 ) printf("int initialize_fonts_param_sheet () ends.\r\n");
	return 0;
}

//
int sub_fonts_number_focus_get_param_sheet () {
	int i;
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int sub_fonts_number_focus_get_param_sheet () starts.\r\n");

	a = sub_fonts_number_focus_exist_param_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf ("We are going to set the params for font sets.");
		a = sub_fonts_number_focus_set_param_sheet  ();
	}

	a = sub_fonts_number_focus_exist_param_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	fonts_width = fonts_width / 10;

	for ( i=0; i<10; i++ ) {
		p_jackson->fonts_focus[i].start_x =  fonts_start_x;
		p_jackson->fonts_focus[i].start_y =  fonts_start_y;
		p_jackson->fonts_focus[i].width = fonts_width ;
		p_jackson->fonts_focus[i].height = fonts_height ;
		fonts_start_x += fonts_width;
	}

	p_jackson->paint_focus[0].start_x =  0;
	p_jackson->paint_focus[0].start_y =  0;
	p_jackson->paint_focus[0].width = fonts_width ;
	p_jackson->paint_focus[0].height = fonts_height ;


	if ( debug_print_msg_param () == 1 ) printf("int sub_fonts_number_focus_get_param_sheet () ends.\r\n");
	return 0;
}

int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) {
	int a, b, c, d;
	char a_w[1][255];
	char a_h[1][255];
	char a_x[1][255];
	char a_y[1][255];

	if ( debug_print_msg_param () == 1 ) printf("int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[15] %d\r\n", debug_ppm[15]);
	if ( debug_ppm[15] == 1 ) exit(-1);

	a = Get_Param_005ah ( "number_start_x", (char**)a_x );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[16] %d\r\n", debug_ppm[16]);
	if ( debug_ppm[16] == 1 ) exit(-1);
	b = Get_Param_005ah ( "number_start_y", (char**)a_y );
	if ( b < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[17] %d\r\n", debug_ppm[17]);
	if ( debug_ppm[17] == 1 ) exit(-1);
	c = Get_Param_005ah ( "number_width", (char**)a_w );
	if ( c < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[18] %d\r\n", debug_ppm[18]);
	if ( debug_ppm[18] == 1 ) exit(-1);
	d = Get_Param_005ah ( "number_height", (char**)a_h );
	if ( d < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("sub_fonts_number_focus_exist_param_sheet return -1.\0");
		return -1;
	}

	*fonts_width = atoi(a_w[0]);
	*fonts_height = atoi(a_h[0]);
	*fonts_start_x = atoi(a_x[0]);
	*fonts_start_y = atoi(a_y[0]);

	if ( debug_print_msg_param () == 1 ) sprintf( a_w[0], " fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\0", *fonts_start_x, *fonts_start_y, *fonts_width, *fonts_height );
	if ( debug_print_msg_param () == 1 ) printf( "%s\r\n", (char*)a_w[0] );

	if ( debug_print_msg_param () == 1 ) sprintf( a_w[0], "a %d b %d c %d d %d\0", a, b, c, d );
	if ( debug_print_msg_param () == 1 ) printf( "%s\r\n", (char*)a_w[0] );

	if ( debug_print_msg_param () == 1 ) printf("int sub_fonts_number_focus_exist_param_sheet (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ends.\0");
	return 0;
}

//
int sub_fonts_number_focus_set_param_sheet () {
	int a;
	if ( debug_print_msg_param () == 1 ) printf ( "int sub_fonts_number_focus_set_param_sheet () starts.\0" );

//	char a_w[1][255];
//	char a_h[1][255];
//	char a_x[1][255];
//	char a_y[1][255];

//	strcpy( "50",a_x[0]):
//	strcpy( "500",a_y[0]):
//	strcpy( "600",a_w[0]):
//	strcpy( "100",a_h[0]):
//	a = Set_Param_005ah ( "number_start_x", (char**)a_x );
//	a = Set_Param_005ah ( "number_start_y", (char**)a_y );
//	a = Set_Param_005ah ( "number_width", (char**)a_w );
//	a = Set_Param_005ah ( "number_height", (char**)a_h );

	a = sub_fonts_number_focus_set_param_sheet_basic ();

	if ( debug_print_msg_param () == 1 ) printf ( "int sub_fonts_number_focus_set_param_sheet () ends.\0" );

	return 0;
}


int sub_fonts_number_focus_set_param_sheet_basic () {

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_basic () starts.\0" );

	Set_Param_index ( 6 );
	Set_Param_005a( 0, 3, (char*) "number_start_x"  ) ;
	Set_Param_005a( 1, 3, (char*) "number_start_y"  ) ;
	Set_Param_005a( 2, 3, (char*) "number_width"  ) ;
	Set_Param_005a( 3, 3, (char*) "number_height"  ) ;

	Set_Param_index ( 7 );
	Set_Param_005a( 0, 3, (char*) "0"  ) ;
	Set_Param_005a( 1, 3, (char*) "882"  ) ;
	Set_Param_005a( 2, 3, (char*) "640"  ) ;
	Set_Param_005a( 3, 3, (char*) "55"  ) ;

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_basic () ends.\0" );
	return 0;
}

// 20240319
int sub_fonts_number_focus_set_param_sheet_result () {
	static char num_str[255];

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_result () starts.\0" );

	Set_Param_index ( 6 );
	Set_Param_005a( 0, 4, (char*) "focus_start_x"  ) ;
	Set_Param_005a( 1, 4, (char*) "focus_start_y"  ) ;
	Set_Param_005a( 2, 4, (char*) "focus_width"  ) ;
	Set_Param_005a( 3, 4, (char*) "focus_height"  ) ;
	Set_Param_005a( 4, 4, (char*) "draw_param"  ) ;
	Set_Param_005a( 5, 4, (char*) "canvas_focus_start_x"  ) ;
	Set_Param_005a( 6, 4, (char*) "canvas_focus_start_y"  ) ;
	Set_Param_005a( 7, 4, (char*) "canvas_focus_width"  ) ;
	Set_Param_005a( 8, 4, (char*) "canvas_focus_height"  ) ;

	if ( p_jackson == NULL) return 1;

	Set_Param_index ( 7 );
	//itoa( i, num_str, 10 )
	Set_Param_005a( 0, 4, (char*) itoa(p_jackson->number_focus.start_x,(char*)num_str,10)  ) ;
	Set_Param_005a( 1, 4, (char*) itoa(p_jackson->number_focus.start_y,(char*)num_str,10)  ) ;
	Set_Param_005a( 2, 4, (char*) itoa(p_jackson->number_focus.width,(char*)num_str,10)  ) ;
	Set_Param_005a( 3, 4, (char*) itoa(p_jackson->number_focus.height,(char*)num_str,10)  ) ;
	Set_Param_005a( 4, 4, (char*) itoa( DRAW_PARAM ,(char*)num_str,10)  ) ;
	Set_Param_005a( 5, 4, (char*) itoa(p_jackson->canvas_focus.start_x,(char*)num_str,10)  ) ;
	Set_Param_005a( 6, 4, (char*) itoa(p_jackson->canvas_focus.start_y,(char*)num_str,10)  ) ;
	Set_Param_005a( 7, 4, (char*) itoa(p_jackson->canvas_focus.width,(char*)num_str,10)  ) ;
	Set_Param_005a( 8, 4, (char*) itoa(p_jackson->canvas_focus.height,(char*)num_str,10)  ) ;

	dlog_001 = logging->update_log ( (char*)"int sub_fonts_number_focus_set_param_sheet_result () ends.\0" );
	return 0;
}


int draw_canvas () {
	return 0;
}

// We are going to set
// font width
// fonr height
//
// change
// m_read_ppm. ->
int draw_canvas_number ( char* str_number, READ_PPM* read_ppm ) {
	static int i, j, k;
	int width, height, start_x, start_y;
	int ac;

	width = read_ppm->focus.width;
	height = read_ppm->focus.height;
//	width = ;
//	height = ;

	ac = array_count(str_number);

	for ( k=0; k<ac; k++ ) {
		for ( j = p_jackson->number_focus.start_y; j<p_jackson->number_focus.height; j++ ) {
			for ( i = p_jackson->number_focus.start_x; i<p_jackson->number_focus.width; i++ ) {
				// x (20240111)
				// x p_jackson->canvas[i][j] = (int)m_read_ppm.ppm_canvas[i][j];
				// x p_jackson->canvas[i][j] = (int)( m_read_ppm.ppm_canvas[i][j] );
				int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
				p_jackson->canvas[i][j] = (int)*h;
			}
		}
		start_x += width;
		start_y += height;
	}
}


int read_ppm_count (char* filename, READ_PPM* read_ppm, int* count) {

	return 0;
}

//
int read_ppm (char* filename, READ_PPM* read_ppm) {
	FILE *fp;
	int a, i, j;

	if ( debug_print_msg_param () == 1 ) printf("int read_ppm (char* filename, READ_PPM* read_ppm) starts.\r\n");

	read_ppm->ppm_canvas = (RGBT**)NULL;
	read_ppm->focus.start_x = 0;
	read_ppm->focus.start_y = 0;
	read_ppm->focus.width = 0;
	read_ppm->focus.height = 0;

	fp = fopen( filename, "rb");

	if ( debug_print_msg_param () == 1 ) printf("|%s| fp %d\r\n", filename, fp);

	a = read_ppm_head ( fp, &read_ppm->focus.start_x, &read_ppm->focus.start_y, &read_ppm->focus.width, &read_ppm->focus.height);
	if ( debug_print_msg_param () == 1 ) printf( "x %d y %d w %d h %d debug_ppm[4] %d\r\n",read_ppm->focus.start_x, read_ppm->focus.start_y, read_ppm->focus.width, read_ppm->focus.height, debug_ppm[4]);
	if ( debug_ppm[4] == 1) exit(-1);

	read_ppm->ppm_canvas = (RGBT**)malloc (sizeof(RGBT*) * read_ppm->focus.width);
	if ( read_ppm->ppm_canvas == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("We cannnot allocate read_ppm->ppm_canva as width %d of image\r\n", read_ppm->focus.width );
		exit(-1);
	}

	if ( debug_print_msg_param () == 1 ) printf("We could allocate read_ppm->ppm_canva as width %d of image sizeof(RGBT) %d\r\n", read_ppm->focus.width, sizeof(RGBT) );
	if ( debug_ppm[5] == 1) exit(-1);

	// allocation
	for ( i= read_ppm->focus.start_x; i<read_ppm->focus.width; i++ ) {
		read_ppm->ppm_canvas[i] = (RGBT*)malloc ( sizeof(RGBT) * read_ppm->focus.height);
		if ( read_ppm->ppm_canvas[i] == NULL ) {
			if ( debug_print_msg_param () == 1 ) printf("read_ppm->ppm_canvas[%d]\r\n", i );
			exit(-1);
		}
		if ( debug_ppm[7] == 1 && (i % 100) == 0 ) if ( debug_print_msg_param () == 1 ) printf("We could allocate read_ppm->ppm_canva as i %d width %d / height %d\r\n", i, read_ppm->focus.width, read_ppm->focus.height );
	}

	for ( i= read_ppm->focus.start_x; i<read_ppm->focus.width; i++ ) {
		for ( j= read_ppm->focus.start_y; j<read_ppm->focus.height; j++ ) {
			read_ppm->ppm_canvas[i][j].t = 0;
			if ( debug_ppm[6] == 1) if ( debug_print_msg_param () == 1 ) printf("i %d j %d canvas %d\r\n", i, j, read_ppm->ppm_canvas[i][j].t);
			if ( debug_ppm[7] == 1 && ( i * read_ppm->focus.width + j ) % 100 == 0 ) if ( debug_print_msg_param () == 1 ) printf("i %d j %d canvas %d\r\n", i, j, read_ppm->ppm_canvas[i][j].t);
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("We could initialize read_ppm->ppm_canva as width %d and height of  image\r\n", read_ppm->focus.width, read_ppm->focus.height );
	if ( debug_ppm[7] == 1) if ( debug_print_msg_param () == 1 ) printf("i - 1 %d j -1  %d canvas %d\r\n", i -1, j -1, read_ppm->ppm_canvas[i -1 ][j -1].t);


	a = read_ppm_image_binary ( fp, &read_ppm->focus.start_x, &read_ppm->focus.start_y, &read_ppm->focus.width, &read_ppm->focus.height, (RGBT**) read_ppm->ppm_canvas);

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int read_ppm (char* filename, READ_PPM* read_ppm) ends.\r\n");
	return 0;
}


// P6
// 255
// 320 180
//
//
int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) {
	char dummy[255], print_dummy[255];
	int i, j, a;
	int count, skip, lootin_continued, get_value;

	if ( debug_print_msg_param () == 1 ) printf("int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("fp %d\r\n", fp);

	count = 0;
	skip = 0;
	j = 0;
	lootin_continued = 0;
	get_value = 0;
	for ( i = 0; i<1000; i++ ) {
		fread( dummy, 1, 1, fp );
		print_dummy[ j % 255 ] = dummy[0];
		print_dummy[ j % 255 + 1 ] = 0;
		if ( debug_print_msg_param () == 1 ) printf("count %d i %d j %d |%d|%c|%s|\r\n", count, i, j, dummy[0], dummy[0], print_dummy);
		if ( dummy[0] == '\r' || dummy[0] == '\n' ) {
			if ( skip == 0 ) { count++; j = -1; get_value=1; if ( debug_print_msg_param () == 1 ) printf("count %d\r\n", count );}
			else { skip = 0; if ( debug_print_msg_param () == 1 ) printf("count %d\r\n", count ); j = 0; continue; }

			if ( get_value == 1 ) {
				switch ( count ) {
				case 1: //P6
					if ( debug_print_msg_param () == 1 ) printf( "in case 1 and P6, |%s|\r\n", print_dummy);
					break;
				case 2:
					if ( debug_print_msg_param () == 1 ) printf( "in case 2 and like 320 180, |%s|\r\n", print_dummy);
					a = char_ppm_width_height ( print_dummy, 255, (int*)width, (int*)height );
					break;
				case 3:
					if ( debug_print_msg_param () == 1 ) printf( "in case 3 and like 255, |%s|\r\n", print_dummy);
					if ( debug_ppm[3] == 1) exit(-1);
					break;
				}
				get_value=0;
			}

		}

		if ( count >= 3 ) break;

		if ( dummy[0] == '#' ) {
			skip = 1;
		}

		j++;
	}

	if ( debug_print_msg_param () == 1 ) printf("width %d height %d\r\n", *width, *height );

	if ( debug_print_msg_param () == 1 ) printf("int read_ppm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ends.\r\n");
	return 0;
}


//
// width_line_end
int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) {
	int i, j;
	char c;
	char n_dummy[8];

	if ( debug_print_msg_param () == 1 ) printf("int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) starts.\r\n");

	for ( i=0; i<num; i++ ) {
		c = print_dummy[i];
		if ( c == ' ' )
			break;

		n_dummy[i] = c;
	}

	n_dummy[i] = 0;
	if ( debug_print_msg_param () == 1 ) printf("w %s i %d ", n_dummy, i );
	*width = atoi(n_dummy);

	j = 0;
	for ( ; i<num; i++ ) {
		c = print_dummy[i];
		if ( c == '\r' )
			break;

		n_dummy[j] = c;
		j++;
	}

	if ( debug_print_msg_param () == 1 ) printf("h %s j %d\r\n", n_dummy, j );
	n_dummy[j] = 0;
	*height = atoi(n_dummy);

	if ( debug_print_msg_param () == 1 ) printf("int char_ppm_width_height ( char* print_dummy, int num, int* width, int* height ) ends.\r\n");
	return 0;
}

// P6
// 255
// 320 180
//
int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) {
	int i, j;
	unsigned char dummy[4];
	static int count = 0;

	if ( debug_print_msg_param () == 1 ) printf("int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) starts.\r\n");

	for ( j = 0; j<*height; j++ ) {
		for ( i = 0; i<*width; i++ ) {
			fread( dummy , 1, 3, fp);
			canvas[i][j].r = dummy[0];
			canvas[i][j].g = dummy[1];
			canvas[i][j].b = dummy[2];
			count++;
			if ( debug_ppm[7] == 1 && ( count % 100 ) == 1 ) if ( debug_print_msg_param () == 1 ) printf("canvas i %d j %d / (%d,%d) b%d\r\n", i, j, *width, *height, canvas[i][j].b );
		}
	}


	if ( debug_print_msg_param () == 1 ) printf("last i-1 %d j-1 %d r%d g%d b%d t%d\r\n", i -1 , j - 1, canvas[ i -1 ][ j -1 ].r, canvas[ i -1 ][ j -1 ].g, canvas[ i -1 ][ j -1 ].b, canvas[ i -1 ][ j -1 ].t );

	if ( debug_print_msg_param () == 1 ) printf("int read_ppm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ends.\r\n");
	return 0;
}

//
int set_log_001_jackson_animation (Logging* llog) {

	logging = (Logging*)llog;

	return 1;
}

//
int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) {
	int fnt_wid = 0;
	int fnt_x = 0;
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[12] %d\r\n", debug_ppm[12]);
	if ( debug_ppm[12] == 1) exit(-1);

	if ( debug_print_msg_param () == 1 ) printf("pointer set *fonts_start_x %d *fonts_start_y %d *fonts_width %d *fonts_height %d\r\n", *fonts_start_x, *fonts_start_y, (*fonts_width), (*fonts_height));

	fnt_wid = *fonts_width / 10;
	fnt_x = *fonts_start_x;
	for ( i=0; i<10; i++ ) {
		p_jackson->fonts_focus[i].start_x =  fnt_x;
		p_jackson->fonts_focus[i].start_y =  *fonts_start_y;
		p_jackson->fonts_focus[i].width = fnt_wid ;
		p_jackson->fonts_focus[i].height = *fonts_height ;

		p_jackson->fonts_focus[i].margin_x =  1;
		p_jackson->fonts_focus[i].margin_y =  0;

		fnt_x += fnt_wid;
	}

	if ( debug_print_msg_param () == 1 ) printf("pointer set *fonts_start_x %d *fonts_start_y %d *fonts_width %d *fonts_height %d\r\n", *fonts_start_x, *fonts_start_y, (*fonts_width), (*fonts_height));

	p_jackson->number_focus.start_x =  (*fonts_start_x);
	p_jackson->number_focus.start_y =  (*fonts_start_y);
	p_jackson->number_focus.width = (*fonts_width) ;
	p_jackson->number_focus.height =(*fonts_height) ;

	if ( debug_print_msg_param () == 1 ) printf("nf x %d y %d w %d h %d\r\n", p_jackson->number_focus.start_x, p_jackson->number_focus.start_y, p_jackson->number_focus.width, p_jackson->number_focus.height );
	if ( debug_print_msg_param () == 1 ) printf("pointer set *fonts_start_x %d *fonts_start_y %d *fonts_width %d *fonts_height %d\r\n", *fonts_start_x, *fonts_start_y, *fonts_width, *fonts_height);
	a = wait_sharp_short_time ();

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[13] %d\r\n", debug_ppm[13]);
	if ( debug_ppm[13] == 1) exit(-1);

	if ( debug_print_msg_param () == 1 ) printf("int set_fonts_param_frm_rect_values (int *fonts_width, int *fonts_height, int *fonts_start_x, int *fonts_start_y ) ends.\r\n");
	return 1;
}

//
int Resque_Number_Work_Param () {
	if ( debug_print_msg_param () == 1 ) printf("int Resque_Number_Work_Param () starts.\r\n");

	p_jackson->number_focus.start_x = 0;
	p_jackson->number_focus.start_y = 300;
	p_jackson->number_focus.width =  198;
	p_jackson->number_focus.height = 55;

	if ( debug_print_msg_param () == 1 ) printf("int Resque_Number_Work_Param () ends.\r\n");
	return 0;
}

//
int Random_Work_Param () {
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;
	int a;

	a = wait_sharp_short_time ();

	if ( debug_print_msg_param () == 1 ) printf("int Random_Work_Param () starts.\r\n");

	a = wait_sharp_short_time ();
	if ( debug_print_msg_param () == 1 ) printf("debug_ppm |%p|\r\n", debug_ppm);
	if ( debug_ppm == NULL ) exit(-1);
	a = wait_sharp_short_time ();

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[10] %d\r\n", debug_ppm[10]);
	if ( debug_ppm[10] == 1) exit(-1);

	a = wait_sharp_short_time ();

	if ( debug_print_msg_param () == 1 ) printf("before set fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\r\n", fonts_start_x, fonts_start_y, fonts_width, fonts_height);
	if ( debug_print_msg_sleep () == 1 ) Sleep(1000);

	// 0,862 + 640, 55
	fonts_start_x = 0;
	fonts_start_y = 880;
	fonts_width = 640;
	fonts_height = 55;

	if ( debug_print_msg_param () == 1 ) printf("before set fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\r\n", fonts_start_x, fonts_start_y, fonts_width, fonts_height);
	if ( debug_print_msg_sleep () == 1 ) Sleep(1000);

	a = set_fonts_param_frm_rect_values ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	if ( debug_print_msg_param () == 1 ) printf("after set fonts_start_x %d fonts_start_y %d fonts_width %d fonts_height %d\r\n", fonts_start_x, fonts_start_y, fonts_width, fonts_height);
	if ( debug_print_msg_sleep () == 1 ) Sleep(1000);

	if ( debug_ppm[11] == 1 ) {
		a = print_thumb_number_focus ();
		a = print_number_focus ();
	}

	if ( debug_print_msg_param () == 1 ) printf("int Random_Work_Param () ends.\r\n");
	return 0;
}

//
int Grid_Work_Param () {
	int i;
	int fonts_width;
	int fonts_height;
	int fonts_start_x;
	int fonts_start_y;
	int a;
	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[9] %d\r\n", debug_ppm[9]);
	if ( debug_ppm[9] == 1) exit(-1);

	a = sub_fonts_number_focus_exist_param_sheet ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	a = set_fonts_param_frm_rect_values ( &fonts_width, &fonts_height, &fonts_start_x, &fonts_start_y );

	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}


//
int Stored_Work_Param (char* file_name ) {
	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}

//
int Check_Initialize_Param () {
	int a, i;
	if ( debug_print_msg_param () == 1 ) printf("int Check_Initialize_Param () starts.\r\n");

	for ( i=0; i<10; i++ ) {
		a = check_animation_focus( &(p_jackson->fonts_focus[i]) );
		if ( a < 0 ) {
			if ( debug_print_msg_param () == 1 ) printf("font focus i %d a %d \r\n", i, a );
			if ( debug_print_msg_param () == 1 ) printf("int Check_Initialize_Param () return -1.\r\n");
			if ( debug_print_msg_sleep () == 1 ) Sleep(1000);
			return -1;
		}
	}

	a = check_animation_focus_band ( &(p_jackson->focus) );
	if ( a < 0 ) {
		if ( debug_print_msg_param () == 1 ) printf("font focus a %d \r\n",  a );
		if ( debug_print_msg_param () == 1 ) printf("int Check_Initialize_Param () ends.\r\n");
		if ( debug_print_msg_sleep () == 1 ) Sleep(1000);
		return -1;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Check_Initialize_Param () returns as 1.\r\n");
	if ( debug_print_msg_sleep () == 1 ) Sleep(1000);
	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[14] %d\r\n", debug_ppm[14]);
	if ( debug_ppm[14] == 1 ) {
		exit(-1);
	}
	return 1;
}

int check_animation_focus(ANIMATION_FOCUS* focus) {
	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("focus |%p| focus->width %d focus->height %d\r\n", focus, focus->width, focus->height );
	
	if ( focus->width <=0 || focus->height<=0 ) {
		return -1;
	}

	if ( focus->width > 100 || focus->height > 100 ) {
		return -1;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}

int check_animation_focus_band (ANIMATION_FOCUS* focus) {
	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () starts.\r\n");

	if ( debug_print_msg_param () == 1 ) printf("focus |%p| focus->width %d focus->height %d\r\n", focus, focus->width, focus->height );
	
	if ( focus->width <=0 || focus->height<=0 ) {
		return -1;
	}

	if ( focus->width > 640 || focus->height > 100 ) {
		return -1;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Grid_Work_Param () ends.\r\n");
	return 1;
}



//
int Resque_Initialize_Param () {
	int i, a;
	static int select_param = 0;
	if ( debug_print_msg_param () == 1 ) printf("int Resque_Initialize_Param () starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("debug_ppm[8] %d\r\n", debug_ppm[8]);
	if ( debug_ppm[8] == 1) exit(-1);

	for (i=0; Check_Initialize_Param() <= 0; i++) {
		if ( debug_print_msg_param () == 1 ) printf("select_param %d\r\n", select_param);
		if ( debug_print_msg_sleep () == 1 ) Sleep(1000);

		switch( select_param ) {
		case 0:
			a = Grid_Work_Param ();
			break;
		case 1:
			a = Stored_Work_Param(".\\end_p\\001-end-file-process-font-001\.txt");
			break;
		case 2:
			a = Random_Work_Param ();
			break;
		default:
			exit(-1);
			break;
		}

		select_param++;
		select_param %= 3;
	}

	a = print_number_focus();
	if ( debug_print_msg_param () == 1 ) printf("int Resque_Initialize_Param () ends.\r\n");
	return 1;
}

//
int Store_Work_Param (char* file_name ) {
	if ( debug_print_msg_param () == 1 ) printf("int Store_Work_Param (char* file_name ) starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("int Store_Work_Param (char* file_name ) ends.\r\n");
	exit(-1);
	return 1;
}


//
int Save_Sound_Wave_Buffer () {
	if ( debug_print_msg_param () == 1 ) printf("int Save_Sound_Wave_Buffer () starts.\r\n");
	voicewave[0] = 0;

	if ( debug_print_msg_param () == 1 ) printf("int Save_Sound_Wave_Buffer () ends.\r\n");
	return 0;
}

//
int set_focus (int sx, int sy, int width, int height ) {
	if ( debug_print_msg_param () == 1 ) printf("int set_focus (int sx, int sy, int width, int height ) starts.\r\n");

	p_jackson->paint_focus[0].start_x = sx;
	p_jackson->paint_focus[0].start_y = sy;
	p_jackson->paint_focus[0].width   = width;
	p_jackson->paint_focus[0].height  = height;

	if ( debug_print_msg_param () == 1 ) printf("int set_focus (int sx, int sy, int width, int height ) ends.\r\n");
	return 0;
}


// 20250615
int print_set_focus () {

	printf("int print_set_focus () starts.\r\n");

	printf("( %d, ", p_jackson->paint_focus[0].start_x );
	printf(" %d, ", p_jackson->paint_focus[0].start_y );
	printf(" %d, ", p_jackson->paint_focus[0].width );
	printf(" %d )", p_jackson->paint_focus[0].height );
	printf("\r\n");

	printf("int print_set_focus () ends.\r\n");
	return 0;
}


// 	p_jackson->draw_focus.start_x = sx;
// 20250615
int print_set_draw_focus () {

	printf("int print_set_draw_focus () starts.\r\n");

	printf("( %d, ", p_jackson->draw_focus.start_x );
	printf(" %d, ", p_jackson->draw_focus.start_y );
	printf(" %d, ", p_jackson->draw_focus.width );
	printf(" %d )", p_jackson->draw_focus.height );
	printf("\r\n");

	printf("int print_set_draw_focus () ends.\r\n");
	return 0;
}


//
int Draw_Rigth_Top_004 (int number_p ) {
	int i, j, k;
	RGBT* col;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Rigth_Top () starts.\r\n");
	for ( j = p_jackson->paint_focus[0].start_y; j<p_jackson->paint_focus[0].height; j++ ) {
		for ( i = p_jackson->paint_focus[0].start_x; i<p_jackson->paint_focus[0].width; i++ ) {

			k = 2;
			for ( j = p_jackson->fonts_focus[k].start_y; j<p_jackson->fonts_focus[k].height; j++ ) {
				for ( i = p_jackson->fonts_focus[k].start_x; i<p_jackson->fonts_focus[k].width; i++ ) {
					int* h = (int*)&(m_read_ppm.ppm_canvas[i][j]);
					p_jackson->canvas[i][j] = (int)*h;
				}
			}

		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Rigth_Top () ends.\r\n");
	return 0;
}

// Draw_Rigth_Top_002 -> Draw_Focus_Number
//
int Draw_Focus_Number (int number_p ) {
	int i, j, v;
	double x, y;
	RGBT* col;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Focus_Number (%d) starts.\r\n", number_p);
	if ( debug_print_msg_param () == 1 ) printf("%d %d %d %d\r\n", p_jackson->small_focus.start_x, p_jackson->small_focus.start_y, p_jackson->small_focus.width, p_jackson->small_focus.height);
	for ( j = p_jackson->small_focus.start_y; j<p_jackson->small_focus.start_y + p_jackson->small_focus.height; j++ ) {
		if ( j >= p_jackson->canvas_focus.height ) break;
		for ( i = p_jackson->small_focus.start_x; i<p_jackson->small_focus.start_x + p_jackson->small_focus.width - 2*p_jackson->fonts_focus[number_p].margin_x ; i++ ) {
			if ( i >= p_jackson->canvas_focus.width ) break;
			x = i - p_jackson->small_focus.start_x ;
			y = j - p_jackson->small_focus.start_y ;
			x /= p_jackson->font_rasio;
			y /= p_jackson->font_rasio;
			x += p_jackson->fonts_focus[number_p].start_x + p_jackson->fonts_focus[number_p].margin_x;
			y += p_jackson->fonts_focus[number_p].start_y;
			if ( debug_print_msg_param () == 1 ) printf("i %d j %d <- x %d, y %d ", i, j, (int)x, (int)y);
//			v = return_ppm_value_001 ( x, y );
			v = return_ppm_value_002 ( x, y );
			if ( debug_print_msg_param () == 1 ) printf ("v %d ", v );
			if ( p_jackson->font_background == 1 ) v = value_on_background ( p_jackson->canvas[i][j], v );
			if ( debug_print_msg_param () == 1 ) printf ("v %d\r\n", v );
			p_jackson->canvas[i][j] = v;
			//col = (RGBT*)&(m_read_ppm.ppm_canvas[x][y]);
//			p_jackson->canvas[0][0] = return_ppm_value ( 0, 0 );
//			p_jackson->canvas[i][j] = return_ppm_value ( x, y );
//			p_jackson->canvas[i][j] = (int) 0;
//			p_jackson->canvas[0][0] = (int)*((int*) (col));
//			p_jackson->canvas[i][j] = (int)*((int*) (col));
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Focus_Number (%d) ends.\r\n", number_p);
	return 0;
}


int Draw_Focus_Number_001 (int number_p ) {
	int i, j, k;
	RGBT* col;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Focus_Number_001 (%d) starts.\r\n", number_p);

	for ( j = 180; j<240; j++ )
	for ( i = 320; i<380; i++ ) {
		p_jackson->canvas[i][j] = (int) 0;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Focus_Number_001 (%d) ends.\r\n", number_p);
	return 0;
}

// Draw_Rigth_Top_003 -> Draw_Jackson_Focus_Number
//
int Draw_Jackson_Focus_Number () {
	int i, j, ac, num, a, cnt;
	char* p_num;
	int width, height;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Number () starts.\r\n");

	p_num = (char*)p_jackson->char_str_number;
	ac = array_count( p_num );
	cnt = 0;
	num = 0;

	width = p_jackson->fonts_focus[0].width * p_jackson->font_rasio;
	height = p_jackson->fonts_focus[0].height * p_jackson->font_rasio;

	if ( debug_print_msg_param () == 1 ) printf("num %d p_num|%s| ac %d [0]=|%d|\r\n", num, p_num, ac, p_num[0]);
	for ( i = p_jackson->draw_focus.start_x; cnt<ac; i += width ) {
		a = set_small_focus ( i, p_jackson->draw_focus.start_y, width, height );
		num = p_num[cnt] - '0';
		a = Draw_Focus_Number ( num );
		cnt++;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Number () ends.\r\n");
	return 0;
}

//
int ascii_to_int ( char* num ) {
	int result;

	if ( debug_print_msg_param () == 1 ) printf("int ascii_to_int () starts.\r\n");

	result = num[0] - '0';

	if ( debug_print_msg_param () == 1 ) printf("int ascii_to_int () ends.\r\n");
	return result;
}

//
int set_small_focus (int sx, int sy, int width, int height ) {
	if ( debug_print_msg_param () == 1 ) printf("int set_small_focus ( %d, %d, %d, %d ) starts.\r\n", sx, sy, width, height );

	p_jackson->small_focus.start_x = sx;
	p_jackson->small_focus.start_y = sy;
	p_jackson->small_focus.width   = width;
	p_jackson->small_focus.height  = height;

	p_jackson->small_focus.margin_x = 1;
	p_jackson->small_focus.margin_y = 0;

	if ( debug_print_msg_param () == 1 ) printf("int set_small_focus ( %d, %d, %d, %d ) ends.\r\n", sx, sy, width, height );
	return 0;
}

//
int return_ppm_value ( int x, int y ) {
	int result;
	RGBT* col;

	col = (RGBT*)&(m_read_ppm.ppm_canvas[x][y]);
	result = (int)*((int*) (col));
//	result = col->r * 255 * 255 * 255;
//	result += col->g * 255 * 255;
//	result += col->b * 255;
//	result += col->t;

	return result;
}


//
int return_ppm_value_001 ( double x, double y ) {
	int result;
	RGBT* col;

	col = (RGBT*)&(m_read_ppm.ppm_canvas[(int)x][(int)y] );
	result = (int)*((int*) (col));

	return result;
}

//
int return_ppm_value_002 ( double x, double y ) {
	int result;
	RGBT *col1, *col2, *col3, *col4;
	RGBT c3;
	RGBT *col;
	int x1, x2, y1, y2;
	double a1, a2;
	int white = 0;
	double c1_r, c1_g, c1_b;
	double c2_r, c2_g, c2_b;
	double c3_r, c3_g, c3_b;

	if ( debug_print_msg_param () == 1 ) printf("int return_ppm_value_002 ( double x, double y ) starts.\r\n");

	x1 = (int) x;
	x2 = x1 + 1;
	y1 = (int) y;
	y2 = y1 + 1;

	a1 = x - x1 ;
	a2 = 1.0 - a1;

	col1 = (RGBT*)&(m_read_ppm.ppm_canvas[x1][y1]);
	col2 = (RGBT*)&(m_read_ppm.ppm_canvas[x2][y1]);

	c1_r = a2 * col1->r + a1 * col2->r;
	c1_g = a2 * col1->g + a1 * col2->g;
	c1_b = a2 * col1->b + a1 * col2->b;

	if ( c1_r > 255.0 || c1_g > 255.0 || c1_b > 255.0 ) {
		if ( debug_print_msg_param () == 1 ) printf("c1 ( %0.3f, %0.3f, %0.3f) a1 %0.3f, a2 %0.3f x1 %d x2 %d y1 %d y2 %d\r\n", c1_r, c1_g, c1_b, a1, a2, x1, x2, y1, y2 );
		exit(-1);
	}


	col3 = (RGBT*)&(m_read_ppm.ppm_canvas[x1][y2]);
	col4 = (RGBT*)&(m_read_ppm.ppm_canvas[x2][y2]);

	c2_r = a2 * col3->r + a1 * col4->r;
	c2_g = a2 * col3->g + a1 * col4->g;
	c2_b = a2 * col3->b + a1 * col4->b;

	if ( c2_r > 255.0 || c2_g > 255.0 || c2_b > 255.0 ) {
		if ( debug_print_msg_param () == 1 ) printf("c2 ( %0.3f, %0.3f, %0.3f) a1 %0.3f, a2 %0.3f x1 %d x2 %d y1 %d y2 %d\r\n", c2_r, c2_g, c2_b, a1, a2, x1, x2, y1, y2 );
		exit(-1);
	}

	a1 = y - y1;
	a2 = 1.0 - a1;

	c3_r = a2 * c1_r + a1 * c2_r;
	c3_g = a2 * c1_g + a1 * c2_g;
	c3_b = a2 * c1_b + a1 * c2_b;

	if ( c3_r > 255.0 || c3_g > 255.0 || c3_b > 255.0 ) {
		if ( debug_print_msg_param () == 1 ) printf("c3 ( %0.3f, %0.3f, %0.3f) a1 %0.3f, a2 %0.3f x1 %d x2 %d y1 %d y2 %d\r\n", c3_r, c3_g, c3_b, a1, a2, x1, x2, y1, y2 );
		exit(-1);
	}

	c3.r = (unsigned char) c3_r;
	c3.g = (unsigned char) c3_g;
	c3.b = (unsigned char) c3_b;

	col = (RGBT*)&c3;
	result = (int)*((int*) (col));

	if ( debug_print_msg_param () == 1 ) printf("int return_ppm_value_002 ( double x, double y ) ends.\r\n");

	return result;
}

// v1 canvas
// v2 font
//
int value_on_background ( int v1, int v2 ) {
	double aa1, aa2;
	RGBT *col1, *col2, c3, *col;
	double white = 0.0;
	int result = 0;
	if ( debug_print_msg_param () == 1 ) printf("int value_on_background ( int v1, int v2 ) starts.\r\n");

	col1 = (RGBT*) &v1;
	col2 = (RGBT*) &v2;

	// aa2 0.0 ------> 1.0 white
	white = col2->r * 0.4 + col2->g * 0.3 + col2->b * 0.3;
	aa2 = (double)white / (double)( 255.0);
	if ( aa2 > 0.6 ) aa2 = 1.0;
	aa1 = 1.0 - aa2 - 0.001;

	if ( debug_print_msg_param () == 1 ) printf("white %0.3f aa1 %0.3f aa2 %0.3f ", white, aa1, aa2);
	if ( debug_print_msg_param () == 1 ) printf("font r %d g %d b %d ", col2->r, col2->g, col2->b );
	if ( debug_print_msg_param () == 1 ) printf("col r %d g %d b %d\r\n", p_jackson->fore_ground_colour.r, p_jackson->fore_ground_colour.g, p_jackson->fore_ground_colour.b);
//	if ( aa2 < 0.5 ) exit(-1);

	c3.r = aa2 * col1->r + aa1 * p_jackson->fore_ground_colour.r;
	c3.g = aa2 * col1->g + aa1 * p_jackson->fore_ground_colour.g;
	c3.b = aa2 * col1->b + aa1 * p_jackson->fore_ground_colour.b;

	col = (RGBT*)&c3;
	result = (int)*((int*) (col));

	if ( debug_print_msg_param () == 1 ) printf("int value_on_background ( int v1, int v2 ) ends.\r\n");
	return result;
}

int set_font_background (int fbk_v) {
	if ( debug_print_msg_param () == 1 ) printf("int set_font_background (int fbk_v) starts.\r\n");
	if (p_jackson == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("int set_font_background (int fbk_v) return -1.\r\n");
		return -1;
	}
	p_jackson->font_background = fbk_v;
	if ( debug_print_msg_param () == 1 ) printf("int set_font_background (int fbk_v) return 1.\r\n");
	return 1;
}

//
int set_font_rasio (double fr_v) {
	if ( debug_print_msg_param () == 1 ) printf("int set_font_rasio (int fr_v) starts.\r\n");
	if (p_jackson == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("int set_font_rasio (int fr_v) return -1.\r\n");
		return -1;
	}
	p_jackson->font_rasio = fr_v;
	if ( debug_print_msg_param () == 1 ) printf("int set_font_rasio (int fr_v) return 1.\r\n");
	return 1;
}

//
int set_font_height_rasio (int height) {
	if ( debug_print_msg_param () == 1 ) printf("int set_font_height_rasio (int height) starts.\r\n");

//	width = p_jackson->fonts_focus[0].width * p_jackson->font_rasio;
	p_jackson->font_rasio = (double) (double)height / (double)p_jackson->fonts_focus[0].height ; 

	if ( debug_print_msg_param () == 1 ) printf("int set_font_height_rasio (int height) ends.\r\n");
	return 1;
}

//
int set_draw_focus (int sx, int sy, int width, int height ) {
	if ( debug_print_msg_param () == 1 ) printf("int set_draw_focus (int %d, int %d, int %d, int %d ) starts.\r\n", sx, sy, width, height);

	p_jackson->draw_focus.start_x = sx;
	p_jackson->draw_focus.start_y = sy;
	p_jackson->draw_focus.width   = width;
	p_jackson->draw_focus.height  = height;

	// 20250613
	if ( p_jackson->draw_focus.width > p_jackson->canvas_focus.width )
		p_jackson->draw_focus.width = p_jackson->canvas_focus.width;

	// 20250613
	if ( p_jackson->draw_focus.height > p_jackson->canvas_focus.height )
		p_jackson->draw_focus.height = p_jackson->canvas_focus.height;

	// 20250613
	if ( p_jackson->draw_focus.width < 0 )
		p_jackson->draw_focus.width = 0;

	// 20250613
	if ( p_jackson->draw_focus.height < 0 )
		p_jackson->draw_focus.height = 0;


	if ( debug_print_msg_param () == 1 ) printf("int set_draw_focus (int %d, int %d, int %d, int %d ) ends.\r\n", sx, sy, width, height);
	return 0;
}


//
int read_pgm (char* filename, READ_PGM* read_pgm) {
	FILE *fp;
	int a, i, j;

	if ( debug_print_msg_param () == 1 ) printf("int read_pgm (char* filename, READ_PGM* read_pgm) starts.\r\n");

	read_pgm->pgm_canvas = (RGBT**)NULL;
	read_pgm->focus.start_x = 0;
	read_pgm->focus.start_y = 0;
	read_pgm->focus.width = 0;
	read_pgm->focus.height = 0;

	fp = fopen( filename, "rb");

	if ( debug_print_msg_param () == 1 ) printf("|%s| fp %d\r\n", filename, fp);

	a = read_pgm_head ( fp, &read_pgm->focus.start_x, &read_pgm->focus.start_y, &read_pgm->focus.width, &read_pgm->focus.height);
	if ( debug_print_msg_param () == 1 ) printf( "x %d y %d w %d h %d debug_ppm[4] %d\r\n",read_pgm->focus.start_x, read_pgm->focus.start_y, read_pgm->focus.width, read_pgm->focus.height, debug_ppm[4]);
	if ( debug_ppm[4] == 1) exit(-1);

	read_pgm->pgm_canvas = (RGBT**)malloc (sizeof(RGBT*) * read_pgm->focus.width);
	if ( read_pgm->pgm_canvas == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("We cannnot allocate read_pgm->ppm_canva as width %d of image\r\n", read_pgm->focus.width );
		exit(-1);
	}

	if ( debug_print_msg_param () == 1 ) printf("We could allocate read_pgm->ppm_canva as width %d of image sizeof(RGBT) %d\r\n", read_pgm->focus.width, sizeof(RGBT) );
	if ( debug_ppm[5] == 1) exit(-1);

	// allocation
	for ( i= read_pgm->focus.start_x; i<read_pgm->focus.width; i++ ) {
		read_pgm->pgm_canvas[i] = (RGBT*)malloc ( sizeof(RGBT) * read_pgm->focus.height);
		if ( read_pgm->pgm_canvas[i] == NULL ) {
			if ( debug_print_msg_param () == 1 ) printf("read_pgm->pgm_canvas[%d]\r\n", i );
			exit(-1);
		}
		if ( debug_ppm[7] == 1 && (i % 100) == 0 ) if ( debug_print_msg_param () == 1 ) printf("We could allocate read_pgm->ppm_canva as i %d width %d / height %d\r\n", i, read_pgm->focus.width, read_pgm->focus.height );
	}

	for ( i= read_pgm->focus.start_x; i<read_pgm->focus.width; i++ ) {
		for ( j= read_pgm->focus.start_y; j<read_pgm->focus.height; j++ ) {
			read_pgm->pgm_canvas[i][j].t = 0;
			if ( debug_ppm[6] == 1) if ( debug_print_msg_param () == 1 ) printf("i %d j %d canvas %d\r\n", i, j, read_pgm->pgm_canvas[i][j].t);
			if ( debug_ppm[7] == 1 && ( i * read_pgm->focus.width + j ) % 100 == 0 ) if ( debug_print_msg_param () == 1 ) printf("i %d j %d canvas %d\r\n", i, j, read_pgm->pgm_canvas[i][j].t);
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("We could initialize read_pgm->ppm_canva as width %d and height of  image\r\n", read_pgm->focus.width, read_pgm->focus.height );
	if ( debug_ppm[7] == 1) if ( debug_print_msg_param () == 1 ) printf("i - 1 %d j -1  %d canvas %d\r\n", i -1, j -1, read_pgm->pgm_canvas[i -1 ][j -1].t);


	a = read_pgm_image_binary ( fp, &read_pgm->focus.start_x, &read_pgm->focus.start_y, &read_pgm->focus.width, &read_pgm->focus.height, (RGBT**) read_pgm->pgm_canvas);

	fclose(fp);

	if ( debug_print_msg_param () == 1 ) printf("int read_pgm (char* filename, READ_PGM* read_pgm) ends.\r\n");
	return 0;
}


// P5
// 255
// 320 180
//
//
int read_pgm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) {
	char dummy[255], print_dummy[255];
	int i, j, a;
	int count, skip, lootin_continued, get_value;

	if ( debug_print_msg_param () == 1 ) printf("int read_pgm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("fp %d\r\n", fp);

	count = 0;
	skip = 0;
	j = 0;
	lootin_continued = 0;
	get_value = 0;
	for ( i = 0; i<1000; i++ ) {
		fread( dummy, 1, 1, fp );
		print_dummy[ j % 255 ] = dummy[0];
		print_dummy[ j % 255 + 1 ] = 0;
		if ( debug_print_msg_param () == 1 ) printf("count %d i %d j %d |%d|%c|%s|\r\n", count, i, j, dummy[0], dummy[0], print_dummy);
		if ( dummy[0] == '\r' || dummy[0] == '\n' ) {
			if ( skip == 0 ) { count++; j = -1; get_value=1; if ( debug_print_msg_param () == 1 ) printf("count %d\r\n", count );}
			else { skip = 0; if ( debug_print_msg_param () == 1 ) printf("count %d\r\n", count ); j = 0; continue; }

			if ( get_value == 1 ) {
				switch ( count ) {
				case 1: // P5
					if ( debug_print_msg_param () == 1 ) printf( "in case 1 and P5, |%s|\r\n", print_dummy);
					break;
				case 2:
					if ( debug_print_msg_param () == 1 ) printf( "in case 2 and like 320 180, |%s|\r\n", print_dummy);
					a = char_ppm_width_height ( print_dummy, 255, (int*)width, (int*)height );
					break;
				case 3:
					if ( debug_print_msg_param () == 1 ) printf( "in case 3 and like 255, |%s|\r\n", print_dummy);
					if ( debug_ppm[3] == 1) exit(-1);
					break;
				}
				get_value=0;
			}

		}

		if ( count >= 3 ) break;

		if ( dummy[0] == '#' ) {
			skip = 1;
		}

		j++;
	}

	if ( debug_print_msg_param () == 1 ) printf("width %d height %d\r\n", *width, *height );

	if ( debug_print_msg_param () == 1 ) printf("int read_pgm_head ( FILE *fp, int* start_x, int* start_y, int* width, int* height) ends.\r\n");
	return 0;
}

int initialize_pgm_fonts () {
	int a;

	a = initialize_ppm_fonts_debug () ;

	char* str_numbered_pgm = (char*)p_jackson->font_filename_name;
	a = read_pgm ( (char*) str_numbered_pgm, &m_read_pgm) ;

	return 0;
}


// P5
// 255
// 320 180
//
int read_pgm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) {
	int i, j;
	unsigned char dummy[4];
	static int count = 0;

	if ( debug_print_msg_param () == 1 ) printf("int read_pgm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) starts.\r\n");

	for ( j = 0; j<*height; j++ ) {
		for ( i = 0; i<*width; i++ ) {
			fread( dummy , 1, 3, fp);
			canvas[i][j].t = dummy[0];
			count++;
			if ( debug_ppm[7] == 1 && ( count % 100 ) == 1 ) if ( debug_print_msg_param () == 1 ) printf("canvas i %d j %d / (%d,%d) b%d\r\n", i, j, *width, *height, canvas[i][j].b );
		}
	}


	if ( debug_print_msg_param () == 1 ) printf("last i-1 %d j-1 %d r%d g%d b%d t%d\r\n", i -1 , j - 1, canvas[ i -1 ][ j -1 ].r, canvas[ i -1 ][ j -1 ].g, canvas[ i -1 ][ j -1 ].b, canvas[ i -1 ][ j -1 ].t );

	if ( debug_print_msg_param () == 1 ) printf("int read_pgm_image_binary ( FILE *fp, int* start_x, int* start_y, int* width, int* height, RGBT** canvas ) ends.\r\n");
	return 0;
}

int Set_Font_Draw_Left_Top ( int x, int y ) {
	if ( p_jackson ==NULL ) return -1;
	p_jackson->draw_focus.start_x = x;
	p_jackson->draw_focus.start_y = y;
	return 0;
}

int Set_Font_Pix_Scale ( int scale ) {
	int a;
	a = Set_Font_Height ( scale );
	return a;
}

int Set_Font_Colour ( RGBT rgbt ) {
	if ( p_jackson ==NULL ) return -1;

	p_jackson->fore_ground_colour.r = rgbt.r;
	p_jackson->fore_ground_colour.g = rgbt.g;
	p_jackson->fore_ground_colour.b = rgbt.b;
	p_jackson->fore_ground_colour.t = rgbt.t;

	return 0;
}

int Set_Font_Height ( int height ) {
	int a;
	a = set_font_height_rasio ( height );
	return a;
}


int Set_Font_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) {
	RGBT rgbt;
	int a;

	rgbt.r = r;
	rgbt.g = g;
	rgbt.b = b;
	rgbt.t = 255;

	a = Set_Font_Colour ( rgbt );

	return a;
}

// 20250814
// it sets fore_ground_colour
int Set_Foreground_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) {
	RGBT rgbt;
	int a;

	rgbt.r = r;
	rgbt.g = g;
	rgbt.b = b;
	rgbt.t = 255;

	a = Set_Foreground_Colour( rgbt );

	return a;
}

int Set_Background_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) {
	RGBT rgbt;
	int a;

	rgbt.r = r;
	rgbt.g = g;
	rgbt.b = b;
	rgbt.t = 255;

	a = Set_Background_Colour ( rgbt );

	return a;
}

int Set_Grid_Colour_Rgb ( unsigned char r, unsigned char g, unsigned char b ) {
	RGBT rgbt;
	int a;

	rgbt.r = r;
	rgbt.g = g;
	rgbt.b = b;
	rgbt.t = 255;

	a = Set_Grid_Colour ( rgbt );

	return a;
}

int Set_Foreground_Colour ( RGBT rgbt ) {
	if ( p_jackson ==NULL ) return -1;
	p_jackson->fore_ground_colour.r = rgbt.r;
	p_jackson->fore_ground_colour.g = rgbt.g;
	p_jackson->fore_ground_colour.b = rgbt.b;
	p_jackson->fore_ground_colour.t = rgbt.t;
	return 0;
}


int Set_Background_Colour ( RGBT rgbt ) {
	if ( p_jackson ==NULL ) return -1;
	p_jackson->back_ground_colour.r = rgbt.r;
	p_jackson->back_ground_colour.g = rgbt.g;
	p_jackson->back_ground_colour.b = rgbt.b;
	p_jackson->back_ground_colour.t = rgbt.t;
	return 0;
}

int Set_Grid_Colour ( RGBT rgbt ) {
	if ( p_jackson ==NULL ) return -1;
	p_jackson->grid_colour.r = rgbt.r;
	p_jackson->grid_colour.g = rgbt.g;
	p_jackson->grid_colour.b = rgbt.b;
	p_jackson->grid_colour.t = rgbt.t;
	return 0;
}

int Set_Support_Number_001 (int num) {
	if ( p_jackson ==NULL ) return -1;
	p_jackson->number = num;
	return 0;
}

int Set_Support_Number (int num) {
	int a;
	if ( p_jackson ==NULL ) return -1;
	p_jackson->number = num;

	a = set_number();
	return 0;
}


int Set_Background_Rect (int sx, int sy, int w, int h) {
	int i, j, ex, ey;
	int *hh;

	if ( p_jackson ==NULL ) return -1;

	hh = (int*) &(p_jackson->back_ground_colour);
	ex = sx + w;
	ey = sy + h;
	for ( j = sy; j<ey; j++ ) {
		for ( i = sx; i<ex; i++ ) {
			p_jackson->canvas[i][j] = (int) *hh;
		}
	}

	return 0;
}

//
int Process_and_History (char* p_msg_string ) {
	int a;

	a = stack_msg_string (p_msg_string);

	return 0;
}

// p_jackson->history
// p_jackson->history_pix_middle_index
// p_jackson->history_index
// p_jackson->history_last_index
//
int stack_msg_string (char* p_msg_string ) {
	int a;
	int i;

	if ( p_jackson == NULL ) return -1;

	if ( p_jackson->history == NULL ) {
		p_jackson->history_last_index = 8;
		p_jackson->history = (char**) malloc ( p_jackson->history_last_index * sizeof(char) );
	} else {
		p_jackson->history_last_index *= 2;
		p_jackson->history = (char**) realloc ( p_jackson->history, p_jackson->history_last_index * sizeof(char) );
	}

	if ( p_jackson->history == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("p_jackson->history could not be allocated.\r\n");
		exit(-1);
	}


	p_jackson->history[ p_jackson->history_index ] = (char*) p_msg_string;
	p_jackson->history_index++; 

	return 0;
}

int devide_num_history_focus_box (int num ) {
	int brunch;

	brunch = p_jackson->history_focus_last_index / num + 1;

	return 0;
}

int initialize_history_focus_box () {

	if ( p_jackson->history_focus  == NULL ) {
		p_jackson->history_focus_index = 0;
		p_jackson->history_focus_last_index = 8;
		p_jackson->history_focus = (HISTORYFOCUS*) malloc ( sizeof(HISTORYFOCUS) * p_jackson->history_focus_last_index );
	}

	if ( p_jackson->history_focus  == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("initialize_history_focus_box exits.\r\n");
		exit(-1);
	}
	return 0;
}


// Number -> Circle
// Number -> Rectangle
// Number -> Triangle
//
// Draw_Rigth_Top_003 -> Draw_Jackson_Focus_Circle
//
int Draw_Jackson_Focus_Circle () {
	int i, j, a;
	int to_width, to_height, *hh;
	int inside = 0;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Circle () starts.\r\n");

	a = create_draw_focus_circle ();

	hh = (int*) &(p_jackson->fore_ground_colour);

	if ( debug_print_msg_param () == 1 ) printf( "x %d, y %d, w %d, h %d \r\n", p_jackson->draw_focus.start_x, p_jackson->draw_focus.start_y, p_jackson->draw_focus.width, p_jackson->draw_focus.height );
	if ( debug_print_msg_param () == 1 ) printf ( "p_jackson->circle_r %f \r\n", p_jackson->circle_r );

	to_width = p_jackson->draw_focus.start_x + p_jackson->draw_focus.width;
	to_height = p_jackson->draw_focus.start_y + p_jackson->draw_focus.height;

	// 20250613
	// to_width
	// to_height

	for ( i = p_jackson->draw_focus.start_x; i< to_width; i++ )
	for ( j = p_jackson->draw_focus.start_y; j< to_height; j++ ) {
		if ( debug_print_msg_param () == 1 ) printf("(i %d, j %d) = ", i, j );
		inside = inside_circle ( i, j );
		if ( debug_print_msg_param () == 1 ) printf("inside %d\r\n", inside );
		if ( inside == 1 ) p_jackson->canvas[(int)i][(int)j] = (int) *hh;
		if ( debug_print_msg_param () == 1 ) printf("\r\n");
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Circle () ends.\r\n");
	return 0;
}

//
int inside_circle ( int i, int j ) {
	double x, y, dist;

	x =  i - p_jackson->circle_center_x;
	y =  j - p_jackson->circle_center_y;

	if ( debug_print_msg_param () == 1 ) printf( "circle_center(%f,%f) ->(%f, %f) ", p_jackson->circle_center_x, p_jackson->circle_center_y, x, y );

	dist = x*x + y*y;
	dist = sqrt(dist);

	if ( debug_print_msg_param () == 1 ) printf("dist %f circle_r %f\r\n", dist, p_jackson->circle_r);

	if ( dist < p_jackson->circle_r ) return 1;

	return 0;
}

//
int set_circle (double cx, double cy, double r) {
	int ax, ay, ar, a;
	if ( debug_print_msg_param () == 1 ) printf("int set_circle ( %0.3f, %0.3f, %0.3f) starts.\r\n", cx, cy, r);

	p_jackson->circle_center_x = cx;
	p_jackson->circle_center_y = cy;
	p_jackson->circle_r = r;

	ar = (int)r + 2;
	ax = (int)cx - ar;
	ay = (int)cy - ar;

	a = set_draw_focus ( ax, ay, ar , ar );

	if ( debug_print_msg_param () == 1 ) printf("int set_circle ( %0.3f, %0.3f, %0.3f) ends.\r\n", cx, cy, r);
	return 0;
}


// Draw_Rigth_Top_003 -> Draw_Jackson_Focus_Rectangle
//
int Draw_Jackson_Focus_Rectangle () {
	int i, j, a;
	int *hh;
	int to_width, to_height;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Rectangle () starts.\r\n");

	to_width = p_jackson->draw_focus.start_x + p_jackson->draw_focus.width;
	to_height = p_jackson->draw_focus.start_y + p_jackson->draw_focus.height;

	hh = (int*) &(p_jackson->back_ground_colour);

	// algo
	for ( j = p_jackson->draw_focus.start_y; j<to_height; j++ )
	for ( i = p_jackson->draw_focus.start_x; i<to_width; i++ ) {
		p_jackson->canvas[i][j] = (int) *hh;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Rectangle () ends.\r\n");
	return 0;
}

// Draw_Rigth_Top_003 -> Draw_Jackson_Focus_Rectangle
//
int Draw_Jackson_Focus_Rectangle_org () {
	int i, j, ac, num, a, cnt;
	char* p_num;
	int width, height;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Rectangle () starts.\r\n");

	p_num = (char*)p_jackson->char_str_number;
	ac = array_count( p_num );
	cnt = 0;
	num = 0;

	width = p_jackson->fonts_focus[0].width * p_jackson->font_rasio;
	height = p_jackson->fonts_focus[0].height * p_jackson->font_rasio;

	if ( debug_print_msg_param () == 1 ) printf("num %d p_num|%s| ac %d [0]=|%d|\r\n", num, p_num, ac, p_num[0]);
	for ( i = p_jackson->draw_focus.start_x; cnt<ac; i += width ) {
		a = set_small_focus ( i, p_jackson->draw_focus.start_y, width, height );
		num = p_num[cnt] - '0';
		a = Draw_Focus_Number ( num );
		cnt++;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Rectangle () ends.\r\n");
	return 0;
}



// Draw_Rigth_Top_003 -> Draw_Jackson_Focus_Triangle
//
int Draw_Jackson_Focus_Triangle () {
	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Triangle () starts.\r\n");


	if ( debug_print_msg_param () == 1 ) printf("int Draw_Jackson_Focus_Triangle () ends.\r\n");
	return 0;
}


//
int Interface_Draw_Jackson (int (*function_name () ) ) {
	if ( debug_print_msg_param () == 1 ) printf("int Interface_Draw_Jackson (int (*function_name () ) ) starts.\r\n");
	if ( debug_print_msg_param () == 1 ) printf("function_name %s \r\n", (char*) function_name );

	stack_msg_string((char*) function_name );

	if ( debug_print_msg_param () == 1 ) printf("int Interface_Draw_Jackson (int (*function_name () ) ) ends.\r\n");
	return 0;
}

// <math.h> fabs
int Line_To (int x1, int y1, int x2, int y2) {
	int flip = 0;
	double a;
	int value;
	if ( debug_print_msg_param () == 1 ) printf("int Line_To (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	switch (flip) {
	case 0:
		value = line_to ( x1, y1, x2, y2, a );
		break;
	case 1:
		value = line_to ( x2, y2, x1, y1, a );
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Line_To (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}


//
int line_to (int x1, int y1, int x2, int y2, double a) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	double base = 1.0;

	if ( debug_print_msg_param () == 1 ) printf("int line_to (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (int) x1;
	j = (int) y1;
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );
		if ( flag == 0 && i - 0.5 > x2 ) {
			if ( debug_print_msg_param () == 1 ) printf("break because of the end of line.\r\n");
			break;
		}
		if ( flag == 1 &&  j - 0.5 > y2 ) {
			if ( debug_print_msg_param () == 1 ) printf("break because of the end of line.\r\n");
			break;
		}
		skip = 0;
		if ( i + 0.5 >= p_jackson->canvas_focus.width || j + 0.5 >= p_jackson->canvas_focus.height ) {
			if ( cnt == 0 ) {
				if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas of width or height and cnt 0.\r\n");
				skip = 1;
			} else {
				if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas of width or height.\r\n");
				break;
			}
		}

		if ( i < 0 || j < 0 ) {
			if ( cnt == 0 ) {
				if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas memories of 0 and cnt 0.\r\n");
				skip = 1;
			} else {
				if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas memories of 0.\r\n");
				break;
			}
		}

		if ( skip == 0 ) p_jackson->canvas[(int)i][(int)j] = (int) *hh;
		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;

		if (flag == 1 ) {
			j += base;
			i += a;
		} else {
			i += base;
			j += a;
		}

	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}

// p_jackson
int check_draw_line_to () {
	return 1;
}

// p_jackson
// is_initialized : for objects.
//
int check_draw_circle () {
	if (is_initialized () != 1 ) {
		if ( debug_print_msg_param () == 1 ) printf("... is not initialized.\r\n");
		return -1;
	}
	return 1;
}

// p_jackson
int check_break_draw_line_to () {
	return 1;
}

// p_jackson
int check_break_draw_circle () {
	return 1;
}

// p_jackson
int check_continue_draw_line_to () {
	return 1;
}

// p_jackson
int check_continue_draw_circle () {
	return 1;
}

// p_jackson
int check_draw_string () {
	if ( p_jackson == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("p_jackson is null.\r\n");
		return -1;
	}

	if ( p_jackson->char_str_number == NULL ) {
		if ( debug_print_msg_param () == 1 ) printf("p_jackson->char_str_number is null.\r\n");
		return -1;
	}
	return 1;
}

// p_jackson
int check_break_draw_string () {
	return 1;
}

// p_jackson
int check_continue_draw_string () {
	return 1;
}

// 20250814
// it doesn't touch fore_ground_colour
int create_draw_focus_circle ( ) {
	int width;
	int height;
	int margin = 1;

	p_jackson->draw_focus.start_x = p_jackson->circle_center_x - p_jackson->circle_r + margin;
	p_jackson->draw_focus.start_y = p_jackson->circle_center_y - p_jackson->circle_r + margin;
	p_jackson->draw_focus.width = 2.0 * p_jackson->circle_r + margin;
	p_jackson->draw_focus.height = 2.0 * p_jackson->circle_r + margin;

	width = p_jackson->draw_focus.width;
	height = p_jackson->draw_focus.height;

	//20240612
	if ( p_jackson->draw_focus.start_x < 0 ) p_jackson->draw_focus.start_x = 0;
	if ( p_jackson->draw_focus.start_y < 0 ) p_jackson->draw_focus.start_y = 0;

	if ( p_jackson->draw_focus.start_x + width >= p_jackson->canvas_focus.width )  p_jackson->draw_focus.width = p_jackson->draw_focus.start_x - p_jackson->canvas_focus.width;
	if ( p_jackson->draw_focus.start_y + height >= p_jackson->canvas_focus.height ) p_jackson->draw_focus.height = p_jackson->draw_focus.start_y - p_jackson->canvas_focus.height;

	return -1;
}


//
int Draw_Circle ( float x, float y, float r ) {
	int a;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle ( %0.3f, %0.3f, %0.3f ) starts.\r\n", x, y, r );

	a = set_circle ( x, y, r );
	a = Draw_Jackson_Focus_Circle ();
	// exit(-1); 20250520

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle ( %0.3f, %0.3f, %0.3f ) ends.\r\n", x, y, r );
	return 0;
}

// float input
int line_to_002 (float x1, float y1, float x2, float y2, double a, int stack ) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	double base = 1.0;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_002 (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (double) x1;
	j = (double) y1;
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );
		if ( flag == 0 && i - 0.5 > x2 ) {
			if ( debug_print_msg_param () == 1 ) printf("break because of the end of line.\r\n");
			break;
		}
		if ( flag == 1 &&  j - 0.5 > y2 ) {
			if ( debug_print_msg_param () == 1 ) printf("break because of the end of line.\r\n");
			break;
		}
		skip = 0;
		if ( i + 0.5 >= p_jackson->canvas_focus.width || j + 0.5 >= p_jackson->canvas_focus.height ) {
			if ( cnt == 0 ) {
				if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas of width or height and cnt 0.\r\n");
				skip = 1;
			} else {
				if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas of width or height.\r\n");
				break;
			}
		}

		if ( i < 0 || j < 0 ) {
			if ( cnt == 0 ) {
				if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas memories of 0 and cnt 0.\r\n");
				skip = 1;
			} else {
				if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas memories of 0.\r\n");
				break;
			}
		}

		if ( skip == 0 ) {
			p_jackson->canvas[(int)i][(int)j] = (int) *hh;
			if ( stack == 1 ) a = line_stack ( (float)i, (float)j, 1 );
			if ( stack == 2 ) a = line_stack ( (float)i, (float)j, 2 );
		}

		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;

		if (flag == 1 ) {
			j += base;
			i += a;
		} else {
			i += base;
			j += a;
		}

	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_002 (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}


int line_stack (float x, float y, int num) {

	return 0;
}

//
int polygon_to (float x1, float y1, float x2, float y2, float x3, float y3 ) {
	double d1, d2, d3;
	int flag = 0;
	int a;

	d1 = distance_to (x1, y1, x2, y2);
	d2 = distance_to (x2, y2, x3, y3);
	d3 = distance_to (x3, y3, x1, y1);

	switch ( flag ) {
	case 0:
		a = line_to_002_01 ( x1, y1, x2, y2, 1 );
		a = line_to_002_01 ( x2, y2, x3, y3, 2 );
		break;
	case 1:
		a = line_to_002_01 ( x2, y2, x3, y3, 1 );
		a = line_to_002_01 ( x3, y3, x1, y1, 2 );
		break;
	case 2:
		a = line_to_002_01 ( x3, y3, x1, y1, 1 );
		a = line_to_002_01 ( x1, y1, x2, y2, 2 );
		break;
	}

	return 0;
}

//
int line_to_002_01 (float x1, float y1, float x2, float y2, int stack ) {
	double a;
	int flip = 0;
	int value;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_002_01 (%0.3f, %0.3f, %0.3f, %0.3f, stack=%d a=%0.3f) starts.\r\n", (float) x1, (float) y1, (float) x2, (float) y2, stack, (double) a);

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	switch (flip) {
	case 0:
		value = line_to_002 ( x1, y1, x2, y2, a , stack );
		break;
	case 1:
		value = line_to_002 ( x2, y2, x1, y1, a, stack );
		break;
	}


	if ( debug_print_msg_param () == 1 ) printf("int line_to_002_01 (%0.3f, %0.3f, %0.3f, %0.3f, stack=%d a=%0.3f) end.\r\n", (float) x1, (float) y1, (float) x2, (float) y2, stack, (double) a);
	return 0;
}

//
double distance_to (float x1, float y1, float x2, float y2) {
	double a;
	a = ( x2 -x1 ) * ( x2 -x1 ) + ( y2 - y1 ) * ( y2 -y1 );

	return sqrt(a);
}


// 20240903
// float input
int line_to_003 (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	int aa;
	double	da_m_base;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003 (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (double) x1;
	j = (double) y1;

	// first step
	aa = first_line_to_003 ( (float) x1, (float) y1, (float) x2, (float) y2, (double) a, (float) base, flag, type, first_type, cnt, (double*) &i, (double*) &j )  ;
	if ( aa == 1 ) cnt++;

	da_m_base = a * base ;
	// step works and their code blocks for easiness
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );

		aa = check_break_line_to_003_01 ( (double) i, (double) j, (int) flag, (int) x2, (int) y2 ) ;
		if ( aa == 1 ) break;
		aa = check_break_line_to_003_02 ( (double) i, (double) j, (int) flag, (int) cnt, (int*) &skip ) ;
		if ( aa == 1 ) break;

		// 
		// 20240904
		aa = draw_circle_line_to_fix1 ((double) i, (double) j, (float) base, skip, type );

		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;

		if (flag == 1 ) {
			j += base;
			i += da_m_base;
		} else {
			i += base;
			j += da_m_base;
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003 (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}


// 20240904
// float input
int line_to_004 (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	int aa;
	double	da_m_base;
	int ii, jj, p_ii, p_jj;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_004 (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (double) x1;
	j = (double) y1;

	ii = (int)( i / base);
	jj = (int)( j / base);
	ii *= base;
	jj *= base;

	// 20240905
	// first step
	// type 1:
//	aa = first_line_to_003 ( (float) x1, (float) y1, (float) x2, (float) y2, (double) a, (float) base, flag, 1, first_type, cnt, (double*) &i, (double*) &j )  ;
//	if ( aa == 1 ) cnt++;

	p_ii = -1;
	p_jj = -1;

	da_m_base = a * base ;
	// step works and their code blocks for easiness
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );

		aa = check_break_line_to_003_01 ( (double) i, (double) j, (int) flag, (int) x2, (int) y2 ) ;
		if ( aa == 1 ) break;
		aa = check_break_line_to_003_02 ( (double) i, (double) j, (int) flag, (int) cnt, (int*) &skip ) ;
		if ( aa == 1 ) break;

		ii = (int)( i / base);
		jj = (int)( j / base);
		ii *= base;
		jj *= base;

		// 20240904
		// additional part
		// diagnal: first_type 1:
		// fabs is not necesarry.
		if ( p_ii != -1 && p_jj != -1 && abs(ii - p_ii) >= fabs(base) && abs(ii - p_jj) >= fabs(base) && first_type == 1 ){
			if ( flag == 1 ) {
				aa = draw_circle_line_to_fix1 ((double) p_ii, (double) jj, (float) base, skip, type );
			} else {
				aa = draw_circle_line_to_fix1 ((double) ii, (double) p_jj, (float) base, skip, type );
			}
		}

		// 20240904
		aa = draw_circle_line_to_fix1 ((double) ii, (double) jj, (float) base, skip, type );

		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;

		p_ii = ii;
		p_jj = jj;

		if (flag == 1 ) {
			j += base;
			i += da_m_base;
		} else {
			i += base;
			j += da_m_base;
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_004 (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}

// 20240905
// type 1
// type 2 fraction
//
//
//
int draw_circle_line_to_003 ( double i, double j, float base, int skip, int type ) {
	int a_i, a_j;
	int aa;
	double fi, fj;
	double frac;
	RGBT rgbt;

	if ( debug_print_msg_param () == 1 ) printf("skip %d type %d \r\n", skip, type);

	if ( type >= 2 ) 
		frac = base / 2.0;
	else
		frac = base * 0.99;

	if ( skip == 0 ) {
		if ( type >= 1 ) {
			if ( type == 2 ) {
				a_i = (i + base / 2.0) / base;
				a_j = (j + base / 2.0) / base;
			} else {
				a_i = i / base;
				a_j = j / base;
			}
			a_i *= base;
			a_j *= base;
			fi = i - a_i;
			fj = j - a_j;
			if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d) f(%0.3f,%0.3f) base %0.3f frac %0.3f\r\n", a_i, a_j, fi, fj, base, frac );
			if ( fi >= frac || fj >= frac ) {
				aa = Get_Font_Colour ( &rgbt );
				aa = Set_Font_Colour_Rgb ( 0, 0, 255 );
				aa = Draw_Circle( (float) i, (float) j, base/2.0 ); //r
				aa = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );
			} else
				aa = Draw_Circle( (float) a_i, (float) a_j, base/2.0 ); //r
		} else aa = Draw_Circle( i, j, base/2.0 ); //r
	}

	return 0;
}


// type 1
// type 2 fraction
//
//
//
int draw_circle_line_to_003_Normal ( double i, double j, float base, int skip, int type ) {
	int a_i, a_j;
	int aa;
	double fi, fj;
	double frac;
	RGBT rgbt;

	if ( debug_print_msg_param () == 1 ) printf("skip %d type %d \r\n", skip, type);

	if ( type >= 2 ) 
		frac = base / 2.0;
	else
		frac = base * 0.99;

	if ( skip == 0 ) {
		if ( type >= 1 ) {
			if ( type == 2 ) {
				a_i = (i + base / 2.0) / base;
				a_j = (j + base / 2.0) / base;
			} else {
				a_i = i / base;
				a_j = j / base;
			}
			a_i *= base;
			a_j *= base;
			fi = i - a_i;
			fj = j - a_j;
			if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d) f(%0.3f,%0.3f) base %0.3f frac %0.3f\r\n", a_i, a_j, fi, fj, base, frac );
			if ( fi >= frac ) { 
				aa = Get_Font_Colour ( &rgbt );
				aa = Set_Font_Colour_Rgb ( 0, 128, 0 );
				aa = Draw_Circle( (float) a_i + base,  (float) a_j, base/2.0 ); //r
				aa = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );
			} else if ( fj >= frac ) {
				aa = Get_Font_Colour ( &rgbt );
				aa = Set_Font_Colour_Rgb ( 0, 128, 0 );
				aa = Draw_Circle( (float) a_i, (float) a_j + base, base/2.0 ); //r
				aa = Set_Font_Colour_Rgb ( rgbt.r, rgbt.g, rgbt.b );
			} else {
				aa = Draw_Circle( (float) a_i, (float) a_j, base/2.0 ); //r
			}
		} else aa = Draw_Circle( i, j, base/2.0 ); //r
	}

	return 0;
}


// 5 -> 1
// 6 -> 1
// type 1
// type 2 fraction
//
//
//
int draw_circle_line_to_003_Normal_05 ( double i, double j, float base, int skip, int type ) {
	int a_i, a_j;
	int aa;
	double fi, fj;
	double frac;
	RGBT rgbt;

	if ( debug_print_msg_param () == 1 ) printf("skip %d type %d \r\n", skip, type);

	if ( type >= 2 ) 
		frac = base / 2.0;
	else
		frac = base * 0.99;

	if ( skip == 0 ) {
		if ( type >= 1 ) {
			if ( type == 2 ) {
				a_i = (i + base / 2.0) / base;
				a_j = (j + base / 2.0) / base;
			} else {
				a_i = i / base;
				a_j = j / base;
			}
			a_i *= base;
			a_j *= base;
			fi = i - a_i;
			fj = j - a_j;
			if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d) f(%0.3f,%0.3f) base %0.3f frac %0.3f\r\n", a_i, a_j, fi, fj, base, frac );
			if ( fi >= frac ) { 
				aa = Draw_Circle( (float) a_i + base,  (float) a_j, base / 2.0 ); //r
			} else if ( fj >= frac ) {
				aa = Draw_Circle( (float) a_i, (float) a_j + base, base/2.0 ); //r
			} else {
				aa = Draw_Circle( (float) a_i, (float) a_j, base/2.0 ); //r
			}
		} else aa = Draw_Circle( i, j, base/2.0 ); //r
	}

	return 0;
}


//
int check_break_line_to_003_02 ( double i, double j, int flag, int cnt, int* skip ) {
	*skip = 0;
	if ( i + 0.5 >= p_jackson->canvas_focus.width || j + 0.5 >= p_jackson->canvas_focus.height ) {
		if ( cnt == 0 ) {
			if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas of width or height and cnt 0.\r\n");
			*skip = 1;
			return 0;
		} else {
			if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas of width or height.\r\n");
			return 1;
		}
	}

	if ( i < 0 || j < 0 ) {
		if ( cnt == 0 ) {
			if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas memories of 0 and cnt 0.\r\n");
			*skip = 1;
			return 0;
		} else {
			if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas memories of 0.\r\n");
			return 1;
		}
	}

	return 0;
}

// 20240903
//
int check_break_line_to_003_01 ( double i, double j, int flag, int x2, int y2 ) {

	if ( flag == 0 && i - 0.5 > x2 ) {
		if ( debug_print_msg_param () == 1 ) printf("check1-1 break because of the end of line as j %0.3f/%d.\r\n", i, x2);
		return 1;
	}

	if ( flag == 1 &&  j - 0.5 > y2 ) {
		if ( debug_print_msg_param () == 1 ) printf("check1-2 break because of the end of line as j %0.3f/%d.\r\n", j, y2);
		return 1;
	}

	return 0;
}

// float input
int line_to_003_org (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	int aa;
	int a_i, a_j;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003 (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (double) x1;
	j = (double) y1;
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );
		if ( flag == 0 && i - 0.5 > x2 ) {
			if ( debug_print_msg_param () == 1 ) printf("break because of the end of line.\r\n");
			break;
		}
		if ( flag == 1 &&  j - 0.5 > y2 ) {
			if ( debug_print_msg_param () == 1 ) printf("break because of the end of line.\r\n");
			break;
		}
		skip = 0;
		if ( i + 0.5 >= p_jackson->canvas_focus.width || j + 0.5 >= p_jackson->canvas_focus.height ) {
			if ( cnt == 0 ) {
				if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas of width or height and cnt 0.\r\n");
				skip = 1;
			} else {
				if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas of width or height.\r\n");
				break;
			}
		}

		if ( i < 0 || j < 0 ) {
			if ( cnt == 0 ) {
				if ( debug_print_msg_param () == 1 ) printf("continue because of the out of canvas memories of 0 and cnt 0.\r\n");
				skip = 1;
			} else {
				if ( debug_print_msg_param () == 1 ) printf("break because of the out of canvas memories of 0.\r\n");
				break;
			}
		}


		// a = check_break_line_to_003 ( (double) i, (double)j, flag, &skip );

		if ( skip == 0 ) {
			if ( type >= 1 ) {
				if ( type == 2 ) {
					a_i = (i + base / 2.0) / base;
					a_j = (j + base / 2.0) / base;
				} else {
					a_i = i / base;
					a_j = j / base;
				}
				a_i *= base;
				a_j *= base;
				if ( debug_print_msg_param () == 1 ) printf("a(i,j) =(%d,%d)\r\n", a_i, a_j );
				aa = Draw_Circle( (float) a_i, (float) a_j, base/2.0 ); //r
			} else aa = Draw_Circle( i, j, base/2.0 ); //r
		}

		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;

		if (flag == 1 ) {
			j += base;
			i += a * base;
		} else {
			i += base;
			j += a * base;
		}

		if ( first_type == 1 && cnt == 1 ) {
			if (flag == 1 ) {
				i -= a * base;
			} else {
				j -= a * base;
			}
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003 (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}

// 20240905
// type 0: normal
// type 1: fraction
// type 2: fraction slide a centered a little.
// first_type: 0 as straight
// first_type: 1 as diagnal under not over
//
//
int first_line_to_003 (float x1, float y1, float x2, float y2, double a, float base, int flag, int type, int first_type, int cnt, double *i, double *j )  {
	int aa;
	int skip;

	aa = check_break_line_to_003_01 ( (double) *i, (double) *j, (int) flag, (int) x2, (int) y2 ) ;
	if ( aa == 1 ) return -1;
	aa = check_break_line_to_003_02 ( (double) *i, (double) *j, (int) flag, (int) cnt, (int*) &skip ) ;
	if ( aa == 1 ) return -1;

	aa = draw_circle_line_to_fix1 ( (double) *i, (double) *j, (float) base, skip, type ) ;

	if (flag == 1 ) {
		*j += base;
		*i += a * base;
	} else {
		*i += base;
		*j += a * base;
	}

	if ( first_type == 1 && cnt == 0 ) {
		if (flag == 1 ) {
			*i -= a * base;
		} else {
			*j -= a * base;
		}
	}

	if ( skip != 0 ) return -1;

	return 1;
}

//
int Draw_Circle_Line_grid (float base_x1, float x1, float y1, float x2, float y2, float bold, int type, int first_type ) {
	double a;
	int flip = 0;
	int value;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_grid (float base_x1, float x1, float y1, float x2, float y2, float bold, int type, int first_type ) starts.\r\n");

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	switch (flip) {
	case 0:
		value = line_to_003 ( x1, y1, x2, y2, a , bold * 2.0, type, first_type );
		break;
	case 1:
		value = line_to_003 ( x2, y2, x1, y1, a, bold * 2.0, type, first_type );
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_grid (float base_x1, float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ends.\r\n");
	return 0;
}

//20240903
int Draw_Circle_Line_Power_Flag (float x1, float y1, float x2, float y2, float power, int flag, float bold, int type, int first_type ) {
	double a;
	int flip = 0;
	int value;
	int aa;
	float bold_001;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_Power_Flag (float x1, float y1, float x2, float y2, float power, int flag, float bold, int type, int first_type ) starts.\r\n");


	if ( debug_print_msg_param () == 1 ) printf("%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d,%0.3f,%d,%d\r\n",   x1,   y1,   x2,   y2,   power,   flag,   bold,   type,   first_type);

	bold_001 = bold;
	if ( bold_001 < 0.0 ) bold_001 *= -1.0;


	if (flag == 1 ) 
		aa = Draw_Circle_Line ( (float)power, y1, x2, y2,  bold_001, type, first_type );
	else
		aa = Draw_Circle_Line ( x1, (float)power, x2, y2,  bold_001, type, first_type );

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_Power_Flag (float x1, float y1, float x2, float y2, float power, int flag, float bold, int type, int first_type ) ends.\r\n");
	return 0;
}

//20240904
int Draw_Circle_Line_004 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) {
	double a;
	int flip = 0;
	int value;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_004 (float x1, float y1, float x2, float y2, float bold ) starts.\r\n");

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	// 20240904
	// diagnal first_type 1
	switch (flip) {
	case 0:
		value = line_to_004 ( x1, y1, x2, y2, a , bold * 2.0, type, first_type );
		break;
	case 1:
		value = line_to_004 ( x2, y2, x1, y1, a, bold * 2.0, type, first_type );
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_004 (float x1, float y1, float x2, float y2, float bold ) ends.\r\n");
	return 0;
}



//20240903
int Draw_Circle_Line (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) {
	double a;
	int flip = 0;
	int value;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line (float x1, float y1, float x2, float y2, float bold ) starts.\r\n");

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	// 20240904
	switch (flip) {
	case 0:
		value = line_to_003 ( x1, y1, x2, y2, a , bold * 2.0, type, first_type );
		break;
	case 1:
		value = line_to_003 ( x2, y2, x1, y1, a, bold * 2.0, type, first_type );
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line (float x1, float y1, float x2, float y2, float bold ) ends.\r\n");
	return 0;
}

//
int Draw_Circle_Line_Fraction (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) {
	double a;
	int flip = 0;
	int value;

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_Fraction (float x1, float y1, float x2, float y2, float bold ) starts.\r\n");

	a = (double)( y2 - y1 ) / (double)( x2 - x1 );

	if ( x1 > x2 ) flip = 1;
	if ( y1 > y2 && fabs(a) > 1.0 ) flip = 1;
	if ( y1 < y2 && fabs(a) > 1.0 ) flip = 0;

	if ( debug_print_msg_param () == 1 ) printf("flip %d\ a %f\r\n", flip, a);

	switch (flip) {
	case 0:
		value = line_to_003_fraction ( x1, y1, x2, y2, a , bold * 2.0, type, first_type );
		break;
	case 1:
		value = line_to_003_fraction ( x2, y2, x1, y1, a, bold * 2.0, type, first_type );
		break;
	}

	if ( debug_print_msg_param () == 1 ) printf("int Draw_Circle_Line_Fraction (float x1, float y1, float x2, float y2, float bold ) ends.\r\n");
	return 0;
}


// float input
int line_to_003_fraction (float x1, float y1, float x2, float y2, double a, float base, int type, int first_type) {
	int flag = 0;
	int skip = 0;
	int cnt = 0;
	double i, j;
	int *hh;
	int aa;
	double err = 0.0001;
	double err_10 = 0.001;

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_fraction (int %4d, int %4d, int %4d, int %4d, double %0.3f) starts.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);

	if ( fabs(a) > 1.0 ) { flag = 1; a = 1.0 / a; }

	hh = (int*) &(p_jackson->fore_ground_colour);
	i = (double) x1;
	j = (double) y1;

	// first step
	aa = first_line_to_003 ( (float) x1, (float) y1, (float) x2, (float) y2, (double) a, (float) base, flag, type, first_type, cnt, (double*) &i, (double*) &j )  ;
	if ( aa == 1 ) cnt++;

	// step works and their code blocks for easiness
	while(1) {
		if ( debug_print_msg_param () == 1 ) printf("i %0.3f j %0.3f ", i, j );

		aa = check_break_line_to_003_01 ( (double) i, (double) j, (int) flag, (int) x2, (int) y2 ) ;
		if ( aa == 1 ) break;
		aa = check_break_line_to_003_02 ( (double) i, (double) j, (int) flag, (int) cnt, (int*) &skip ) ;
		if ( aa == 1 ) break;

		aa = draw_circle_line_to_003 ( (double) i, (double) j, (float) base, skip, type ) ;

		if ( debug_print_msg_param () == 1 ) printf("v %d\r\n", (int)*hh );
		if ( skip == 0 ) cnt++;

		if (flag == 1 ) {
			j += base;
			i += a * base;
		} else {
			i += base;
			j += a * base;
		}

		if ( cnt % 10 == 0 ) {
			i -= err_10;
			j -= err_10;
		} else {
			i += err;
			j += err;
		}
	}

	if ( debug_print_msg_param () == 1 ) printf("int line_to_003_fraction (int %4d, int %4d, int %4d, int %4d, double %0.3f) ends.\r\n", (int) x1, (int) y1, (int) x2, (int) y2, (double) a);
	return 0;
}

//---  Reinitialize starts. ---
// 20250916
// return -2 :
// return 1  :
int Reinitialize_Refresh_Several_Focus_001_01 () {
	static ANIMATION_FOCUS** a;
	int i, num, b;

	printf("int Reinitialize_Refresh_Several_Focus_001_01 () starts.\r\n");
	printf("modifing... \r\n");

	a = (ANIMATION_FOCUS**)p_jackson->several_focus.child;
	num = p_jackson->several_focus.history_several_focus_last_index;

	p_jackson->several_focus.history_several_focus_last_index *= 2;
	p_jackson->several_focus.child = NULL;

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	printf("sizeof(ANIMATION_FOCUS*) %d * p_jackson->several_focus.history_several_focus_last_index %d\r\n", sizeof(ANIMATION_FOCUS*), p_jackson->several_focus.history_several_focus_last_index);
	printf("sizeof(int*) %d\r\n", sizeof(int*) );
	printf("sizeof(int**) %d\r\n", sizeof(int**) );
	printf("sizeof(ANIMATION_FOCUS) %d\r\n", sizeof(ANIMATION_FOCUS) );

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	b = wait_sharp_short_time ();
	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	b = wait_sharp_short_time ();
	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		p_jackson->several_focus.child = (ANIMATION_FOCUS**) a;
		p_jackson->several_focus.history_several_focus_last_index /= 2;
		printf(" -> recover for paging backup|%p| reset|%p| last index |%d|\r\n", a, p_jackson->several_focus.child, p_jackson->several_focus.history_several_focus_last_index);
		printf("return -2.\r\n");
		return -2;
	}

	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	for ( i=0; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// copy
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = a[i];
	}

	// release array only
	free ( a );

	printf( "re -> index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Reinitialize_Refresh_Several_Focus_001_01 () ends.\r\n");
	return 1;
}

int Reinitialize_Refresh_Several_Focus_001_02 () {
	static ANIMATION_FOCUS** a;
	int i, num, b;

	printf("int Reinitialize_Refresh_Several_Focus_001_02 () starts.\r\n");
	printf("modifing... \r\n");

	a = (ANIMATION_FOCUS**)p_jackson->several_focus.child;
	num = p_jackson->several_focus.history_several_focus_last_index;

	p_jackson->several_focus.history_several_focus_last_index *= 2;
	p_jackson->several_focus.child = NULL;

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	printf("sizeof(ANIMATION_FOCUS*) %d * p_jackson->several_focus.history_several_focus_last_index %d\r\n", sizeof(ANIMATION_FOCUS*), p_jackson->several_focus.history_several_focus_last_index);
	printf("sizeof(int*) %d\r\n", sizeof(int*) );
	printf("sizeof(ANIMATION_FOCUS) %d\r\n", sizeof(ANIMATION_FOCUS) );

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	b = wait_sharp_short_time ();
	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	b = wait_sharp_short_time ();
	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		exit(-1);
	}

	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	for ( i=0; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// copy
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = a[i];
	}

	// release array only
	free ( a );

	printf( "re -> index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Reinitialize_Refresh_Several_Focus_001_02 () ends.\r\n");
	return 1;
}

int Reinitialize_Refresh_Several_Focus_001_03 () {
	static ANIMATION_FOCUS** a;
	int i, num, b;

	printf("int Reinitialize_Refresh_Several_Focus_001_03 () starts.\r\n");
	printf("modifing... \r\n");

	a = (ANIMATION_FOCUS**)p_jackson->several_focus.child;
	num = p_jackson->several_focus.history_several_focus_last_index;

	p_jackson->several_focus.history_several_focus_last_index *= 2;
	p_jackson->several_focus.child = NULL;

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	printf("sizeof(ANIMATION_FOCUS*) %d * p_jackson->several_focus.history_several_focus_last_index %d\r\n", sizeof(ANIMATION_FOCUS*), p_jackson->several_focus.history_several_focus_last_index);
	printf("sizeof(int*) %d\r\n", sizeof(int*) );
	printf("sizeof(ANIMATION_FOCUS) %d\r\n", sizeof(ANIMATION_FOCUS) );

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	b = wait_sharp_short_time ();
	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	b = wait_sharp_short_time ();
	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		exit(-1);
	}

	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	for ( i=0; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// copy
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = a[i];
	}

	// release array only
	free ( a );

	printf( "re -> index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Reinitialize_Refresh_Several_Focus_001_03 () ends.\r\n");
	return 1;
}

int Reinitialize_Refresh_Several_Focus_001_04 () {
	static ANIMATION_FOCUS** a;
	int i, num, b;

	printf("int Reinitialize_Refresh_Several_Focus_001_04 () starts.\r\n");
	printf("modifing... \r\n");

	a = (ANIMATION_FOCUS**)p_jackson->several_focus.child;
	num = p_jackson->several_focus.history_several_focus_last_index;

	p_jackson->several_focus.history_several_focus_last_index *= 2;
	p_jackson->several_focus.child = NULL;

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	printf("sizeof(ANIMATION_FOCUS*) %d * p_jackson->several_focus.history_several_focus_last_index %d\r\n", sizeof(ANIMATION_FOCUS*), p_jackson->several_focus.history_several_focus_last_index);
	printf("sizeof(int*) %d\r\n", sizeof(int*) );
	printf("sizeof(ANIMATION_FOCUS) %d\r\n", sizeof(ANIMATION_FOCUS) );

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	b = wait_sharp_short_time ();
	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	b = wait_sharp_short_time ();
	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		exit(-1);
	}

	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	for ( i=0; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// copy
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = a[i];
	}

	// release array only
	free ( a );

	printf( "re -> index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Reinitialize_Refresh_Several_Focus_001_04 () ends.\r\n");
	return 1;
}

int Reinitialize_Refresh_Several_Focus_001_05 () {
	static ANIMATION_FOCUS** a;
	int i, num, b;

	printf("int Reinitialize_Refresh_Several_Focus_001_05 () starts.\r\n");
	printf("modifing... \r\n");

	a = (ANIMATION_FOCUS**)p_jackson->several_focus.child;
	num = p_jackson->several_focus.history_several_focus_last_index;

	p_jackson->several_focus.history_several_focus_last_index *= 2;
	p_jackson->several_focus.child = NULL;

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	printf("sizeof(ANIMATION_FOCUS*) %d * p_jackson->several_focus.history_several_focus_last_index %d\r\n", sizeof(ANIMATION_FOCUS*), p_jackson->several_focus.history_several_focus_last_index);
	printf("sizeof(int*) %d\r\n", sizeof(int*) );
	printf("sizeof(ANIMATION_FOCUS) %d\r\n", sizeof(ANIMATION_FOCUS) );

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	b = wait_sharp_short_time ();
	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	b = wait_sharp_short_time ();
	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		exit(-1);
	}

	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	for ( i=0; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// copy
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = a[i];
	}

	// release array only
	free ( a );

	printf( "re -> index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Reinitialize_Refresh_Several_Focus_001_05 () ends.\r\n");
	return 1;
}

int Reinitialize_Refresh_Several_Focus_001_06 () {
	static ANIMATION_FOCUS** a;
	int i, num, b;

	printf("nt Reinitialize_Refresh_Several_Focus_001_06 () starts.\r\n");
	printf("modifing... \r\n");

	a = (ANIMATION_FOCUS**)p_jackson->several_focus.child;
	num = p_jackson->several_focus.history_several_focus_last_index;

	p_jackson->several_focus.history_several_focus_last_index *= 2;
	p_jackson->several_focus.child = NULL;

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	printf("sizeof(ANIMATION_FOCUS*) %d * p_jackson->several_focus.history_several_focus_last_index %d\r\n", sizeof(ANIMATION_FOCUS*), p_jackson->several_focus.history_several_focus_last_index);
	printf("sizeof(int*) %d\r\n", sizeof(int*) );
	printf("sizeof(ANIMATION_FOCUS) %d\r\n", sizeof(ANIMATION_FOCUS) );

	printf("backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);
	b = wait_sharp_short_time ();
	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	b = wait_sharp_short_time ();
	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		exit(-1);
	}

	printf(" -> backup|%p| reset|%p|\r\n", a, p_jackson->several_focus.child);

	for ( i=0; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// copy
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = a[i];
	}

	// release array only
	free ( a );

	printf( "re -> index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Reinitialize_Refresh_Several_Focus_001_06 () ends.\r\n");
	return 1;
}
//---  Reinitialize ends.  ---
/*
	// 20251208
	int block_width = 16;
	int block_height = 16;
	unsigned char** map_grid_focus = NULL;

*/

// 20251208
int Initialize_Map_Grid_Focus () {
	int i, j, a;
	printf("int Initialize_Map_Grid_Focus () starts.\r\n");

	a = Set_Map_Grid_Focus_xy ( 32, 32 );

	if ( p_jackson->map_grid_focus ==  NULL )
		p_jackson->map_grid_focus = (unsigned char**) malloc ( sizeof (unsigned char**) *  p_jackson->block_width);

	for ( i=0; i<p_jackson->block_width; i++ ) {
		p_jackson->map_grid_focus[i] = (unsigned char*) malloc ( sizeof (unsigned char*) *  p_jackson->block_height);
	}

	for ( j=0; i<p_jackson->block_height; j++ ) {
		for ( i=0; i<p_jackson->block_width; i++ ) {
			p_jackson->map_grid_focus[i][j] = 0;
		}
	}

	printf("int Initialize_Map_Grid_Focus () ends.\r\n");
	return 0;
}
// 20251208

// 20251213
// 0: unset drew
// 1: set drew
// dfault: drew
int Set_Drew_Map_Grid_Focus_xy ( int x, int y, unsigned char value ) {
	int a;

	printf("int Set_Drew_Map_Grid_Focus_xy ( int x, int y, unsigned char value ) starts.\r\n");

//	printf("p_jackson->map_grid_focus |&p|\r\n", p_jackson->map_grid_focus);

	if ( p_jackson->map_grid_focus ==  NULL )
		a = Initialize_Map_Grid_Focus ();

	p_jackson->map_grid_focus[x][y] = value;

	printf("int Set_Drew_Map_Grid_Focus_xy ( int x, int y, unsigned char value ) ends.\r\n");
	return 0;
}


/*
	for ( j= p_jackson->canvas_focus.start_y; j<p_jackson->canvas_focus.height; j++ )
	for ( i= p_jackson->canvas_focus.start_x; i<p_jackson->canvas_focus.width; i++ ) {
*/
/*
	ar = (int)r + 2;
	ax = (int)cx - ar;
	ay = (int)cy - ar;

	a = set_draw_focus ( ax, ay, ar , ar );

*/
// 20251218
int Set_Drew_Map_Grid_Focus_From_Image_xy ( int x, int y ) {
	double r;
	int ar, ax, ay, a;

	printf("int Set_Drew_Map_Grid_Focus_From_Image_xy ( int x, int y ) starts.\r\n");

	r = 5.0;
	ar = (int)r + 2;
	ax = (int)x - ar;
	ay = (int)y - ar;

	a = set_draw_focus ( ax, ay, ar , ar );

	printf("int Set_Drew_Map_Grid_Focus_From_Image_xy ( int x, int y ) ends.\r\n");
	return 0;
}

// 20251213
int Set_Map_Grid_Focus_xy ( int x, int y ) {
	int a;
	printf("int Set_Map_Grid_Focus_xy ( int x, int y ) starts.\r\n");

	if ( p_jackson->map_grid_focus !=  NULL )
		a = Release_Map_Grid_Focus ();

	p_jackson->block_width = x;
	p_jackson->block_height = y;

	printf("int Set_Map_Grid_Focus_xy ( int x, int y ) ends.\r\n");
	return 0;
}

// 20251226
int Get_Drew_Map_Grid_Focus_xy ( int x, int y, int* value ) {
	int a;

	printf("int Get_Drew_Map_Grid_Focus_xy ( int x, int y, int* value ) starts.\r\n");
	printf("p_jackson->map_grid_focus|%p|\r\n", p_jackson->map_grid_focus);
	if ( p_jackson->map_grid_focus ==  NULL )
		a = Initialize_Map_Grid_Focus ();

	*value = 0;
	if (  p_jackson->map_grid_focus[x][y] != 0 ) {
		*value = 1;
	}

	printf("value|%p|%d|\r\n", value, *value);

	printf("int Get_Drew_Map_Grid_Focus_xy ( int x, int y, int* value ) ends.\r\n");
	return 0;
}


// 20251226
int Get_Drew_Map_Grid_Focus_xy_with_sleep ( int x, int y, int* value ) {
	int a;

	printf("int Get_Drew_Map_Grid_Focus_xy_with_sleep ( int x, int y, int* value ) starts.\r\n");
	printf("p_jackson->map_grid_focus|%p|\r\n", p_jackson->map_grid_focus);
	if ( p_jackson->map_grid_focus ==  NULL )
		a = Initialize_Map_Grid_Focus ();

	*value = 0;
	if (  p_jackson->map_grid_focus[x][y] != 0 ) {
		*value = 1;
	}

	printf("value|%p|%d|\r\n", value, *value);
	if ( *value == 1 && debug_small_area <= 2 ) Sleep(5000);
	else if ( debug_small_area <= 2 ) Sleep(250);

	printf("int Get_Drew_Map_Grid_Focus_xy_with_sleep ( int x, int y, int* value ) ends.\r\n");
	return 0;
}


int Initialize_xxxx_000_02 () {

	return 0;
}

int Initialize_xxxx_000_03 () {

	return 0;
}

int Initialize_xxxx_000_04 () {

	return 0;
}
int Initialize_xxxx_000_05 () {

	return 0;
}

int Initialize_xxxx_000_06 () {

	return 0;
}

int Initialize_xxxx_000_07 () {

	return 0;
}

int Initialize_xxxx_000_08 () {

	return 0;
}

int Initialize_xxxx_000_09 () {

	return 0;
}

int Initialize_xxxx_000_10 () {

	return 0;
}
int Initialize_xxxx_000_11 () {

	return 0;
}

int Initialize_xxxx_000_12 () {

	return 0;
}

// 20251213
int Release_Map_Grid_Focus () {
	int i, a;

	if ( p_jackson->map_grid_focus !=  NULL )
		a = Release_Map_Grid_Focus ();

	for ( i = 0; i<p_jackson->block_width; i++ )
		free(p_jackson->map_grid_focus[i]); 

	free (p_jackson->map_grid_focus);

	p_jackson->map_grid_focus = NULL;
	p_jackson->block_width = 0;
	p_jackson->block_height = 0;

	return 0;
}

int Release_xxxx_000_02 () {

	return 0;
}

int Release_xxxx_000_03 () {

	return 0;
}

int Release_xxxx_000_04 () {

	return 0;
}
int Release_xxxx_000_05 () {

	return 0;
}

int Release_xxxx_000_06 () {

	return 0;
}

int Release_xxxx_000_07 () {

	return 0;
}

int Release_xxxx_000_08 () {

	return 0;
}

int Release_xxxx_000_09 () {

	return 0;
}

int Release_xxxx_000_10 () {

	return 0;
}
int Release_xxxx_000_11 () {

	return 0;
}

int Release_xxxx_000_12 () {

	return 0;
}


// --- EOF --- end of file ---- 


