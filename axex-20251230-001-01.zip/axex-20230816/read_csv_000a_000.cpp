#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_000.h"

extern char* filename_read_csv_000a_000_ = (char*)"read_csv_000a_000.txt";

int read_csv_000a_000 ();
int set_read_csv_000a_000 (char** argv, int argc);
int initialize_read_csv_000a_000 (char** argv, int argc);

int read_csv_000a_000 () {
	return 1;

}


int read_csv_000a_set_000 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_000 (char** argv, int argc) {
 	return 1;
 
}

