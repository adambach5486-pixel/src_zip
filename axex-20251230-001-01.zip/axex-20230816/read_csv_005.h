#ifndef _SETTLE_GRID_005_H_
#define _SETTLE_GRID_005_H_

extern int csvgetcount_005 () ;
extern void csvsetcount_005 ( int mcount ) ;
extern void csvafree_005 (char* mafree) ;
extern char* csvcopyof_005 ( char* mstring ) ;

// initialize
extern int Set_Logging_read_csv_005 ( Logging* log ) ;


#endif
