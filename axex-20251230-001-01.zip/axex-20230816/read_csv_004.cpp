#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"

#include "read_csv_004.h"
#include "read_csv_005.h"

GRID_MATRIX_004* grid_matrix_004 = NULL;

static Logging* log_001;
static LOG_001* dlog_001 = NULL;


int Set_Logging ( Logging* log ) ;


int puttheword_004 ( int ii, int jj, char* word ) ;
int initialize_grid_matrix_004 () ;
int	initialize_grid_matrix_004_01 () ;

int file_all_size ( char* filename, int *file_end ) ;
int filesize_004( FILE *fp ) ;
char* gettheword_004 ( int ii, int jj ) ;
int puttheword_004a ( int ii, int jj, char* word ) ;



//
char* gettheword_004 ( int ii, int jj ) {
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_004 ( int ii, int jj ) starts." );

	if ( grid_matrix_004->width_index_num_max <= ii ) {
		return NULL;
	}

	if ( grid_matrix_004->height_index_num_max <=jj ) {
		return NULL;
	}

	dlog_001 = log_001->update_log ( (char*)"char* gettheword_004 ( int ii, int jj ) ends." );
	return grid_matrix_004->grid_matrix[ii][jj];
}

int puttheword_004a ( int ii, int jj, char* word ) {
	int a, i, wi;
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_004 ( int ii, int jj ) starts." );

	wi = grid_matrix_004->width_index_num_max;
	if (grid_matrix_004->width_index_num_max <= ii ) {
		for ( i= 0; jj >= grid_matrix_004->width_index_num_max; i++ ) {
			grid_matrix_004->width_index_num_max *= 2;
		}
	}
	if (grid_matrix_004->height_index_num_max <=jj ) {
		for ( i= 0; jj >= grid_matrix_004->height_index_num_max; i++ ) {
			grid_matrix_004->height_index_num_max *= 2;
		}
	}

	wi = grid_matrix_004->width_index_num_max;
	a = memories_width ( wi, grid_matrix_004->width_index_num_max, grid_matrix_004->height_index_num_max, (char***) grid_matrix_004->grid_matrix ) ;
	a = memories_height ( grid_matrix_004->width_index_num_max, grid_matrix_004->height_index_num_max, (char***) grid_matrix_004->grid_matrix ) ;

	csvafree_005(grid_matrix_004->grid_matrix[ii][jj]);
	grid_matrix_004->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );
	dlog_001 = log_001->update_log ( (char*)"char* gettheword_004 ( int ii, int jj ) ends." );
}

//
int puttheword_004 ( int ii, int jj, char* word ) {
	int a, i, rmode, ri;
	char msg[255];

	printf("int puttheword_004 ( int ii, int jj, char* word ) starts.\r\n");
	printf("grid_matrix_004 |%p| ii %d log_001|%p|\r\n", grid_matrix_004, ii, log_001 );

	dlog_001 = log_001->update_log ( (char*)"int puttheword_004 ( int ii, int jj, char* word ) starts." );

	if ( grid_matrix_004 == NULL ) {
		a = initialize_grid_matrix_004 ();
	}

	printf("int puttheword_004 ( int ii, int jj, char* word ) block 001.\r\n");
	printf("grid_matrix_004 |%p| ii %d\r\n", grid_matrix_004, ii );
	printf("grid_matrix_004->width_index_num_max %d ii %d\r\n", grid_matrix_004->width_index_num_max, ii );

	rmode = 0;
	if (grid_matrix_004->width_index_num_max <= ii ) {
		rmode = 1;
		ri = grid_matrix_004->width_index_num_max;
		for ( i= 0; ii >= grid_matrix_004->width_index_num_max; i++ ) {
			grid_matrix_004->width_index_num_max *= 2;
		}
		printf("out1 i %d jj %d width_index_num_max %d\r\n", i, jj, grid_matrix_004->width_index_num_max );
		grid_matrix_004->grid_matrix = (char***)realloc ( grid_matrix_004->grid_matrix , sizeof(char**) * grid_matrix_004->width_index_num_max );
		for ( i = ri; i< grid_matrix_004->width_index_num_max; i++ ) {
			printf("out1-1 i %d / %d matrix|%p| -> ", i, grid_matrix_004->width_index_num_max, grid_matrix_004->grid_matrix[i] );
			grid_matrix_004->grid_matrix[i] = (char**)malloc ( sizeof(char*) * grid_matrix_004->height_index_num_max );
			printf(" matrix|%p| \r\n", i, grid_matrix_004->width_index_num_max, grid_matrix_004->grid_matrix[i] );
		}
	}

	printf("int puttheword_004 ( int %d, int %d, char* word ) block 002.\r\n", ii, jj);

	if (grid_matrix_004->height_index_num_max <=jj ) {
		rmode = 2;
		printf("in i %d jj %d height_index_num_max %d\r\n", i, jj, grid_matrix_004->height_index_num_max );
		for ( i= 0; jj >= grid_matrix_004->height_index_num_max; i++ ) {
			printf("i %d jj %d height_index_num_max %d\r\n", i, jj, grid_matrix_004->height_index_num_max );
			grid_matrix_004->height_index_num_max *= 2;
		}
		printf("out2 i %d jj %d width_index_num_max %d height_index_num_max %d \r\n", i, jj, grid_matrix_004->width_index_num_max, grid_matrix_004->height_index_num_max );
		for ( i = 0; i< grid_matrix_004->width_index_num_max; i++ ) {
			grid_matrix_004->grid_matrix[i] = (char**)realloc ( grid_matrix_004->grid_matrix[i], sizeof(char*) * grid_matrix_004->height_index_num_max );
			printf("out2-1 grid_matrix_004->grid_matrix[%d]|%p|size %d\r\n", i, grid_matrix_004->grid_matrix[i], grid_matrix_004->height_index_num_max );
		}
	}

	printf("int puttheword_004 ( int %d, int %d, char* word ) block 003.\r\n", ii, jj);

	sprintf( msg, "puttheword_004 %d %d grid matrix %s", ii, jj, (char*) grid_matrix_004->grid_matrix[ii][jj]  );
	dlog_001 = log_001->update_log ( (char*) msg );

	csvafree_005(grid_matrix_004->grid_matrix[ii][jj]);
	grid_matrix_004->grid_matrix[ii][jj] = (char*) csvcopyof_005 ( word );


	printf("int puttheword_004 ( int %d, int %d, char* word ) block 004.\r\n", ii, jj);

	sprintf( msg, "puttheword_004 %d %d word %s", ii, jj, word  );
	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int puttheword_004 ( int ii, int jj, char* word ) end." );

	printf("int puttheword_004 ( int ii, int jj, char* word ) ends.\r\n");
	return 0;
}

int	initialize_grid_matrix_004_01 () {
	printf("int	initialize_grid_matrix_004_01 () starts.\r\n");
	printf("int	initialize_grid_matrix_004_01 () ends.\r\n");
}

//
int	initialize_grid_matrix_004 () {
	int i, j;
	char msg[255];

	printf("int	initialize_grid_matrix_004 () starts.\r\n");

	dlog_001 = log_001->update_log ( (char*)"int	initialize_grid_matrix_004 () starts." );

	grid_matrix_004 = (GRID_MATRIX_004*) malloc ( sizeof (GRID_MATRIX_004) );
	if ( grid_matrix_004 == NULL ) {
		exit(-1);
	}

	grid_matrix_004->width_index_num_max = 8;
	grid_matrix_004->height_index_num_max = 8;

	grid_matrix_004->grid_matrix = (char***)malloc ( sizeof(char**) * grid_matrix_004->width_index_num_max );

	sprintf( msg, "grid_matrix_004->grid_matrix |%p| grid_matrix_004->width_index_num_max=%d", grid_matrix_004->grid_matrix, grid_matrix_004->width_index_num_max );
	dlog_001 = log_001->update_log ( (char*) msg );

	sprintf( msg, "grid_matrix_004->grid_matrix |%p| grid_matrix_004->height_index_num_max=%d", grid_matrix_004->grid_matrix, grid_matrix_004->height_index_num_max );
	dlog_001 = log_001->update_log ( (char*) msg );

	for ( i = 0; i< grid_matrix_004->width_index_num_max; i++ ) {
		grid_matrix_004->grid_matrix[i] = (char**)malloc ( sizeof(char*) * grid_matrix_004->height_index_num_max );
		if ( grid_matrix_004->grid_matrix[i] == NULL ) {
			exit(-1);
		}
		for ( j = 0; j< grid_matrix_004->height_index_num_max; j++ ) {
			grid_matrix_004->grid_matrix[i][j] = (char*)csvcopyof_005 ("g");
		}
	}

	dlog_001 = log_001->update_log ( (char*)"int	initialize_grid_matrix_004 () ends." );

	printf("int	initialize_grid_matrix_004 () ends.\r\n");

	return  0;
}

//
int file_all_size ( char* filename, int *file_end ) {
	FILE *fp;
	char msg[255];

	dlog_001 = log_001->update_log ( (char*)"int file_all_size ( char* filename, int *file_end ) starts." );

	fp = fopen ( filename, "rb" );
	(*file_end) = filesize_004 ( fp );

	fclose(fp);

	sprintf( msg, "msg %s file_end |%p| %d\0", filename, file_end, *file_end );

	dlog_001 = log_001->update_log ( (char*) msg );

	dlog_001 = log_001->update_log ( (char*)"int file_all_size ( char* filename, int *file_end ) ends." );
}

//
int filesize_004( FILE *fp ) {
	int sz;

	fseek(fp, 0L, SEEK_END);
	sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	printf("sz %d\r\n", sz);
	return sz;
}

//
int Set_Logging_read_csv_004 ( Logging* log ) {
	printf("int Set_Logging_read_csv_004 ( Logging* log ) starts.\r\n");
	log_001 = (Logging*)log;
	Set_Logging_read_csv_000a_014 ( (Logging*)log );
	printf("int Set_Logging_read_csv_004 ( Logging* log ) ends.\r\n");
	return 0;
}


