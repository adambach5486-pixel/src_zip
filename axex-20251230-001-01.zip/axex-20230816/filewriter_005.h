#ifndef _FILEWRITER_005_
#define _FILEWRITER_005_
//...
extern int filewriter_005 ();
extern int set_filewriter_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_005 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
