#ifndef _MALLOC_001_
#define _MALLOC_001_

extern char*** mallocation_001_02 ( int width, int height ) ;

#endif
