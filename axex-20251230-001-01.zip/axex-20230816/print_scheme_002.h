#ifndef _PRINT_SCHENE_002_H_
#define _PRINT_SCHENE_002_H_


//extern int print_scheme_002 ():

#endif