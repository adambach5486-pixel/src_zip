#include "array_counter.h"
#include "wC_structure.h"

wC_structure::wC_structure () {

	this->x = 300;
	this->y = 300;
	this->width = 100;
	this->height = 100;

	this->function_name = copyof("default_function_name");
}


void wC_structure::analyze_block() {

	this->x = 300;
	this->y = 300;
	this->width = 100;
	this->height = 100;

	this->function_name = copyof("default_function_name");
}

