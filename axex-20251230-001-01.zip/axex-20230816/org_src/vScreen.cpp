#include <stdarg.h>			// ADD: 20191227
#include <stdio.h>			// ADD: 20191227
#include <windows.h>		// ADD: 20191227

#include "array_counter.h"	// ADD: 20191227
#include "sender.h"			// ADD: 20191227
#include "Print.h"			// ADD: 20191227

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection.h"

#include "vScreen.h"


vScreen::vScreen ( ) {

	//Point U = new Point();
	//Point V = new Point();

	this_calc = new vCalculation ();

	set_level_error_msg = 4;
}

//
//
//
//
//
void vScreen::setHowFarFromEye ( float howfarfromeye ) {

	HowFarFromEye = howfarfromeye;
}

//
//
//
//
//
int vScreen::get_coordinate_on_screen ( vPoint lp, float* lx, float* ly ) {
	vCalculation calc;
//	vTriangle screen_tri;

	vPoint* ray = calc.subtract( lp, this->eye);
	calc.normal(ray);
	// if ( ray.x == 0 && ray.y == 0 && ray.z == 0 ) return -1;

// Move the below to calculation_up_UV at 20191228.
//	screen_tri.p1 = this->C;
//	screen_tri.p2 = calc.add( this->C, this->U );
//	screen_tri.p3 = calc.add( this->C, this->V );

	vIntersection* intersection = nullptr;
	intersection = new vIntersection ();
	vPoint* point_intersection = intersection->Intersect( screen_tri, this->eye, *ray );

	log_msg_003("intersection = ");
	point_intersection->print();
//
//	vPoint result;
//	screen->setPoint(lp);
//	screen->OntheScreen( lp, &result );

	int result = this->OntheScreen( *point_intersection, lx, ly );

	return 0;
}

//
//
//
//
//
int vScreen::OntheScreen ( vPoint lp, vPoint* result ) {

	// Screen( x, y );

	return 0;
}

// All qualified at 20190627:
//
//
//
//
int vScreen::OntheScreen ( vPoint lp, float* x, float* y ) {
	vCalculation calc;

	// Screen( x, y )
	// lp is surely on the screen.
	vPoint* result = calc.subtract( lp , this->C );

	log_msg_003("result = ");
	result->print();

	*x = calc.dot( *result, this->U ); // up
	*y = calc.dot( *result, this->V ); // right

	log_msg_003(" x, y = %f , %f\r\n", *x, *y);

	*x /= (double)this->width;
	*y /= (double)this->height;

	log_msg_003(" x, y = %f , %f\r\n", *x, *y);

	*y = -*y + this->height;

	log_msg_003(" x, y = %f , %f height %f\r\n", *x, *y, this->height);

/*	result_x = calc.cross ( result, this->u ) ;
	result_y = calc.cross ( result, this->up ) ;

	// double -> float
	*x = (float) this_calc->length( result_x );
	*y = this->height - (float) this_calc->length( result_y );

	*x = *x + this->width / 2.0f;
	*y = ( -*y + this->height )  + this->height/2.0f; */

	return 0;
}

void vScreen::OntheScreen ( float* x, float* y ) {
	vPoint px;
	vPoint py;

	printf("vScreen::OntheScreen starts\r\n");

	OntheScreen( &px, &py );
	*x = px.x;
	*y = px.y;
	printf("vScreen::OntheScreen ends\r\n");
}

void vScreen::OntheScreen ( vPoint* x, vPoint* y) {
	 vPoint* px = subtract ( X, C );
	 vPoint* py = subtract ( Y, C );
}

void vScreen::LookAt ( vPoint lookat ) {
	this->lookat = lookat;
}

void vScreen::put_U ( vPoint a ) {
	U = a;
}

void vScreen::put_Up ( vPoint up ) {
	this->up.setPoint( up.x, up.y, up.z );
}

void vScreen::put_V ( vPoint b) {
	this->V.setPoint( b.x, b.y, b.z );
}

void vScreen::put_C ( vPoint c) {
	this->C.setPoint( c.x, c.y, c.z );
}

void vScreen::calculation () {
	calculation_uv_up();
}

void vScreen::calculation_uv_up () {
	vCalculation calc_this;

	printf("void vScreen::calculation_uv_up () starts.\r\n");

	vPoint* uu = normal ( U ) ; // right
	vPoint* vv = normal ( V ) ; // up

	vPoint* depth = calc_this.cross ( *uu, *vv ) ;

	this->u.setPoint( uu->x, uu->y, uu->z );
	this->v.setPoint( depth->x, depth->y, depth->z );
	this->up.setPoint( vv->x, vv->y, vv->z );

	//u, up and v means right, up and depth:

	free_point( uu );
	free_point( vv );
	free_point( depth );

	printf("void vScreen::calculation_uv_up () ends.\r\n");
}


// Set this->C.setPoint( x, y, z);
// this->up is up direction and normal:
// 
// this->U is right direction on the screen
// this->V is up directiont on the screen: which confused us.
void vScreen::calculation_up_UV () {
	vCalculation calc_this;

	printf("vScreen::calculation_up_UV () starts.\r\n");

	log_msg_003("this->eye= ");
	this->eye.print();
	log_msg_003("lookat= ");
	this->lookat.print();

	vPoint* howfar = calc_this.subtract ( this->lookat, this->eye );
	log_msg_003("howfar= ");
	howfar->print();

	vPoint* n_howfar = calc_this.normal( *howfar );
	log_msg_003("n_howfar= ");
	n_howfar->print();

	howfar = (vPoint*) calc_this.scale( *n_howfar, this->HowFarFromEye );
	this->HowFar.setPoint( howfar->x, howfar->y, howfar->z );

	log_msg_003("HowFarFromEye=%d\r\n", this->HowFarFromEye );
	log_msg_003("HowFar= ");
	this->HowFar.print();

	vPoint* CCC = calc_this.add( this->eye, *howfar );
	this->C.setPoint( CCC->x, CCC->y, CCC->z);

	vPoint* uppp = normal ( this->up ) ;
	this->up.setPoint( uppp->x, uppp->y, uppp->z );

	log_msg_003("up= ");
	this->up.print();

	vPoint* right = calc_this.cross( n_howfar, uppp );		//right , -left
	calc_this.normal ( right ) ;				
	vPoint* up_001 = calc_this.cross( right, n_howfar );		//up
	this->up.setPoint( up_001->x, up_001->y, up_001->z );

	vPoint* depth = calc_this.cross( up_001, right ); // depth

	// SET u,v which means up, right.
	this->u.setPoint( up_001->x, up_001->y, up_001->z );
	this->v.setPoint( depth->x, depth->y, depth->z );

	vPoint* UU = calc_this.scale( *right, this->width );
	vPoint* VV = calc_this.scale( this->up, this->height ); // V means UP, v means up direction
	this->U.setPoint(UU->x, UU->y, UU->z);
	this->V.setPoint(VV->x, VV->y, VV->z);


	log_msg_003("u= ");
	u.print();
	log_msg_003("U= ");
	U.print();
	log_msg_003("V= ");
	V.print();

	vPoint* halfU = calc_this.scale( u, -this->width/2.0f );
	vPoint* halfV = calc_this.scale( this->up, -this->height/2.0f );

	vPoint* a = (vPoint *)calc_this.add( &(this->C), halfU );
	vPoint* b = (vPoint *)calc_this.add( a, halfV );
	this->C.setPoint( b->x,  b->y,  b->z );

	log_msg_003("this->C= ");
	this->C.print();

	//20191228
	screen_tri.p1.setPoint( this->C.x, this->C.y, this->C.z );
	vPoint* d = calc_this.add( this->C, this->U );
	vPoint* e = calc_this.add( this->C, this->V );
	screen_tri.p2.setPoint( d->x, d->y, d->z );
	screen_tri.p3.setPoint( e->x, e->y, e->z );

	//
	printf("screnn tringale: \r\n");
	screen_tri.p1.print();
	screen_tri.p2.print();
	screen_tri.p3.print();

	// Free a, b, d, e:
	free_point( a );
	free_point( b );
	free_point( d );
	free_point( e );
	free_point( CCC );
	free_point( uppp );
	free_point( up_001 );
	free_point( UU );
	free_point( VV );
	free_point( depth );
	free_point( right );
	free_point( howfar );
	free_point( n_howfar );
	free_point( howfar );
	free_point( halfU );
	free_point( halfV );

	printf("vScreen::calculation_up_UV () ends.\r\n");
}

//
//
//
//
//
vPoint* vScreen::normal( vPoint a) {
	vPoint* result;

	result = this_calc->normal ( a ) ;
	return result;
}

vPoint* vScreen::subtract( vPoint a, vPoint b) {
	vPoint* result;

	result = this_calc->subtract ( a, b ) ;
	return result;
}

vPoint* vScreen::cross( vPoint a, vPoint b) {
	vPoint* result;

	result = this_calc->cross ( a, b ) ;
	return result;
}

//
//
//
void vScreen::setWidth( int w ) {
	this->width = w;
}

//
//
//
void vScreen::setHeight( int h ) {
	this->height = h;
}

//
//
//
void  vScreen::setEye ( vPoint leye ) {
	this->eye.x = leye.x;
	this->eye.y = leye.y;
	this->eye.z = leye.z;
}

