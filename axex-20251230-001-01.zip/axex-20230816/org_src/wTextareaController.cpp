// textarea controler needs the function which changes textarea cursol.
// that means the contoroler needs the cursol number.
// if there is no cursol numbers i must create them.

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

#include "wTextarea.h"
#include "wTextareaController.h"

// CursolNumber is public.

wTextareaController::wTextareaController () {

	this->mode = 0;
	this->number_textarea = 0;
	AryTextarea = nullptr;
}

void wTextareaController::selectTextarea ( ) {

	if( this->CursolNumber < 0 ) {
		this->CursolNumber = this->number_textarea -1;
		//return;
	}

	if( this->CursolNumber >= this->number_textarea ) {
		this->CursolNumber = 0;
		//return;
	}

	for ( int i=0; i<this->number_textarea; i++ )
		AryTextarea[ i ]->setMode( 0 );

	AryTextarea[ this->CursolNumber ]->setMode( 1 );

}

void wTextareaController::selectTextarea ( char* btn_nm ) {
	int ret;

	for ( int i=0; i<this->number_textarea; i++ ) {
		
		ret = strcmp( AryTextarea[ i ]->textarea_name, btn_nm );
		if ( ret == 0 ) {
			CursolNumber = i;
			AryTextarea[ i ]->setMode( 1 );
		} else
			AryTextarea[ i ]->setMode( 0 );
	}
}

void wTextareaController::addTextarea ( wTextarea* t ) {
	if ( this->number_textarea ==0 || AryTextarea == nullptr ) {
		AryTextarea = ( wTextarea** ) malloc ( sizeof( wTextarea* ) * 1 );
		AryTextarea[ this->number_textarea ] = t;
		this->number_textarea = 1;
		return;
	}

	this->number_textarea++;
	AryTextarea = (wTextarea **) realloc( AryTextarea, this->number_textarea * sizeof(wTextarea *) );
	AryTextarea[ this->number_textarea - 1] = t;

}

void wTextareaController::drawTextareas ( HDC hdc ) {

	// char *textarea
	// this->textarea equals textarea.
	// this.textarea equals textarea.

	char *aname;

	// char text;
	// x text = this.textarea;
	// x aname = this.textarea;

	for ( int i=0; i<this->number_textarea; i++ ) {

		aname = AryTextarea[ i ]->textarea;
		AryTextarea[ i ]->paintTextarea( hdc, aname );
	}

}


// void
