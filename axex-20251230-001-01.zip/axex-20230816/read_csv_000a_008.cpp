#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_008.h"

extern char* filename_read_csv_000a_008_ = (char*)"read_csv_000a_008.txt";

int read_csv_000a_008 ();
int set_read_csv_000a_008 (char** argv, int argc);
int initialize_read_csv_000a_008 (char** argv, int argc);

int read_csv_000a_008 () {
	return 1;

}


int read_csv_000a_set_008 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_008 (char** argv, int argc) {
 	return 1;
 
}

