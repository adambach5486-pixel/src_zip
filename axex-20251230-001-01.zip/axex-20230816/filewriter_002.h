#ifndef _FILEWRITER_002_
#define _FILEWRITER_002_
//...
extern int filewriter_002 ();
extern int set_filewriter_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_002 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
