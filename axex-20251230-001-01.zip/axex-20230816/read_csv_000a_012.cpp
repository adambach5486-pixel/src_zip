#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_012.h"

extern char* filename_read_csv_000a_012_ = (char*)"read_csv_000a_012.txt";

int read_csv_000a_012 ();
int set_read_csv_000a_012 (char** argv, int argc);
int initialize_read_csv_000a_012 (char** argv, int argc);

int read_csv_000a_012 () {
	return 1;

}


int read_csv_000a_set_012 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_012 (char** argv, int argc) {
 	return 1;
 
}

