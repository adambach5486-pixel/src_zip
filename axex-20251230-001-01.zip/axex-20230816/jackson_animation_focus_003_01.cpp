// ---
// ---
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "vVectorCG.h"
#include "vModelBufferController.h"

#include "vDisplayController.h"
#include "vDisplayController_001.h"
#include "vModelBufferController.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"

//20250317
ANIMATION_FOCUS **l_rect_focus;
int l_rects_focus_index = 0;
int l_rects_focus_max = 32;

int debug_sleep = 1;

// 20250317
int Initialize_Refresh_Focus_Focus_Rects_01 ();
int Reinitialize_Refresh_Focus_Focus_Rects_01 ();
int Stack_Focus_Rect_01 (ANIMATION_FOCUS* r) ;
ANIMATION_FOCUS* Pop_Focus_Rect_01 ();
int Print_Refresh_Focus_Focus_Rects_01 ();


// 20250407
int Initialize_Refresh_Several_Focus ();
int Reinitialize_Refresh_Several_Focus ();
int Stack_Oneof_Several_Focus (ANIMATION_FOCUS* r) ;
ANIMATION_FOCUS* Pop_Oneof_Several_Focus ();
int Print_Refresh_Several_Focus ();


int Set_Debug_Sleep_003_01 (int value ) ;

// 20250425
int Stack_Oneof_Several_Focus_Large_003_01 (ANIMATION_FOCUS* r, int c, int cy, int multi) ;
int Stack_Oneof_Several_Focus_Large_003_01a (ANIMATION_FOCUS* r, int c, int cy, int multi) ;
int Stack_Oneof_Several_Focus_Large (ANIMATION_FOCUS* r, int c,int cy, int multi) ;

// 20250905
int Caribration_Draw_Focus () ;

// 20250924
int Write_Page_Refresh_Several_Focus () ;

// 20250925
int Read_Page_Refresh_Several_Focus () ;

// 20251223
// 20251226
int book_focus_map ( double cr, int cx, int cy, int* value );

// 20251226
int Debug_File_Zero_For_Stack ();

// 20251230
int print_focus_map ( int cx, int cy, int bx, int by, int *value );

// 			1: Sleep
// any other�F Skip
int Set_Debug_Sleep_003_01 (int value ) {

	debug_sleep = value;

	return 0;
}

int Debug_File_Zero_For_Stack () {
	FILE *fp;// debug
	fp = fopen ("004-Stack_Oneof_Several_Focus_Large\.txt", "wb");
	fprintf(fp, "004-Stack_Oneof_Several_Focus_Large\.txt\r\n");
	fclose(fp);
	return 0;
}


// Additional one is modification of Stack_Oneof_Several_Focus_Large_003_01a 1st param.
// 20251203
int Stack_Oneof_Several_Focus_Large (ANIMATION_FOCUS* r, int cx, int cy, int multi) {
	int flag;
	int a, value;
	FILE *fp;// debug

	printf("int Stack_Oneof_Several_Focus_Large (ANIMATION_FOCUS* r, int c,int cy, int multi) starts.\r\n");


	printf("r %f ", p_jackson->circle_r );
	printf("cx %d cy %d\r\n", cx, cy );

	a = book_focus_map ( p_jackson->circle_r, cx, cy, &value );
	printf( "book_focus_map: value: %d debug_small_area %d index %d\r\n", value, debug_small_area, p_jackson->several_focus.history_several_focus_index);
	fp = fopen ("004-Stack_Oneof_Several_Focus_Large\.txt", "ab");
	fprintf( fp, "cx %d cy %d book_focus_map: value: %d debug_small_area %d index %d\r\n", cx, cy, value, debug_small_area, p_jackson->several_focus.history_several_focus_index);
	fclose(fp);
	if ( debug_small_area <= 2 ) Sleep(5000);
	if ( value == 1 ) {
		return 1;
	}

	if ( p_jackson->circle_r <= 1.0 ) {
		flag = 1;
	} else {
		flag = 2;
	}

	printf(" flag %d\r\n", flag);
	switch( flag ) {
	case 1:
		a = Stack_Oneof_Several_Focus_Large_003_01a(( ANIMATION_FOCUS*) r, cx, cy, multi + 2 );
		break;
	case 2:
		a = Stack_Oneof_Several_Focus_Large_003_01(( ANIMATION_FOCUS*) r, cx, cy, multi );
		break;
	default:
		printf("Stack_Oneof_Several_Focus_Large exits.\r\n");
		exit(-1);
	}

	printf("int Stack_Oneof_Several_Focus_Large (ANIMATION_FOCUS* r, int c,int cy, int multi) ends.\r\n");
	return 0;
}


int book_focus_map ( double cr, int cx, int cy, int* value ) {
	int bx, by, bw, bh;
	int a;

	printf("int book_focus_map ( double cr, int cx, int cy, int* value ) starts.\r\n");

	bw = p_jackson->canvas_focus.width / p_jackson->block_width;
	bh = p_jackson->canvas_focus.height / p_jackson->block_height;

	bx = cx / bw;
	by = cx / bh;

//	a = Get_Drew_Map_Grid_Focus_xy ( bx , by , value );
	a = Get_Drew_Map_Grid_Focus_xy_with_sleep ( bx , by , value );
	printf("debug_small_area %d value|%p|%d|\r\n", debug_small_area, value, *value);
	if ( debug_small_area <= 2 ) {
		Sleep(5000);
	}

	a = print_focus_map ( cx, cy, bx, by, value);
	if ( *value == 0 ) {
		a = Set_Drew_Map_Grid_Focus_xy( bx, by, 1 );
	}

	if ( *value == 1 && debug_small_area <= 3 ) {
		Sleep(5000);
	}

	printf("int int book_focus_map ( double cr, int cx, int cy, int* value ) ends.\r\n");
	return 0;
}

//
int print_focus_map ( int cx, int cy, int bx, int by, int *value ) {
	FILE *fp;
	printf("int print_focus_map ( int cx, int cy, int bx, int by ) starts.\r\n");

	printf("block( w %d, h %d )\r\n", p_jackson->block_width, p_jackson->block_height );
	printf("c( %d, %d ) -> b( %d, %d )|%d| value|%p|%d| \r\n", cx, cy, bx, by,p_jackson->map_grid_focus[bx][by], value, *value  );

	fp = fopen ("004-Stack_Oneof_Several_Focus_Large\.txt", "ab");

	fprintf( fp, "block( w %d, h %d ) ", p_jackson->block_width, p_jackson->block_height );
	fprintf( fp, "c( %d, %d ) -> b( %d, %d )|%d| value|%p|%d| ", cx, cy, bx, by, p_jackson->map_grid_focus[bx][by], value, *value );

	fclose(fp);

	printf("int print_focus_map ( int cx, int cy, int bx, int by ) ends.\r\n");
	return 0;
}

//
int Stack_Oneof_Several_Focus_Large_003_01a (ANIMATION_FOCUS* r, int c, int cy, int multi) {
	int b;
	int scale_x, scale_y;
	static int count = 0;
	int multi_a;

	printf("int Stack_Oneof_Several_Focus_Large_003_01a (ANIMATION_FOCUS* r) starts.\r\n");

	printf("count %d flag_line_start %d \r\n", count, p_jackson->flag_line_start);
	if ( p_jackson->flag_line_start == 1 ) {
		b = wait_sharp_short_time ();
		count = 0;
		p_jackson->flag_line_start = 0;
		printf(" -> count %d flag_line_start %d\r\n", count, p_jackson->flag_line_start);
		b = wait_sharp_short_time ();
		b = wait_sharp_short_time ();
		b = wait_sharp_short_time ();
		b = wait_sharp_short_time ();
	}

	switch(p_jackson->flag_line_start) {
	case 0:
	case 1:
		break;
	default:
		exit(-1);
	}

	multi_a = multi + 10;

	if ( p_jackson->several_focus.history_several_focus_index < 0 ) 
		 p_jackson->several_focus.history_several_focus_index = 0;

	if ( p_jackson->several_focus.child == NULL ) {
		b = Initialize_Refresh_Several_Focus ();
		if ( b < 0 ) exit(-1);
	}

	if ( p_jackson->several_focus.history_several_focus_index >= p_jackson->several_focus.history_several_focus_last_index )
		b = Reinitialize_Refresh_Several_Focus ();

	switch(b){
	case -2: // paging
		b = Write_Page_Refresh_Several_Focus () ;
		p_jackson->several_focus.history_several_focus_index = 0;
		break;
	}

	if ( p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] == NULL ) {
		p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] = (ANIMATION_FOCUS*)malloc ( sizeof(ANIMATION_FOCUS) );
		if ( p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] == NULL ) {
			printf("Stack_Oneof_Several_Focus_Large_003_01 for a copy is failed.");
			exit(-1);
		}
	}

	printf("count %d multi %d multi_a %d\r\n", count, multi, multi_a);
	if ( debug_sleep == 1 ) Sleep( 3000 );

	if ( count % (multi_a - 1) == 0 && multi > 0 ) {
		scale_x = r->width * multi;
		scale_y = r->height * multi;
		r->start_x -= scale_x / 2;
		r->start_y -= scale_y / 2;
		if ( r->start_x < 0 ) r->start_x = 0;
		if ( r->start_y < 0 ) r->start_y = 0;
		r->width  = scale_x;
		r->height = scale_y;
		p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index][0] = (ANIMATION_FOCUS) *r;
		p_jackson->several_focus.history_several_focus_index++;
		if ( count == 2 && debug_sleep == 1 ) {
			printf( "(%4d,%4d,%4d,%4d) \r\n", r->start_x, r->start_y, r->width, r->height );
			Sleep(1000);
		}
	}

	count++;
	printf("int Stack_Oneof_Several_Focus_Large_003_01a (ANIMATION_FOCUS* r) ends.\r\n");

	return 0;
}

//

// 20250425
// baisu
// baisu -> multiple
int Stack_Oneof_Several_Focus_Large_003_01 (ANIMATION_FOCUS* r, int c, int cy, int multi) {
	int b;
	int scale_x, scale_y;
	static int count = 1;

	printf("int Stack_Oneof_Several_Focus_Large_003_01 (ANIMATION_FOCUS* r) starts.\r\n");

	if ( p_jackson->several_focus.history_several_focus_index < 0 ) 
		 p_jackson->several_focus.history_several_focus_index = 0;

	if ( p_jackson->several_focus.child == NULL ) {
		b = Initialize_Refresh_Several_Focus ();
		if ( b < 0 ) exit(-1);
	}

	printf("p_jackson->several_focus.history_several_focus_index >= p_jackson->several_focus.history_several_focus_last_index %d >= %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	if ( p_jackson->several_focus.history_several_focus_index >= p_jackson->several_focus.history_several_focus_last_index )
		b = Reinitialize_Refresh_Several_Focus ();

	switch(b){
	case -2: // paging
		b = Write_Page_Refresh_Several_Focus () ;
		p_jackson->several_focus.history_several_focus_index = 0;
		break;
	}

	if ( p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] == NULL ) {
		p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] = (ANIMATION_FOCUS*)malloc ( sizeof(ANIMATION_FOCUS) );
		if ( p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] == NULL ) {
			printf("Stack_Oneof_Several_Focus_Large_003_01 for a copy is failed.");
			exit(-1);
		}
	}

	printf("count %d multi %d \r\n", count, multi);
	if ( debug_sleep == 1 ) Sleep( 3000 );

	if ( count % (multi - 1) == 0 && multi > 0 ) {
		printf("stack_msg: count %d\r\n", count);
		scale_x = r->width * multi;
		scale_y = r->height * multi;
		r->start_x -= scale_x / 2;
		r->start_y -= scale_y / 2;
		if ( r->start_x < 0 ) r->start_x = 0;
		if ( r->start_y < 0 ) r->start_y = 0;
		r->width  = scale_x;
		r->height = scale_y;
		p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index][0] = (ANIMATION_FOCUS) *r;
		p_jackson->several_focus.history_several_focus_index++;
		if ( count == 2 && debug_sleep == 1 ) {
			printf( "(%4d,%4d,%4d,%4d) \r\n", r->start_x, r->start_y, r->width, r->height );
			Sleep(1000);
		}
	}

	count++;

	printf("p_jackson->several_focus.history_several_focus_index >= p_jackson->several_focus.history_several_focus_last_index %d >= %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	printf("int Stack_Oneof_Several_Focus_Large_003_01 (ANIMATION_FOCUS* r) ends.\r\n");
	return 0;
}

// 20250407
int Stack_Oneof_Several_Focus (ANIMATION_FOCUS* r) {
	int b;

	printf("int Stack_Oneof_Several_Focus (ANIMATION_FOCUS* r) starts.\r\n");

	if ( debug_other_stack_killed <= 2 ) {
		printf("Stack_Oneof_Several_Focus: debug_other_stack_killed %d\r\n", debug_other_stack_killed);
		exit(-1);
	}

	if ( p_jackson->several_focus.history_several_focus_index < 0 ) 
		 p_jackson->several_focus.history_several_focus_index = 0;


	if ( p_jackson->several_focus.child == NULL ) {
		b = Initialize_Refresh_Several_Focus ();
		if ( b < 0 ) exit(-1);
	}

	if ( p_jackson->several_focus.history_several_focus_index >= p_jackson->several_focus.history_several_focus_last_index )
		b = Reinitialize_Refresh_Several_Focus ();

	switch(b){
	case -2: // paging
		b = Write_Page_Refresh_Several_Focus () ;
		p_jackson->several_focus.history_several_focus_index = 0;
		break;
	}

	if ( p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] == NULL ) {
		p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] = (ANIMATION_FOCUS*)malloc ( sizeof(ANIMATION_FOCUS) );
		if ( p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index] == NULL ) {
			printf("Stack_Oneof_Several_Focus for a copy is failed.");
			exit(-1);
		}
	}

	p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index][0] = (ANIMATION_FOCUS) *r;
	p_jackson->several_focus.history_several_focus_index++;

	printf("int Stack_Oneof_Several_Focus (ANIMATION_FOCUS* r) ends.\r\n");
	return 0;
}

// 20250407
ANIMATION_FOCUS* Pop_Oneof_Several_Focus () {
	int i;
	ANIMATION_FOCUS* result;

	printf("ANIMATION_FOCUS* Pop_Oneof_Several_Focus () starts.\r\n");

	if ( p_jackson->several_focus.history_several_focus_index <= 0 ) return NULL;

	if ( p_jackson->several_focus.child == NULL ) {
		return NULL;
	}

/*	result = p_jackson->several_focus.child[0];
	for ( i=1; i<p_jackson->several_focus.history_several_focus_last_index; i++ ) {
		p_jackson->several_focus.child[i - 1] = (ANIMATION_FOCUS*)p_jackson->several_focus.child[i];
	}
*/

	result = p_jackson->several_focus.child[p_jackson->several_focus.history_several_focus_index - 1];
	p_jackson->several_focus.history_several_focus_index--;

	printf("ANIMATION_FOCUS* Pop_Oneof_Several_Focus () ends.\r\n");
	return result;
}

// 20250407
int Reinitialize_Refresh_Several_Focus () {
	int a;

	printf("int Reinitialize_Refresh_Several_Focus () starts.\r\n");

	a = Reinitialize_Refresh_Several_Focus_001_01 ();

	printf("int Reinitialize_Refresh_Several_Focus () ends.\r\n");
	return a;
}

// 20250924
int Write_Page_Refresh_Several_Focus () {
	int a;
	FILE *fp;
	int i;
	ANIMATION_FOCUS* achild =NULL;
	char* a_token = NULL;

	printf("int Write_Page_Refresh_Several_Focus () starts.\r\n");

	printf("project_directory_name |%s|\r\n", p_jackson->project_directory_name);
	printf("work_directory_name |%s|\r\n", p_jackson->work_directory_name);

	a_token = m_concat ( p_jackson->work_directory_name, "001-Write_Page_Refresh_Several_Focus-01\.page");

	fp = (FILE*) fopen( a_token, "wb");

	for( i= 0; i < p_jackson->several_focus.history_several_focus_index; i++) {
		printf("i %d\r\n", i);
		achild = (ANIMATION_FOCUS*) p_jackson->several_focus.child[i];
		p_jackson->several_focus.child_size_buffer = (char*) achild;
		fwrite( p_jackson->several_focus.child_size_buffer, sizeof(char), p_jackson->several_focus.history_several_focus_child_size, fp);
	}

	fclose(fp);

	printf("int Write_Page_Refresh_Several_Focus () ends.\r\n");
	return a;
}


// 20250925
int Read_Page_Refresh_Several_Focus () {
	int a;

	printf("int Read_Page_Refresh_Several_Focus () starts.\r\n");

	printf("project_directory_name |%s|\r\n", p_jackson->project_directory_name);
	printf("work_directory_name |%s|\r\n", p_jackson->work_directory_name);

	printf("int Read_Page_Refresh_Several_Focus () ends.\r\n");
	return a;
}


// 20250407
int Initialize_Refresh_Several_Focus () {
	int i, num, a;

	printf("int Initialize_Refresh_Several_Focus () starts.\r\n");

	// 20250519
	if ( p_jackson->several_focus.child == NULL ) {
		p_jackson->several_focus.history_several_focus_last_index = 32;
		p_jackson->several_focus.history_several_focus_index = 0;
	}

	printf( "index / last %d / %d\r\n", p_jackson->several_focus.history_several_focus_index, p_jackson->several_focus.history_several_focus_last_index);

	if ( p_jackson->several_focus.history_several_focus_index != 0 ) return -1;

	p_jackson->several_focus.child = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->several_focus.history_several_focus_last_index );
	a = wait_sharp_short_time ();
	printf("p_jackson->several_focus.child|%p|", p_jackson->several_focus.child);
	if ( p_jackson->several_focus.child == NULL ) {
		printf("p_jackson->several_focus.child is NULL.\r\n");
		exit(-1);
	}

	num = p_jackson->several_focus.history_several_focus_last_index;
	for ( i=0; i<num; i++ ) {
		p_jackson->several_focus.child[i] = NULL;
	}

	// 20251005
	p_jackson->several_focus.history_several_focus_child_size = sizeof(ANIMATION_FOCUS*);
	p_jackson->several_focus.child_size_buffer = (char*) malloc ( sizeof(char) * p_jackson->several_focus.history_several_focus_child_size );
	if ( p_jackson->several_focus.child_size_buffer == NULL ) {
		printf("p_jackson->several_focus.child_size_buffer is NULL.\r\n");
		exit(-1);
	}

	printf("int Initialize_Refresh_Several_Focus () ends.\r\n");
	return 0;
}

// 20250407
int Print_Refresh_Several_Focus () {
	int i;

	printf("int Print_Refresh_Several_Focus () starts.\r\n");

	printf("p_jackson->several_focus.history_several_focus_index %d / %d\r\n", p_jackson->several_focus.history_several_focus_index,  p_jackson->several_focus.history_several_focus_last_index);

	if ( p_jackson->several_focus.child == NULL ) {
		return -1;
	}

	for ( i = 0; i<p_jackson->several_focus.history_several_focus_index; i++ ) {
		printf("|%d|%p| ", i, (ANIMATION_FOCUS*)p_jackson->several_focus.child[i] );
		printf("( %d,", (ANIMATION_FOCUS*)p_jackson->several_focus.child[i]->start_x );
		printf(" %d,", (ANIMATION_FOCUS*)p_jackson->several_focus.child[i]->start_y );
		printf(" %d,", (ANIMATION_FOCUS*)p_jackson->several_focus.child[i]->width );
		printf(" %d)\r\n", (ANIMATION_FOCUS*)p_jackson->several_focus.child[i]->height );
	}

	printf("int Print_Refresh_Several_Focus () ends.\r\n");
	return 0;
}

// 20250317
int Stack_Focus_Rect_01 (ANIMATION_FOCUS* r) {
	int b;

	printf("int Stack_Focus_Rect_01 (ANIMATION_FOCUS* r) starts.\r\n");

	if ( debug_other_stack_killed <= 1 ) {
		printf("Stack_Focus_Rect_01: debug_other_stack_killed %d\r\n", debug_other_stack_killed);
		exit(-1);
	}

	if ( l_rect_focus == NULL ) {
		b = Initialize_Refresh_Focus_Focus_Rects_01 ();
	}

	if ( l_rects_focus_index >= l_rects_focus_max )
		b = Reinitialize_Refresh_Focus_Focus_Rects_01 ();

	l_rect_focus[l_rects_focus_index] = (ANIMATION_FOCUS*) r;
	l_rects_focus_index++;

	printf("int Stack_Focus_Rect_01 (ANIMATION_FOCUS* r) ends.\r\n");
	return 0;
}

// 20250317
ANIMATION_FOCUS* Pop_Focus_Rect_01 () {
	int i;
	ANIMATION_FOCUS* result;

	printf("ANIMATION_FOCUS* Pop_Focus_Rect_01 () starts.\r\n");

	if ( l_rect_focus == NULL ) {
		return NULL;
	}

	result = l_rect_focus[0];
	for ( i=1; i<l_rects_focus_max; i++ ) {
		l_rect_focus[i - 1] = (ANIMATION_FOCUS*)l_rect_focus[i];
	}

	l_rects_focus_index--;

	printf("ANIMATION_FOCUS* Pop_Focus_Rect_01 () ends.\r\n");
	return result;
}

// 20250317
int Reinitialize_Refresh_Focus_Focus_Rects_01 () {
	ANIMATION_FOCUS** a;
	int i, num, b;

	printf("int Reinitialize_Refresh_Focus_Focus_Rects_01 () starts.\r\n");

	a = (ANIMATION_FOCUS**)l_rect_focus;
	num = l_rects_focus_max;
	l_rects_focus_max *= 2;
	b = Initialize_Refresh_Focus_Focus_Rects_01 () ;
	for ( i=0; i<num; i++ ) {
		l_rect_focus[i] = a[i];
	}

	free ( a );

	printf("int Reinitialize_Refresh_Focus_Focus_Rects_01 () ends.\r\n");
	return 0;
}

// 20250317
int Initialize_Refresh_Focus_Focus_Rects_01 () {

	printf("int Initialize_Refresh_Focus_Focus_Rects_01 () starts.\r\n");

	l_rects_focus_max = 32;
	l_rects_focus_index = 0;

	l_rect_focus = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * l_rects_focus_max );
	if ( l_rect_focus == NULL ) {
		printf("l_rect_focus is NULL.\r\n");
		exit(-1);
	}

	printf("int Initialize_Refresh_Focus_Focus_Rects_01 () ends.\r\n");
	return 0;
}

// 20250317
int Print_Refresh_Focus_Focus_Rects_01 () {
	int i;

	printf("int Print_Refresh_Focus_Focus_Rects_01 () starts.\r\n");

	if ( l_rect_focus == NULL ) {
		return -1;
	}

	for ( i = 0; i<l_rects_focus_index; i++ ) {
		printf("|%d|%p|\r\n", i, (ANIMATION_FOCUS*)l_rect_focus[i] );
	}

	printf("int Print_Refresh_Focus_Focus_Rects_01 () ends.\r\n");
	return 0;
}


// 20250905
int Caribration_Draw_Focus () {
	int a;
	ANIMATION_FOCUS* a_rect = NULL;
	int index_max = 66;
	int i;

	printf("int Caribration_Draw_Focus () starts.\r\n");

	for ( i = 0; i< index_max; i++ ) {
		printf("i %d/ %d\r\n", i, index_max);

		a_rect = (ANIMATION_FOCUS*) malloc(sizeof(ANIMATION_FOCUS));

		if (a_rect == NULL ) {
			printf("a_rect is NULL.\r\n");
		}

		a = Stack_Oneof_Several_Focus_Large (a_rect, 0, 0, 3);
	}

	a = wait_sharp_short_time ();

	for ( i = 0; i< index_max; i++ ) {
		printf("i %d/ %d\r\n", i, index_max);
		a_rect = Pop_Oneof_Several_Focus ();
		if ( a_rect == NULL ) break;
	}

	a = wait_sharp_short_time ();

	printf("int Caribration_Draw_Focus () ends.\r\n");
	return 0;
}

