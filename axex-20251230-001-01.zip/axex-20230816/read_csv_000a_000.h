#ifndef _READ_CSV__000_
#define _READ_CSV__000_
//...
extern int read_csv_000a_000 ();
extern int set_read_csv_000a_000 (char** argv, int argc);
extern int initialize_read_csv_000a_000 (char** argv, int argc);
#endif
