#ifndef _READ_CSV__001_
#define _READ_CSV__001_
//...
extern int read_csv_000a_001 ();
extern int set_read_csv_000a_001 (char** argv, int argc);
extern int initialize_read_csv_000a_001 (char** argv, int argc);
#endif
