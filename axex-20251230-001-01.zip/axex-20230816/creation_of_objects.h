#ifndef _CREATION_OF_OBJECTS_H_
#define _CREATION_OF_OBJECTS_H_


extern vCircle_2D**	 vCircle_2D_001;

extern int initialize_vCircle_2D_001() ;

#endif
