#ifndef _PRINT_SCHENE_001_H_
#define _PRINT_SCHENE_001_H_


extern int function_001_01 ():

#endif