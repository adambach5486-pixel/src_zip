#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

//


#include "wTextarea.h"
#include "wTextareaController.h"

#include "param_synse.h"


//
int ParamSynse::Initialization () {

	box_param = (wTextarea**)malloc (sizeof(wTextarea*) * box_param_num );
	if ( box_param == NULL ) {
		printf("We cannot allocate box_param and it exits.\r\n");
		exit(-1);
	}

	return 0;
}



