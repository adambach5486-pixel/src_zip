#ifndef _JACKSON_ANIMATION_FOCUS_003_UT_H_
#define _JACKSON_ANIMATION_FOCUS_003_UT_H_

extern int initilize_jackson_animation_focus_003_ut () ;
extern int set_log_debug_message_flag (int df);
extern ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () ;

#endif
