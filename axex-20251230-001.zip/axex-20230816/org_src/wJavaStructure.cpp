#include "wJavaStructure.h"

wJavaStructure::wJavaStructure () {

}

void wJavaStructure::set_ClassName ( char* classname, int raw, int line ) {

	this->ClassName = classname;
	this->class_raw = raw;
	this->class_line = line;

}

