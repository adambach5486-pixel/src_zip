#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include "wButton.h"
#include "wController.h"

wController::wController ( char* cn )
{
}

int wController::addButton( wButton *btn)
{
	return 0;
}

int wController::paintWindowProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	return 0;
}

