#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vPoint.h"
#include "vJoint.h"
#include "vBebetoGaniMindWell.h"

/*
 *
In 1994, All soccer player respect Bebeto's ball technics.
He opens both knees outside very soft and role a ball well inside.
That is one of basic skills not like Stanley Matthews and at the least opposite to him.
Fun of soccer usually think, that is arranged Matthews skill and beautiful.
 *
 */

// 20250708
int vBebetoGaniMindWell::BebetoGaniMindWell_First_Creation () {
	vPoint** result1;
	vPoint** result2;
	// You do not loss interesting that.
	// Human body and animals already know
	// which way is effective in the tube on its bend.
	
	return 0;
}

// 20250216
vPoint** vBebetoGaniMindWell::reallocation_set_point_2d (int num) {
	vPoint** result;
	int i;

	printf("vPoint** vBebetoGaniMindWell::reallocation_set_point_2d (int num) starts.\r\n");

	result = (vPoint**) malloc ( sizeof(vPoint*) * bones_max_006_01 );
	for (i= 0; i<bones_max_006_01; i++) {
		result[i] = bones_006_01[i];
	}

	for (i= 0; i<num; i++) {
		free ( bones_006_01[i] );
	}

	free(bones_006_01);

	printf("vPoint** vBebetoGaniMindWell::reallocation_set_point_2d (int num) ends.\r\n");
	return result;
}

// 20250216
int vBebetoGaniMindWell::SetPoint2D( float x, float y ) {
	int i;
	printf("int vBebetoGaniMindWell::SetPoint2D( float x, float y ) starts.\r\n");

	printf("|%p|%p|\r\n", NULL, nullptr );
	printf("1: [%d/%d]|%p| %0.3f, %0.3f\r\n", bones_index_006_01, bones_max_006_01, bones_006_01, x, y );

	if ( bones_max_006_01 == 0 || bones_006_01 == NULL ) {
		printf("bones_max_006_01 is 0 or bones_006_01 is MULL.\r\n");
		bones_max_006_01 = 16;
		bones_006_01 = (vPoint**) malloc ( sizeof(vPoint*) * bones_max_006_01 );
		if ( bones_006_01 == NULL ) {
			printf("bones_006_01 is NULL.\r\n");
			exit(-1);
		}

		for ( i = 0; i<bones_max_006_01; i++ ) {
			bones_006_01[i] = nullptr;
		}
		bones_index_006_01 = 0;
	}

	printf("2: bone index %d / %d max %d\r\n", bones_index_006_01, bones_max_006_01 );

	if ( bones_index_006_01 >= bones_max_006_01 ) {
		bones_max_006_01 *= 2;
		bones_006_01 = 	reallocation_set_point_2d ( bones_max_006_01 / 2);
	}

	printf("3: -> bone index %d / %d max %d\r\n", bones_index_006_01, bones_max_006_01 );
	printf("4: [%d]|%p| %0.3f, %0.3f\r\n", bones_index_006_01, &(bones_006_01[bones_index_006_01]), x, y );

	if ( bones_006_01[bones_index_006_01] == nullptr) {
		bones_006_01[bones_index_006_01] = (vPoint*) memorizevPoint (0.0f, 0.0f, 0.0f);
	}
	bones_006_01[bones_index_006_01]->setPoint( x, y, 0.0f);

	bones_index_006_01++;

//	Paarams
//	vPoint* bones_006_01 = nullptr;
//	int bones_index_006_01 = 0;
//	int bones_max_006_01 = 10;

	printf("5: inc index %d head changed [0]|%p| %0.3f, %0.3f\r\n", bones_index_006_01, bones_006_01, x, y );

	printf("int vBebetoGaniMindWell::SetPoint2D( float x, float y ) ends.\r\n");
	return 0;
}

// 20250216
vPoint** vBebetoGaniMindWell::GetPoints(int* num) {
	printf("vPoint** vBebetoGaniMindWell::GetPoints(int* num) starts.\r\n");
	vPoint** result = nullptr;
	*num = bones_index_006_01;
	result = (vPoint**) bones_006_01;
	printf("set *num %d result|%p| result[0]|%p|\r\n",*num, result, result[0] );
	printf("vPoint** vBebetoGaniMindWell::GetPoints(int* num) ends.\r\n");
	return result;
}

// 20250615
int vBebetoGaniMindWell::Print3DBones() {
	int i;
	printf("int vBebetoGaniMindWell::Print3DBones() starts.\r\n");
	printf("this->create_bones_initialized = %d\r\n",this->create_bones_initialized );
	for ( i=0; i<this->bones_max; i++ ) {
		printf("bones[%d] %3.3f, %3.3f, %3.3f\r\n", i, bones_001[i].x, bones_001[i].y, bones_001[i].z );
	}

	printf("int vBebetoGaniMindWell::Print3DBones() ends.\r\n");
	return 0;
}

// 20250615
vPoint** vBebetoGaniMindWell::GetPoints3D(int* num) {
	vPoint** result = nullptr;
	int i;
	printf("vPoint** vBebetoGaniMindWell::GetPoints3D(int* num) starts.\r\n");
	*num = bones_max;
	printf("set *num %d result|%p|%p|\r\n",*num, &result, result);
	printf("bones|%p|%p|%p|%p(+1)|", &bones_001, bones_001, &bones_001[0], &bones_001[1] );
//o	result = (vPoint**) &bones_001;

	result = (vPoint**) malloc ( sizeof(vPoint*) * bones_max );
	printf("set *num %d result|%p|%p|\r\n",*num, &result, result);
	for (i= 0; i<bones_max_006_01; i++) {
		result[i] = (vPoint*) memorizevPoint ( bones_001[i].x, bones_001[i].y, bones_001[i].z );
		result[i]->setPoint ( bones_001[i].x, bones_001[i].y, bones_001[i].z );
//		result[i] = (vPoint*) &bones_001[i];
	}

	printf(" -> set *num %d result|%p| result[0]|%p|\r\n",*num, result, result[0] );
	printf("vPoint** vBebetoGaniMindWell::GetPoints3D(int* num) ends.\r\n");
	return result;
}


// 20250225
// 20250528
// O, X, Y, Z
vLine** vBebetoGaniMindWell::GetAxex(int* num) {
	printf("vLine** vBebetoGaniMindWell::GetAxex(int* num) starts.");
	*num = this->axex_line_max;
	printf("line|%p| num %d\r\n", axex_line_3d_002, this->axex_line_max);
	printf("vLine** vBebetoGaniMindWell::GetAxex(int* num) ends.\r\n");
	return axex_line_3d_002;
}

// 20250225
// 20250528
// O, X, Y, Z
vLine** vBebetoGaniMindWell::GetAxex2D(int* num) {
	printf("vLine** vBebetoGaniMindWell::GetAxex2D(int* num) starts.");
	*num = this->line_2D_max;
	printf("line|%p| num %d\r\n", line_2D, this->line_2D_max);
	printf("vLine** vBebetoGaniMindWell::GetAxex2D(int* num) ends.\r\n");
	return line_2D;
}

//
int vBebetoGaniMindWell::SetupAxex () {

	printf("int vBebetoGaniMindWell::SetupAxex () ends.\r\n");

	//vLine** axex_line_3d_002 = nullptr;
	axex_line_max = 3;

	if ( axex_line_3d_002 == nullptr) {
		axex_line_3d_002 = (vLine**) malloc (sizeof(axex_line_3d_002) * axex_line_max);
		if ( axex_line_3d_002 == nullptr) {
			printf("axex_line_3d_002 exit.\r\n");
			exit(-1);
		}
	}

	line_2D_max = 3;
	if ( line_2D == nullptr ) {
		line_2D = (vLine**) malloc ( sizeof (vLine*) * line_2D_max );
		if ( line_2D == nullptr) {
			printf("line_2D exits.\r\n");
			exit(-1);
		}
	}


	axex_line_3d_002[0] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 500.0f, 0.0f, 0.0f ) );
	axex_line_3d_002[1] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 500.0f, 0.0f ) );
	axex_line_3d_002[2] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 500.0f ) );

	printf("axex_line_3d_002 |%p|\r\n", axex_line_3d_002 );

	line_2D[0] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 0.0f ) );
	line_2D[1] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 0.0f ) );
	line_2D[2] = (vLine*) memorizevLine ( memorizevPoint( 0.0f, 0.0f, 0.0f ), memorizevPoint( 0.0f, 0.0f, 0.0f ) );

	printf("int vBebetoGaniMindWell::SetupAxex () starts.\r\n");
	return 0;
}

int vBebetoGaniMindWell::SetupScreen () {
	vPoint* eye = nullptr;
	vPoint p[4];
	int random_int = 0;

	srand(time(NULL));   // Initialization, should only be called once.
	random_int = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
	random_int = random_int % 4;

	p[0].setPoint ( 1000.0f, 1000.0f, -1000.0f);
	p[1].setPoint ( 1000.0f, 1000.0f,  1000.0f);
	p[2].setPoint (-1000.0f, 1000.0f, -1000.0f);
	p[3].setPoint (-1000.0f, 1000.0f,  1000.0f);

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );

//	screen_006.setEye ( *eye );
	screen_006.setEye ( p[random_int] );

	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	return 1;
}

//20250216
int vBebetoGaniMindWell::CreateBones () {
	//vPoint bones_001[10];
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;
	int a;

	printf("vBebetoGaniMindWell:: CreateBones () starts.\r\n");
	a = wait_sharp_short_time () ;

	this->SetupScreen ();
	this->SetupAxex ();

	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_001[0].setPoint (  0.0f,  0.0f,    0.0f );
	bones_001[1].setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_001[1], bones_001[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_001[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_001[j-1].print();
			bones_001[j].print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_001[ j ].setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->bones_max_index = 0;
	this->bones_index_006_01 = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->SetPoint2D( x, y );
		printf("code block set loop %d / index %d ends.\r\n", j, this->bones_index_006_01);
		if ( debug_print_msg_sleep () == 1 ) Sleep(1000);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_001 print %d starts.\r\n", j);
		bones_001[j].print();
		printf("bones_001 print %d ends.\r\n", j);
	}

	a = wait_sharp_short_time () ;

	for ( int j=0; j<this->bones_index_006_01; j++ ) {
		printf("bones_006_01 print %d starts.\r\n", j);
		bones_006_01[j]->print();
		printf("bones_006_01 print %d ends.\r\n", j);
	}

	this->bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	// axex -> 2D
	this->Organize_Axex_2D ( axex_line_3d_002, axex_line_max );

	printf("vBebetoGaniMindWell:: CreateBones () ends.\r\n");
	Sleep(5000);
//	exit(-1);
	return 0;
}

//
int vBebetoGaniMindWell::PrintEye () {
	screen_006.eye.print();
	return 0;
}

//
int vBebetoGaniMindWell::SetEye (vPoint p) {

	screen_006.setEye (p);
	return 0;
}


// 20250611
int vBebetoGaniMindWell::ConvertionBonesOntheFace () {
	float x, y;

	this->bones_max_index = 0;
	this->bones_index_006_01 = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_001[j], &x, &y );
		this->SetPoint2D( x, y );
		printf("code block set loop %d / index %d ends.\r\n", j, this->bones_index_006_01);
		if ( debug_print_msg_sleep () == 1 ) Sleep(1000);
	}

	return 0;
}

// 20250611
int vBebetoGaniMindWell::CreateBones_call_one_time () {
	if ( this->create_bones_initialized == -1 ) {
		this->CreateBones ();
		this->create_bones_initialized = 1;
	}

	return 0;
}

// 20250528
int vBebetoGaniMindWell::Organize_Axex_2D (vLine** lines, int num) {
	int i;
	vPoint* p1;
	vPoint* p2;
	int a;
	float x, y;
	printf("int Draw_Organaize_Axex (vLine** lines, int num) starts.\r\n");

	printf("Initialized lines |%p|\r\n", lines);
	printf("Initialized lines[%d] |%p|\r\n", 0, lines[0] );
	if ( lines == NULL || lines[0] == NULL ) {
		printf("lines is NULL.\r\n");
		exit(-1);
	}

	printf("Initialized line_2D |%p|\r\n", line_2D);
	printf("Initialized line_2D[%d] |%p|\r\n", 0, line_2D[0] );
	if ( line_2D == NULL || line_2D[0] == NULL ) {
		printf("line_2D is NULL.\r\n");
		exit(-1);
	}

	for ( i = 0; i<num; i++ ) {
		p1 = lines[i]->p1;
		p2 = lines[i]->p2;
		printf("line[%d](%0.3f,%0.3f,%0.3f) -> (%0.3f,%0.3f,%0.3f)\r\n", i, p1->x, p1->y, p1->z, p2->x, p2->y, p2->z );

		a = screen_006.get_cooordinate_on_screen ( *p1, &x, &y );
		printf("For loop1: line_2D |%p|\r\n", line_2D);
		printf("For loop1: line_2D[%d] |%p|\r\n", i, line_2D[i] );
		printf("For loop1: line_2D[%d]->p1 |%p|\r\n", i, line_2D[i]->p1 );
		printf("For loop1: line_2D[%d]->p1->x |%0.3f|\r\n", i, line_2D[i]->p1->x );
		line_2D[i]->p1->x = x;
		line_2D[i]->p1->y = y;
		line_2D[i]->p1->z = 0.0f;


		a = screen_006.get_cooordinate_on_screen ( *p2, &x, &y );
		printf("For loop2: line_2D |%p| index %d\r\n", line_2D, i );
		printf("For loop2: line_2D[%d] |%p|\r\n", i, line_2D[i] );
		printf("For loop2: line_2D[%d]->p1 |%p|\r\n", i, line_2D[i]->p1 );
		printf("For loop2: line_2D[%d]->p1->x |%0.3f|\r\n", i, line_2D[i]->p1->x );
		line_2D[i]->p2->x = x;
		line_2D[i]->p2->y = y;
		line_2D[i]->p2->z = 0.0f;

		// Print
		p1 = line_2D[i]->p1;
		p2 = line_2D[i]->p2;
		printf("-> line2D [%d](%0.3f,%0.3f,%0.3f) -> (%0.3f,%0.3f,%0.3f)\r\n", i, p1->x, p1->y, p1->z, p2->x, p2->y, p2->z );
	}

//	a = Print_Refresh_Several_Focus();

	printf("int Draw_Organaize_Axex (vLine** lines, int num) ends.\r\n");
	return 0;
}


