#ifndef _FILEWRITER_000_
#define _FILEWRITER_000_
//...
extern int filewriter_000 ();
extern int set_filewriter_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_000 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
