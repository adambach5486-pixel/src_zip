#ifndef CLIENT_H
#define CLIENT_H

extern int __cdecl client_main(int argc, char **argv);

#endif
