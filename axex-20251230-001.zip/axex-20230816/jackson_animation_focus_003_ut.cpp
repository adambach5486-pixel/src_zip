#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"
#include "control_image_layer_010.h"

#include "vModelBufferController.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"
#include "jackson_animation_focus_003_02.h"
#include "jackson_animation_focus_003_ut.h"


#include "winmainthread_005a_009.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_001.h"


//
// jackson_animation_focus_003_ut.h
// jackson_animation_focus_003_ut.cpp
//
// control_image_layer_010.h


int initilize_jackson_animation_focus_003_ut () ;
int set_log_debug_message_flag (int df);
ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () ;

int set_log_debug_message_flag (int df) {
	log_001.set_debug_log_flg (df);
	return 0;
}



//
int initilize_jackson_animation_focus_003_ut () {


	l_settle_grid.set_log_001(&log_001);
	Set_lot_001_Control_Image_Layer_001 (&log_001);

	return 0;
}

//
ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () {
	int a;
	ANIMATION_FOCUS_FRAME* lp_jackson =NULL;
	ANIMATION_FOCUS* a_rect = NULL;

	printf("ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () starts.\r\n");

	lp_jackson = (ANIMATION_FOCUS_FRAME*) get_jackson_pointer_animation_thread ();
	if ( lp_jackson->initialized == 1 ) return lp_jackson;

	printf("001\r\n");

	a = initilize_jackson_animation_focus_003_ut ();

	printf("002\r\n");

	a = Random_Work_Param () ;
	printf("002-01\r\n");
	a = Check_Initialize_Param ();
	printf("003\r\n");

	a = initialize_ppm_fonts ();
	printf("004\r\n");

	a = Set_Background_Colour_Rgb ( 255, 128, 128 );
	a = initialize_canvas ();


	a = Set_Background_Colour_Rgb ( 223, 223, 223 );
	a = Set_Background_Rect ( 330, 190, 300, 160 ) ;
	a = set_focus ( 320, 180, 320, 180 );
	a = Set_Grid_Colour_Rgb ( 255, 64, 64 );
	a = lp_jackson->draw_grid();

	printf("005\r\n");

	a_rect = (ANIMATION_FOCUS*) malloc(sizeof(ANIMATION_FOCUS));

	a = Stack_Oneof_Several_Focus (a_rect);
	printf ("lp_jackson->several_focus.history_several_focus_index %d\r\n", lp_jackson->several_focus.history_several_focus_index);
	a = Print_Refresh_Several_Focus  ();
	a_rect = Pop_Oneof_Several_Focus ();
	a = Print_Refresh_Several_Focus  ();
	printf ("lp_jackson->several_focus.history_several_focus_index %d\r\n", lp_jackson->several_focus.history_several_focus_index);
	printf("006\r\n");

	a = Stack_Oneof_Several_Focus_Large (a_rect, 3, 0, 0);
	a = Stack_Oneof_Several_Focus_Large (a_rect, 3, 0, 0);
	a = Stack_Oneof_Several_Focus_Large (a_rect, 3, 0, 0);
	printf ("lp_jackson->several_focus.history_several_focus_index %d\r\n", lp_jackson->several_focus.history_several_focus_index);
	a = Print_Refresh_Several_Focus  ();
	a_rect = Pop_Oneof_Several_Focus ();
	a = Print_Refresh_Several_Focus  ();
	printf ("lp_jackson->several_focus.history_several_focus_index %d\r\n", lp_jackson->several_focus.history_several_focus_index);
	printf("007\r\n");


	printf("initilize_jackson_animation_focus_003_canvas_ut: debug_other_stack_killed %d\r\n", debug_other_stack_killed);
	if ( debug_other_stack_killed < 4 ) {
		printf("debug_other_stack_killed < 4\r\n");
		exit(-1);
	}



	a = Stack_Focus_Rect (a_rect);
	a = Print_Refresh_Focus_Focus_Rects ();
	if ( debug_print_msg_sleep () == 1 ) Sleep(2000);
	a_rect = (ANIMATION_FOCUS*)Pop_Focus_Rect ();
	a = Print_Refresh_Focus_Focus_Rects ();
	if ( debug_print_msg_sleep () == 1 ) Sleep(2000);

	printf("008\r\n");

	lp_jackson->initialized = 1;


	debug_other_stack_killed = 2;

	printf("ANIMATION_FOCUS_FRAME* initilize_jackson_animation_focus_003_canvas_ut () ends.\r\n");
	return lp_jackson;
}

