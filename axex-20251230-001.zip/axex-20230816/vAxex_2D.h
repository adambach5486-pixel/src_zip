#ifndef _VAXEX_2D_H_
#define _VAXEX_2D_H_

class vAxex_2D {

public:
	vPoint *right = nullptr;
	vPoint *up = nullptr;
	vPoint *depth = nullptr;
	vPoint *eye_001 = nullptr;
	vPoint *center = nullptr;

public:
	float x, y, r, distance, width, height;

private:
	vCalculation Calc;

public:
	vAxex_2D ();
	vAxex_2D ( float xx, float yy, float rr, float d_distance);
	int SetUp ( float xx, float yy, float zz ) ;
	int SetRight ( float xx, float yy, float zz ) ;
	int SetDepth ( float xx, float yy, float zz ) ;
	int SetEye ( float xx, float yy, float zz ) ;
	int SetCenter ( float xx, float yy, float zz ) ;
	int Calculation_Axex ( ) ;
	int Calculation_Axex_002 ( ) ;
	int SetWidth ( float w ) ;
	int SetHeight ( float h ) ;
	int CheckAxex () ;
	int CheckBaseAxexAndAllocation () ;

};

#endif
