#include <stdio.h>
#include <stdlib.h>

#include "Ban.h"

int Ban::inside (int mx, int my, int* koma_x, int* koma_y ) {

	return 0;
}
