#ifndef _IMAGE_LAYER_001_H_
#define _IMAGE_LAYER_001_H_

typedef struct {
	int x;
	int y;
	int width;
	int height;
	unsigned char*** image = NULL;
}Img_001;

class Image_Layer_001 {

	public:
	
	private:
		int layer_index = 10;
		Img_001	**layer;

	public:
		void initialize_image_layer ();
		void set_image_layer (int layer_num, int xpos, int ypos, unsigned char* rgbt) ;
		void set_default_image_layer () ;
		unsigned char* get_image_layer (int layer_num, int xpos, int ypos) ;
		int get_width (int l);
		int get_height (int l);
		int get_posx (int l);
		int get_posy (int l);
		unsigned char* get_image_layer_001 (int layer_num, int xpos, int ypos) ;
		// rectangle
		void set_image_layer_size (int layer_num, int lxpos, int lypos, int lwidth, int lheight ) ;


};

#endif






