#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

//#include <ctime>
#include <windows.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"

aToken::aToken () {
	initialize_parse();
}

int aToken::clear_token()
{
	printf("int aToken::clear_token() starts.\r\n");

	free(this->token);
	free(this->dummy_token);
	m_cnt_tkn = 0;
	m_size = 8;

	this->token = NULL;

	printf("token|%s|\r\n", this->token);

	printf("int aToken::clear_token() ends.\r\n");
	return 1;
}

int aToken::getRaw()
{
	return m_raw - 1;
}

//20241008
// dummy_token
// token
// m_cnt_tkn
// m_size
char* aToken::put_token (char c) {
	char *l_dummy;
	// 20181231 commented out.
	// 20280420 problem solution temporarily.
	// 1. token[0] is line end.
	// 2. at least analyzer is trying to analyze program keyword ( means not skkipping ).
//	if ( m_cnt_tkn == 0 && c == '\n' ) {
//		err_msg_006( "m_mode: %d token[0] is line end. filename %s: line %d raw %d", m_mode, m_filename, m_line, m_raw );
//		exit ( -1 );
//	}

	printf("start of aToken::put_token: m_size=%d m_cnt_tkn=%d\r\n", m_size, m_cnt_tkn);

	if ( m_cnt_tkn == 0 ) {
		token = (char * )string_allocation ( m_size );
	}

	m_cnt_tkn++;
	//m_counter ( c );

	if ( m_size <= m_cnt_tkn ) {
		m_size *= 2;
		dummy_token = (char * )string_allocation ( m_size );
		for ( int i=0; i< m_cnt_tkn; i++) {
			*( dummy_token + i ) = *( token + i );
		}
		free(token);
		token = dummy_token;
	}

	*( token + m_cnt_tkn - 1) = c;
	*( token + m_cnt_tkn ) = '\0';

	printf("put_token:token=%s\r\n", token );

	printf("aToken::end of put_token:\r\n");

	return token;
}

// 20241009
// dummy_token
// token
// m_cnt_tkn
// m_size
//
// return 1: success
// return 0: success
int aToken::last_token ( char* c_str ) {
	int result;

	result = m_last_with( token, c_str);
	if (result > 0 ) return 1;

	return 0;
}

//
//
//
//
//
//
int aToken::getLine()
{
	return m_line;
}

//
//
//
//
//
char aToken::getChar( FILE *fp, int *index, int *file_end )
{
	char dummy[256];

	m_fread ( dummy, 1, fp);
	*index++;

	return dummy[0];
}


// Qualified: 20190921: found #define: 
//
//
//
//
//
char* aToken::getToken( FILE *fp, int *index, int *file_end )
{
	static char dummy[256];
	int breakable = 0;
	int mode_token = 0;
	int found = 0;

	int a = set_level_error_msg;

	level_error_msg = 3;
	set_level_error_msg = 3;

	err_msg_006( "start of aToken::getToken\r\n" );

	for ( int i=( *index ); i< (*file_end) && breakable == 0 && i <PARSE_NUM; i++ ) {
		err_msg_006( "g i: %d / %d \r\n", i, PARSE_NUM );
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );
		err_msg_006( "token: %s / mode_token:%d \r\n", token, mode_token );
		switch ( mode_token ) {
		case 0: // find any first literals.
			found = found_first_literals( token, fp, &i, file_end);
			break;
		case 1:
			break;
		case 2:
			break;
		}

		err_msg_006("found %d \r\n", found );
		switch( found ) {
		case 1:
			this->skip_to( (char*) "*/", &i, (*file_end), fp);
			found = 0;
			this->free_main_token();
			break;
		case 2: // found #define
			//this->free_main_token();
			breakable = 1;
			//exit(-1);
			break;
		case 3: // found #include
			//this->free_main_token();
			breakable = 1;
			//exit(-1);
			break;
		case 4: // found type that means function starts.
			breakable = 1;
			break;
		}

		(*index) = i;
	}

	err_msg_006("end of aToken::getToken return |%s| found %d \r\n", token, found );

	set_level_error_msg = a;
	return token;
}




// return 0: "\r\n", "\n" and space which means we could skip them.
// return 1: "/*" which means comment out.
// 
//
//
int aToken::found_first_literals( char* p_token, FILE *fp, int *index, int *file_end )
{
	static char dummy[256];
	int result = 0;
	int breakable = 0;

	int a = set_level_error_msg;
	level_error_msg = 2;
	set_level_error_msg = 3;

	err_msg_006("start of found_first_literals: %s\r\n", p_token );

	for ( int i=( *index ); i< (*file_end) && breakable == 0 && i < (*index) + 3; i++ ) {
		err_msg_006("g000 i: %d \r\n", i - (*index) );
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );
		err_msg_006("g000 token=%s\r\n", token );

		switch( dummy[0] ) {
		case ' ':
		case '\n':
			this->free_main_token ();
			result = 0;
			break;
		default:
			if ( m_compare( token, "\r\n") == 1 ) {

				result = 0;
			} else if ( m_compare( token, "/*") == 1 ) {

				result = 1;
				breakable = 1;
			} else if ( m_compare( token, "#define") == 1 ) {
				result = 2;
				breakable = 1;
			} else if ( m_compare( token, "#include") == 1 ) {
				result = 3;
				breakable = 1;
			} else if ( found_type( token ) == 1 ) {
				result = 4;
				breakable = 1;
			}
			// printf("g000 result=%d\r\n", result);
			// exit(-1);
			break;
		}

	}

	err_msg_006("end of found_first_literals: %d\r\n", result );

	set_level_error_msg = a;
	return result;
}

int aToken::found_type( char* p_token ) {

	if ( m_compare( p_token, "void") == 1 ) {
		err_msg_006("p_token: %s\r\n", p_token );
		//exit(-1);
		return 1;
	} else if ( m_compare( p_token, "int") == 1 ) {
		err_msg_006("p_token: %s\r\n", p_token );
		//exit(-1);
		return 1;
	}

	return 0;
}

//
//
//
//
//
char* aToken::getToken_002( FILE *fp, int *index, int *file_end )
{
	char dummy[256];
	int breakable = 0;

	printf("start of aToken::getToken\r\n");

	for ( int i=( *index ); i< (*file_end) && breakable == 0 && i <100; i++ ) {
		printf("g i: %d \r\n", i );
		m_fread ( dummy, 1, fp);
		token = put_token ( dummy[0] );
		printf("token: %s\r\n", token);
	}

	printf("end of aToken::getToken\r\n");
	exit(-1);

	return token;
}

// 20190227
// When we use tokenizer, we just call getToken.
//
//
//
char* aToken::getToken_001( FILE *fp, int *index, int *file_end )
{
	char *c_dummy;
	char dummy[256];
	int previous_index = 0;
	int mode_token = 0; // skip
	// 0: skip
	// 1: 
	// 2: 
	int breakable = 0;
	dummy[0] = '\0';

	printf("start of aToken::getToken\r\n");

	for ( int i=( *index ); i< (*file_end) && breakable == 0; i++ ) {
		previous_index = i;
		m_fread ( dummy, 1, fp);
		printf("i=%d mode_token=%d token=|%s|\r\n", i, mode_token );

		switch(mode_token) {
		case 0:
			switch(dummy[0]) {
			case ' ':
				break;
			default:
				if ( is_alphabet( dummy ) == 1 ) {
					mode_token = 1;
				} else {
					mode_token = 2;
				}
				token = put_token ( dummy[0] );
				// printf("token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				break;
			}
			break;
		case 1:
			//Judge if line end or not
			switch(dummy[0]) {
			case '\r':
				i++;
				m_fread ( dummy, 1, fp);
				if ( dummy[0] == '\n' ) mode_token = 0;
				else {
					printf("after \\r \r\n"); 
					exit(-1);
				}
				break;
			case '\n':
				mode_token = 0;
				break;
			default:
				token = put_token ( dummy[0] );
				break;
			}
			break;
		case 2:
			printf("case 2:token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
			if ( line_or_space ( dummy ) == 1 ) {
				breakable = 1;
				*index = i;
			} else {
				token = put_token ( dummy[0] );
				printf("case 2-2:token=%s dummy=%s dummy[0]=%c\r\n", token, dummy, dummy[0] );
				// judge comment out
				if ( m_compare( token, "/*" ) == 1 ) {
					breakable = 1;
					*index = i;
				}
			}
			break;
		}

		// DEBUG
		if ( previous_index > i ) {
			printf("getToken: previous_index > i\r\n");
			printf("getToken: i=%d previous_index=%d\r\n", i, previous_index );
			exit(-1);
		}

	}

	backward( dummy );
	c_dummy = copyof( dummy );
	c_dummy = m_trim ( c_dummy );

	printf("aToken::getToken token=%s\r\n", token);
	printf("aToken::getToken c_dummy=%s\r\n", c_dummy);
	// return token;

	// DEBUG check
	if ( m_contains ( c_dummy, (char*)"\r\n" ) == 1 || m_contains ( c_dummy, (char*)"\n" ) == 1 ) {
		exit(-1);
	}

	printf("end of aToken::getToken\r\n");
	return token;
}


// prototype:
//
//
//
//
//
int aToken::block_to_function_end( int *index , int file_end, FILE *fp) {
	char dummy[256];
	char* a_token = nullptr;

	int breakable = 0;
	int ii = *index;

	int count_1 = 0;
	int count_2 = 0;

	// function start which is '{'.
	// function end which is '}'.

	for( ii=*index; ii<file_end && ii<PARSE_NUM && breakable == 0; ii++ ) {
		if ( ii % 100 == 98 ) {
			sleep (1);
		}
		m_fread ( dummy, 1, fp);
		a_token = m_concat( a_token, &dummy[0] );

		// count { as 1
		// count } as 2
		switch( dummy[0] ) {
		case '{':
			count_1++;
			// error, so break
			if ( count_1 <= count_2 ){
				breakable = 1;
				break;
			}
			break;
		case '}':
			count_2++;
			// end, so break
			if ( count_1 == count_2 ) {
				breakable = 1;
				break;
			}
			break;
		case ';':
			//prototype
			breakable = 1;
			break;
		}
	}

	this->block = a_token; // the answer of token.
	err_msg_006( "a_token: %s\r\n", a_token );
//	exit(-1);

	return 1;
}

//
//
//
//
//
//
int aToken::block_to( char* block_to, int *index , int file_end, FILE *fp) {
	char dummy[256];
	aToken *iToken = nullptr;
	char *parse_token;
	iToken = new aToken();
	int ii = *index;
	char *b_token = nullptr;
	char *a_token = nullptr;
	int counter = 0;

	level_error_msg = 3;

	a_token = char_string(1);
	a_token[0] = (char)'\0';

	int acnt = array_count(block_to);

	err_msg_006("block to: %s\r\n", block_to);
	for( ii=*index; ii<file_end && ii<PARSE_NUM; ii++ ) {
		if ( ii % 100 == 98 ) {
			sleep (1);
		}
		m_fread ( dummy, 1, fp);
		a_token = m_concat( a_token, &dummy[0] );
		counter++;

		b_token = substring(a_token, counter - acnt, acnt);
		err_msg_006("ii: %d file_end: %d counter: %d acnt: %d a_token: |%s| b_token: |%s| block_to: |%s|\r\n", ii, file_end, counter, acnt, a_token, b_token, block_to );
		if ( m_compare( b_token, (char *) block_to ) == 1 ) {
			// donot use token just use merge
			// this->block = substring( a_token, 0, counter - acnt);
			this->block = a_token;
			err_msg_006("block_to ends: ii %d raw %d line %d block |%s| array_count=%d\r\n", ii, iToken->getRaw(), iToken->getLine(), this->block, array_count(a_token) );
			*index = ii;
			return 1;
		}
	}

	*index = ii;

	err_msg_006( "return -1 index %d \r\n", *index );
	exit(-1);

	return -1;
}

//
//
//
//
//
//
int aToken::skip_to( char* skip_to, int *index , int file_end, FILE *fp) {
	char dummy[256];
	aToken *iToken = nullptr;
	char *parse_token;
	iToken = new aToken();
	int ii = *index;
	char *a_token = nullptr;
	char *b_token = nullptr;

	int counter = 0;
	int acnt = array_count(skip_to);

	err_msg_006("skip to: %s\r\n", skip_to);
	for( ii=*index; ii<file_end && ii<PARSE_NUM; ii++ ) {
		if ( ii % 100 == 98 ) {
			sleep (1);
		}

		err_msg_006("loop1:\r\n");
		m_fread ( dummy, 1, fp);
		err_msg_006("loop2:\r\n");
		a_token = m_concat( a_token, &dummy[0] );
		err_msg_006("loop3:\r\n");
		b_token = substring(a_token, counter - acnt, acnt);
		err_msg_006("loop4:\r\n");

		// b_token = copyof("*/");
		err_msg_006("ii: %d file_end: %d counter: %d a_token: %s b_token: %s \r\n", ii, file_end, counter, a_token, b_token );

		if ( m_compare( b_token, (char *) skip_to ) == 1 ) {
			// donot use token just use merge
			err_msg_006("comment out ends: ii %d raw %d line %d\r\n", ii, iToken->getRaw(), iToken->getLine() );

			free(a_token);
			clean_null_array ();
			*index = ii;
			return 1;
		}

		counter++;
	}

	*index = ii;
	return -1;
}


//
//
//
//
//
int aToken::line_or_space ( char* dummy ) {
	// space
	// "\r\n"

	if ( m_start_with ( dummy, "\n\r" ) == 1 ) {
		//exit( -1 );
		return 1;
	} else if ( m_start_with ( dummy, "\n" ) == 1 ) {
		//exit( -1 );
		return 1;
	} else if ( m_start_with ( dummy, " " ) == 1 ) {
		//exit( -1 );
		return 1;
	} else {

		return 0;
	}
}

//
//
//
// scope
//
void aToken::free_main_token () {
	m_cnt_tkn = 0;
	token[0] = '\0';
	token[1] = '\0';
}

void aToken::backward( char *dummy) {
	// int i = 0;
	char c1, c2;
	int cnt_dummy = array_count ( dummy ) ;

	for ( int i=0; i<cnt_dummy/2 && i<256*256; i++ ) {
		c1 = *( dummy + cnt_dummy - 1 - i );
		c2 = *( dummy + i );
		*( dummy + cnt_dummy -1 - i ) = c2;
		*( dummy + i ) = c1;
		printf("i %d %c %c\r\n",i,  c1, c2);
	}

	printf("backward dummy %s\r\n", dummy);
//	exit(-1);
}

//
//
//
//
//
//
int aToken::is_alphabet( char* char_dummy )
{
	return alphabet( char_dummy[0] );
}


