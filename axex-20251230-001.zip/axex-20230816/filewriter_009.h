#ifndef _FILEWRITER_009_
#define _FILEWRITER_009_
//...
extern int filewriter_009 ();
extern int set_filewriter_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_009 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
