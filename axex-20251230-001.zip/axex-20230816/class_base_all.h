#ifndef _CLSBASEALL_H_
#define _CLSBASEALL_H_

//class_base_all.cpp
class class_base_all {

	public:
		float x, y, z;
	private:
		float lx, ly, lz;

	public:
		int Initialize_param_all ();

	private:
		int Sub_Initialize_param_all ();

};

#endif


