#ifndef _FILE_NUMBERING_H_
#define _FILE_NUMBERING_H_

extern int find_numbering (char* filename);
extern int find_numbering_011 (char* filename, int debug_num );

#endif
