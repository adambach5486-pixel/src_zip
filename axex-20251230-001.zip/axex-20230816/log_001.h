#ifndef _LOG_001_H_
#define _LOG_001_H_

typedef struct {
	char* file_name;
	FILE* fp;
	int index;
	int max_index;
	int from;
	int to;
	int cursol;
	char** log_list;
} LOG_001;

class Logging {

public:

private:
	LOG_001* log_001 = NULL;
	int debug_log_flg = 0;

public:
	LOG_001* init_log ();
	LOG_001* start_log ();
	LOG_001* update_log (char* str_log);
	LOG_001* update_log_001 (char* str_log);
	LOG_001* roll_log ();
	LOG_001* print_log (); //
	LOG_001* end_log ();
	LOG_001* declose_log ();
	void Set_Filename(char* l_filename);
	int set_debug_log_flg (int df);

private:
	FILE* Get_Fp();

};

#endif
