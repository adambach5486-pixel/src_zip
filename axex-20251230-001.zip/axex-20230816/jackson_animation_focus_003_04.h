#ifndef _JACSON_ANIMATION_FOCUS_003_04_H_
#define _JACSON_ANIMATION_FOCUS_003_04_H_

// 20250829
extern int Spin_Eye_thin_axex_bones_one_step ();

#endif
