#ifndef _READ_CSV__010_
#define _READ_CSV__010_
//...
extern int read_csv_000a_010 ();
extern int set_read_csv_000a_010 (char** argv, int argc);
extern int initialize_read_csv_000a_010 (char** argv, int argc);
#endif
