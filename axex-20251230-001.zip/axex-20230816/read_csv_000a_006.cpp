#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_006.h"

extern char* filename_read_csv_000a_006_ = (char*)"read_csv_000a_006.txt";

int read_csv_000a_006 ();
int set_read_csv_000a_006 (char** argv, int argc);
int initialize_read_csv_000a_006 (char** argv, int argc);

int read_csv_000a_006 () {
	return 1;

}


int read_csv_000a_set_006 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_006 (char** argv, int argc) {
 	return 1;
 
}

