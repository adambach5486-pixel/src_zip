#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_005.h"

extern char* filename_read_csv_000a_005_ = (char*)"read_csv_000a_005.txt";

int read_csv_000a_005 ();
int set_read_csv_000a_005 (char** argv, int argc);
int initialize_read_csv_000a_005 (char** argv, int argc);

int read_csv_000a_005 () {
	return 1;

}


int read_csv_000a_set_005 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_005 (char** argv, int argc) {
 	return 1;
 
}

