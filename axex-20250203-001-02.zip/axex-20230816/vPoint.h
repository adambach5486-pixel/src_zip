
#ifndef _VPOINT_
#define _VPOINT_

class vPoint {

	public:
		float x, y, z;

	private:
		int debug_msg = 0;

	public:
		vPoint ( );
		vPoint ( float xx, float yy, float zz);
		setPoint ( float xx, float yy, float zz);
		void print ();

	private:
		vPoint subtract( vPoint a, vPoint b );


};

#endif
