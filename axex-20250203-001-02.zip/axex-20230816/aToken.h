#ifndef _ATOKEN_H_
#define _ATOKEN_H_

class aToken {

	public:
		char *head;
		int head_raw;
		int head_line;
		char *the_string;
		char *block;
		int resultType = -1;
		char* dummy_token;
		char* token;
		int m_cnt_tkn = 0;
		int m_size = 8;


	public:
		aToken ();
		char* getToken( FILE *fp, int *index, int *file_end );
		char* getToken_001( FILE *fp, int *index, int *file_end );
		char* getToken_002( FILE *fp, int *index, int *file_end );
		int is_alphabet( char* char_dummy );
		void backward( char *dummy ) ;
		void free_main_token () ;
		int line_or_space ( char *dummy ) ;
		int getLine();
		int getRaw();
		int skip_to( char* skip_to, int *index , int file_end, FILE *fp) ;
		int block_to( char* skip_to, int *index , int file_end, FILE *fp) ;
		int clear_token () ;
		int found_first_literals( char* p_token, FILE *fp, int *index, int *file_end );
		char getChar( FILE *fp, int *index, int *file_end );
		int block_to_function_end( int *index , int file_end, FILE *fp);
		char* put_token (char c) ;
		int last_token ( char* c_str ) ;

	private:
		int found_type( char* p_token ) ;

};

#endif
