#ifndef _READ_CSV__007_
#define _READ_CSV__007_
//...
extern int read_csv_000a_007 ();
extern int set_read_csv_000a_007 (char** argv, int argc);
extern int initialize_read_csv_000a_007 (char** argv, int argc);
#endif
