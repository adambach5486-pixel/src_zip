#include <stdarg.h>  // ADD: 20191227
#include <stdio.h>   // ADD: 20191227
#include <windows.h> // ADD: 20191227

#include "array_counter.h"	// ADD: 20191227
#include "sender.h"			// ADD: 20191227
#include "Print.h"			// ADD: 20191227

#include "vPoint.h"

vPoint::vPoint ( ) {
}

vPoint::vPoint ( float xx, float yy, float zz) {
	this->x = xx;
	this->y = yy;
	this->z = zz;
}

void vPoint::setPoint ( float xx, float yy, float zz) {
	printf("vPoint::setPoint starts.\r\n");
	printf( "this->x=%f\r\n", this->x );
	printf( "this->y=%f\r\n", this->y );
	printf( "this->z=%f\r\n", this->z );
	this->x = xx;
	this->y = yy;
	this->z = zz;
	printf("vPoint::setPoint ends.\r\n");
}

vPoint vPoint::subtract( vPoint a, vPoint b ) {
	vPoint result;

	return result;
}

void vPoint::print( ) {

	// 20200415
	//log_msg_003("p( %f, %f, %f)\r\n", this->x, this->y, this->z );
	printf("p( %f, %f, %f)\r\n", this->x, this->y, this->z );
}

