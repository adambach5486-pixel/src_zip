#include <stdlib.h>
#include <stdio.h>
//#include <unistd.h> // 20200429 for visualstudio: commented out:

#include <windows.h>

#include "Print.h"
#include "array_counter.h"

#pragma comment(lib, "Ws2_32.lib")

char* dummy_allocation = nullptr;
char** dummy_ary = nullptr;
int dummy_ary_index = 0;
char** replace_dummy_ary = nullptr;


char* char_line_end = (char*)"\r\n";
//char* char_line_end_001 = (char*) "\r\n";

int array_count( char *ary );
char* concat( char *head, char *tail );
char* set_array(char *arry, int n, char c);
void print_string( char *head );
int m_compare ( char* tkn, char* m );

char* m_print_buffer( char* buffer);

char* front_trim( char* c_str ) ;
char* back_trim( char* c_str ) ;
char* m_trim( char* c_str ) ;
int m_start_with ( char *head, char *tail ) ;
int m_contains ( char* c_str, char* c_ref ) ;

//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	err_msg_006("count=%d\n", ac );
//
//	return 0;
//}

void print_memories ();
char** put_memories ( char* str );

void slide_to_back ( char *msg, int i, int count ) ;
void place_char ( char *p_char, char c ) ;


void clean_null_array() {

	replace_dummy_ary = ( char**) malloc ( sizeof( char* ) * dummy_ary_index );

	int index = 0;
	for( int i=0; i< dummy_ary_index; i++) {
		if ( dummy_ary[i] == nullptr ) {
			replace_dummy_ary[ index ] = dummy_ary[i];
			index++;
		}
	}

	free( dummy_ary );

	dummy_ary = replace_dummy_ary;
}

//
//
//
// '\r': 13
// '\n': 10
void place_char ( char *p_char, char c ) {
	char* result_001;
	// result_001 = err_msg_001 ( "start of place_char ");
	// o result_001 = err_msg_001 ( "%d %d %d", p_char, 0, c );
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	//   4249052 3 13
	// x result_001 = err_msg_001 ( "%d %c %d", p_char, *p_char, c );
	// print_memories( p_char ) ;
	// result_001 = err_msg_001 ( "%d %d %d %d", p_char, '\n', '\r', c );
	*p_char = (char) c;
	// o *result_001 = (char) c;
	//   *p_char = *result_001;
	// result_001 = err_msg_001 ( "end of place_char ");
}

//
//
//
//
//
void slide_to_back ( char *msg, int start_i, int count ) {
	char *result_001;
	char c;
	char back_c;

	// result_001 = err_msg_001 ( "slide_to_back: start ");
	for( int i = start_i; i<count - 1; i++ ) {
		// result_001 = err_msg_001 ( "slide_to_back: loop satrt i=%d count %d ", i , count);
		// 003
		if ( i == start_i ) {
			c = *( msg + i );
		} else {
			c = back_c;
		}

		back_c = *( msg + i + 1 );
		// result_001 = err_msg_001 ( "|%3d|", c );	// 001
		place_char ( msg + i + 1, c );				// 002
		// exit(-1);
		// place_char ( msg + i + 1, c ); // slide 1 to back and ensured to place.
		// result_001 = err_msg_001 ( "slide_to_back: loop end   i=%d count %d c=%3d c=%c", i , count, c, c );
	}

	//004
	place_char ( msg + count, '\0' );
	// result_001 = err_msg_001 ( "slide_to_back: end ");
}

//
//
//
//
//
char* m_replace ( char* char_string,
 char* from_string, char* to_string ) {
	char c1, c2;
	int count = array_count( char_string );
	int a_f = array_count( from_string );
	int a_t = array_count( to_string );
	int a_c = 0;
	char* char_string_2 = 
	  (char *) malloc ( sizeof (char)*( count + a_t - 1 ) );

	int cnt_replace = 0;
	for ( int i = 0; i<count; i++ ) {
		c1 = *( char_string + i ) ;
		a_c = 0;
		for ( int j=0; j<a_f && j <count; j++ ) {
			c2 = *( from_string + j ) ;
			if ( c1 != c2 ) break;
			a_c++;
		}

		if ( a_c == a_f && cnt_replace == 0) {
			// match
			int to = i + a_t;
			for( int k=0; k<a_t; k++ ) {
				*( char_string_2 + i + k + cnt_replace*(a_t- a_f ) ) = 
				  *( to_string + k );
			}
			i += a_f - 1 ;
			cnt_replace++;
		} else {
			*( char_string_2 + i + cnt_replace*(a_t- a_f ) ) = c1;
		}
	}
	*( char_string_2 + count + cnt_replace*( a_t - a_f ) ) = '\0';
	put_memories ( char_string_2 );

	return char_string_2;
}

//
//
//
//
//
char** put_memories ( char* str ) {

	if ( dummy_ary_index == 0 ) {
		dummy_ary = (char **) malloc( sizeof(char*) );
		dummy_ary_index = 1;
		dummy_ary[ 0 ] = str;
	} else {
		dummy_ary_index++;
		dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index );
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

	return dummy_ary;
}

//
//
//
//
//
void print_memories () {
	int a = level_error_msg;
	level_error_msg = 6;

	for ( int i=0; i<dummy_ary_index; i++) {
		err_msg_006("dummy_ary[%d]=%s\r\n", i, dummy_ary[i] );
	}

	level_error_msg = a;
}

//
//
//
//
//
//
char* m_print_buffer( char* buffer)
{
	char ALetter[1];
	int a = level_error_msg;

	level_error_msg = 6;

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		err_msg_006("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}

	level_error_msg =  a;

	return NULL;
}

//
//
//
//
//
//
int array_count( char *ary )
{
	char c;
	int a = level_error_msg;

	level_error_msg = 6;
	err_msg_006("start function: array_count:\r\n");

	if ( ary == nullptr ) {
//		err_msg_006("end function: array_count: return -1\r\n");
		return -1;
	}

//	err_msg_006("middle of function: array_count: return -1\r\n");
	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

//	err_msg_006("end function: array_count: return %d\r\n", count);

	level_error_msg =  a;
	return count;
}

//
//
//
//
//
//
int m_compare ( char* tkn, char* m ) {

	int a = level_error_msg;
	level_error_msg = 6;
	err_msg_006("function: m_compare:");

	int count_t = array_count( tkn );
	int count_m = array_count( m );

//	err_msg_006(" %d | %d | %s | %s \r\n", count_t, count_m, tkn, m );

	if ( count_t != count_m ) {
		level_error_msg =  a;
		return -1;
	}

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) {
			level_error_msg =  a;
			return -1;
		 }
	}

	level_error_msg =  a;
	return 1;
}

//
//
//
//
//
int m_start_with ( char *head, char *tail ) {
	int nh, nt, min;
	char c1, c2;

	nh = array_count( head );
	nt = array_count( tail );
	min = nh;
	if ( min > nt ) {
		min = nt;
	}

	for ( int i=0; i<min; i++ ) {
		c1 = *(head + i ) ;
		c2 = *(tail + i ) ;
		if ( c1 != c2 ) {
			return 0;
		}
	}

	return 1;
}

//
//
//
//
//
//
char* m_concat( char *head, char *tail ) {
	int nh, nt;
	static int alloc = 0;
//	char ch, ct;
	char* c_head;

	int a = level_error_msg;

	level_error_msg = 6;
	err_msg_006("start function: m_concat:\r\n");

	nh = array_count( head );
	nt = array_count( tail );
	err_msg_006("array_count: %d %d | %s %s \r\n", nh, nt, head, tail);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			Sleep(1000);
		} else {
			break;
		}
	}

	//err_msg_006("alloc=%d\n", alloc);
	if ( alloc == 0 ) {
		alloc = 1;
		for ( int i=0; i<100; i++) {
			dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
			if ( dummy_allocation != 0 ) break;

			Sleep(1);
			char* d_a = (char *) malloc( 1 );
			free(d_a);
		}
		//dummy_allocation[ nh + nt ] = '\0';
		//err_msg_006("allocation blocks( array_count( dummy_allocation ) ) = %d| %d\n", array_count(dummy_allocation), dummy_allocation);
		alloc = 0;
	}

	for( int i=0; i< nh; i++ ) {
		//err_msg_006("i %d\r\n", i);
		*( dummy_allocation + i ) = *(head + i);
	}

	for( int i=0; i< nt; i++ ) {
		err_msg_006("function m_concat: i %d\r\n", i);
		*( dummy_allocation + nh + i ) = *(tail + i);
	}

	*( dummy_allocation + nh + nt ) = '\0';

//	put_memories(dummy_allocation);
//	print_string(dummy_allocation);
	level_error_msg =  a;

	return dummy_allocation;
}

//
//
//
//
//
//
void print_string( char *head )
{
	int nh;
	char aa[] = { '\0', '\0' };
	int a = level_error_msg;

	level_error_msg = 6;

	nh = array_count( head );
	for( int i=0; i<nh; i++ ) {
		aa[0] = *(head + i);
		err_msg_006( "|%s|%3d|\n", (char*)aa, aa[0] );
	}

	level_error_msg =  a;
}

//
// do not use realloc in under sublootin.
// better solution usually by use of macro of realloc in C.
//
// use global value for allocation.
char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;
	char* c_head;

	int a = level_error_msg;
	level_error_msg = 6;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	err_msg_006("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			Sleep(1000);
		}
		break;
	}
	err_msg_006("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
//		c_head = (char *) realloc( head , sizeof( char ) * ( nh + nt + 1) );
		c_head = (char *) realloc( head , 100 );

		dummy_allocation = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( sizeof(char *) * ( nh + nt + 1 ) );
//		dummy_allocation = (char *) malloc( 100 * ( nh + nt + 1 ) );

//		*( head + nh + nt) = '\0';
		// x *(head) = 0;
		// o head = tail;
		err_msg_006("allocation blocks(head)=%d\n", sizeof( head ) );
		err_msg_006("allocation blocks(*head)=%d\n", sizeof( *head ) );
//		err_msg_006("allocation blocks(array_count(head))=%d\n", array_count(head) );

		err_msg_006("allocation blocks(c_head)=%d\n", sizeof( c_head ) );
		err_msg_006("allocation blocks(tail)=%d\n", sizeof( tail ) );

		// x *(head + 3 ) = ' ';
		//set_array( head, 3, ' ');
		err_msg_006("allocation blocks(array_count(head))=%d\n", array_count(head) );


//		*( dummy_allocation + nh + nt ) = '\0';
		*( dummy_allocation + 1 ) = '\0';
		err_msg_006("allocation blocks( dummy_allocation )=%d\n", sizeof( dummy_allocation ) );
		err_msg_006("allocation blocks( array_count( dummy_allocation ) ) = %d\n", array_count(dummy_allocation) );

		alloc = 0;
	}

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

	level_error_msg =  a;

	return head;
}

//
//
//
//
//
//
char* set_array(char *arry, int n, char c) {

	static char *returnable;

	int a = level_error_msg;
	level_error_msg = 6;

	returnable = arry;
	arry++;
	*arry = c;
	////arry = c;
	//arry = returnable;

	level_error_msg =  a;

	return returnable;
}

// alloc's
//
//
char* char_string ( int num_memories ) {
	dummy_allocation = (char*)malloc( sizeof(char) * num_memories );
	put_memories( dummy_allocation );

	return dummy_allocation;
}

// alloc's
//
//
char* copyof ( char* str ) {
	int ac = array_count(str);
	dummy_allocation = (char*)malloc( sizeof(char) * (ac + 1) );
	put_memories( dummy_allocation );

	for ( int i=0; i<ac; i++) {
		dummy_allocation[i] = str[i];
	}

	dummy_allocation[ac] = '\0';

	return dummy_allocation;
}

//
//
//
//
//
char* m_trim( char* c_str ) {

	char* result = (char*)"\0";
	char* return_result = (char*)"\0";
	result = front_trim ( c_str );
	// return_result = back_trim ( result );

	return result;

	//free( result );
	//return return_result;
}


//
//
//
//
//
char* back_trim( char* c_str ) {

	int skip = 0;
	int f_continue = 0;
	char* result = (char*)"\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	for ( int i=length -1; i >= 0; i-- ) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			if ( skip == 0 ) break; // means continue until it finds another letter except space.
			if ( skip == 1 ) return result;
			break;
		default:
			skip = 1;
			dummy[0] = c;
			result = m_concat ( (char *)dummy, (char *)result );
			break;
		}
	}

	return result;
}

//
//
//
//
//
char* front_trim( char* c_str ) {

	int skip = 0;
	int f_continue = 0;
	char* result = (char*)"\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	int a = level_error_msg;
	level_error_msg = 6;

	for ( int i=0; i< length; i++) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			if ( skip == 0 ) break; // means continue until it finds another letter except space.
			if ( skip == 1 ) {
				//err_msg_006( "result |%s|", result );
				//exit( -1 );
				return result;
			}
			break;
		default:
			skip = 1;
			dummy[0] = c;
			result = m_concat ( (char *)result, (char *)dummy );
			break;
		}
	}

	level_error_msg = a;

	return result;
}

//
//
//
//
//
int m_contains ( char* c_str, char* c_ref ) {

	int unmatch = 0;
	int ref_length = array_count( c_ref );

	int a = level_error_msg;
	level_error_msg = 6;

	int length = array_count( c_str );
	for ( int i=length -1; i >= 0; i-- ) {
		for ( int j=ref_length -1; j >= 0; j-- ) {
			// serr_msg_006("m_contains:|%d|%d|\r\n", c_str[i] , c_ref[j] );
			if ( c_str[i] != c_ref[ j ] ) {
				unmatch = 1;
			}
		}
		if ( unmatch == 0 ) return 1;
		else unmatch = 0;
	}

	level_error_msg = a;

	return 0;
}

