#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include "wTextarea.h"

//void wTextarea::setMode( int m );
//int wTextarea::wTextarea( HDC hdc );
//void wTextarea::setTextarea( int xx, int yy, int w, int h);

wTextarea::wTextarea( char* txt ) {

	this->textarea_name = txt;
	this->mode = 0;

}

void wTextarea::setMode( int m ) {

	this->mode = m;


}

void wTextarea::setTextarea( int xx, int yy, int w, int h) {

	this->x = xx;
	this->y = yy;
	this->width = w;
	this->height = h;

}

// aName 
// 
int wTextarea::paintTextarea(  HDC hdc, char* aname ) {

	RECT rect; 
	//SetTextColor( hdc, RGB(0 ,0, 255));
	//Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	//DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	// Calculation of right and bottom
	int right = this->x + this->width;
	int bottom = this->y + this->height;

    SetRect( &rect, this->x, this->y, right, bottom);

	if ( this->mode == 0 )
		SetTextColor( hdc, RGB(0 ,0, 255) );
	else
		SetTextColor( hdc, RGB(255 ,0, 0) );

	Rectangle( hdc, rect.left, rect.top, rect.right, rect.bottom );
	DrawText( hdc, (LPCWSTR)( aname ), -1, &rect, DT_NOCLIP );

	return 1;
}



// this function draws a button.
// button has a string.
// button has a rect which is one of shapes in this case.
/*int wButton::wdrawButton( HDC hdc, char *button_name, RECT *rect )
{

	SetTextColor( hdc, RGB(0 ,0, 255));

	Rectangle( hdc, rect->left, rect->top, rect->right, rect->bottom );
	DrawText( hdc, TEXT( button_name ), -1, rect, DT_NOCLIP);

	return 1;
}
*/



