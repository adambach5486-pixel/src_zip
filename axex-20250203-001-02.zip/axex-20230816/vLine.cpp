#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"

vLine::vLine ( ) {

	this->p1 = new vPoint();
	this->p2 = new vPoint();
}

vLine::vLine ( vPoint* ap1, vPoint* ap2) {
	this->p1 = ap1;
	this->p2 = ap2;
}

// Qualified : 20190711
//
//
//
//
void vLine::setLine ( vPoint* ap1, vPoint* ap2 ) {
	p1->x = ap1->x;
	p2->x = ap2->x;
	p1->y = ap1->y;
	p2->y = ap2->y;
	p1->z = ap1->z;
	p2->z = ap2->z;
	//printf("p1->x %f ap1->x%f \r\n", p1->x, ap1->x );
}

void vLine::setLine ( float x1, float y1, float z1, float x2, float y2, float z2 ) {
	p1->x = x1;
	p2->x = x2;
	p1->y = y1;
	p2->y = y2;
	p1->z = z1;
	p2->z = z2;
	//printf("p1->x %f ap1->x%f \r\n", p1->x, ap1->x );
}


//
//
//
//
//
void vLine::print () {
	if ( this->p1 == nullptr || this->p2 == nullptr) {
		return;
	}

	if ( debug_msg_001 == 1 ) printf("L|%p| ", this );
	this->p1->print();
	this->p2->print();
}

