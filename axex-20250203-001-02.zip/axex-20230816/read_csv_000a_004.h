#ifndef _READ_CSV__004_
#define _READ_CSV__004_
//...
extern int read_csv_000a_004 ();
extern int set_read_csv_000a_004 (char** argv, int argc);
extern int initialize_read_csv_000a_004 (char** argv, int argc);
#endif
