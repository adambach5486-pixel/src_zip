#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "parse.h"

int m_mode = 0; // start outside class
int m_cnt_tkn = 0;
int m_count = 0;
int m_size = 0;
int m_line = 1;
int m_raw = 1;
char* m_filename;

char* token;

char* string_allocation (int size) ;
char* put_token (char c);
int initialize_parse ();
void m_counter ( char c );
int m_fread ( char* dummy, int a, FILE *fp) ;
int line_end ( char c ) ;
int line_end_win ( char* c ) ;

int alphabet( char c );
int number ( char c );
void clear_token() ;
// char* m_trim( char* c_str );
// char* back_trim( char* c_str );
char* front_trim( char* c_str );

// int m_contains ( char* c_str, char* c_ref );
int m_last_with ( char* c_str, char* c_ref ) ;
int m_last_with_001 ( char* c_str, char* c_ref ) ;

char* substring( char* c_a, int start, int length );
int file_type (char* filename, char* type);
char** split ( char* filename, char c, int* number ) ;

// int m_start_with ( char* c_str, char* c_ref );

//
//
//
//
//
/* int m_start_with ( char* c_str, char* c_ref ) {

	int index = 0;

	int unmatch = 0;
	int ref_length = array_count( c_ref );
	int length = array_count( c_str );
	for ( int i=0; i < length; i++ ) {
		for ( int j=0; j < ref_length; j++ ) {
			
			if ( i + j >= length ) return -1;
			
			//printf("i %d j %d | %c %c\r\n", i, j, c_str[ i + j ], c_ref[j] );
			// sprintf("m_contains:|%d|%d|\r\n", c_str[i] , c_ref[j] );
			if ( c_str[i + j ] != c_ref[ j ] ) {
				unmatch = 1;
				//printf("unmatch\r\n");
			}

			index = j;
		}
		if ( unmatch == 0 ) {
			return index + i;
		}
		else unmatch = 0;
	}

	return -1;
}*/

//
//
//
//
//
//
int file_type (char* filename, char* type) {

	int number;
	int index, s_index;
	int asterisk = 0;

//	printf( "file_type strated.\r\n" );

	// split wild card '*'
	// If you set "*a*b*, match returns number 3 and char[3]"
	char** match = split( type, '*', &number );
//	for( int i=0; i<number; i++ ) {
//		if ( m_compare( match[i], "" ) != 1 )
//			match[i] = "*";
//	}

	int filename_length = array_count ( filename ) ;

	s_index = 0;
	for( int i=0; i<number; i++ ) {
		if ( m_compare( match[i], "" ) != 1 ) {
			asterisk = 0;

			printf ( "match %d %s \r\n", i, match[i] );

			// start with 
			index = m_start_with( filename, match[i] );
			printf ( "index %d %s %s\r\n", index, match[i], filename );

			if ( s_index >= index ) {
				printf( "file_type returned -1.\r\n" );
				return -1;
			}
			s_index = index;

		} else {
			asterisk = 1;
		}
	}

	// filename_length = 12
	// fonemae[0] ~ flename[11];
	if ( asterisk == 0 && index < filename_length -1 ) {
		printf ("asterisk: %d index: %d filename_length: %d\r\n", asterisk, index, filename_length );
		printf( "file_type returned -1 because last part doesn't suit file type: %s.\r\n",  type );
		return -1;
	}

//	printf( "file_type returned 1.\r\n" );

	return 1;
}

//
//
//
//
//
//
char** split ( char* str_source, char c, int* number ) {

//	printf( "sprit strated.\r\n" );
	int length = array_count (str_source);
	char* a = "\0";
//	char* aa = "\0\0";
	char aa[] = { '\0', '\0' };
	char** b;
	int index = 0;

	b = (char**)malloc ( sizeof(char*) );

	aa[0] ='\0';

	for ( int i=0; i< length; i++) {
	
		aa[0] = str_source[i];
		// printf("i : %d %s length %d\r\n", i, aa, length );

		if ( str_source[i] == c ) {
			b = (char**)realloc ( b, sizeof(char**) * (index + 1) );
			a = m_concat( a, "\0" );

			b[index]= a;
			// printf ( "b : %d : %s a : %s\r\n", index, b[index], a );

			// initialize
			a = m_concat ( "", "\0" );
			// printf ( "initialize a: %s \r\n", a );
			index++;
			b[index] = "";
		} else {
			a = m_concat( a, aa);
			// printf ( "i: %d a : %s\r\n", i, a );
		}
	}

	// printf ( "index: %d \r\n", index );
	b[index] = a;


//	b = (char**)realloc ( b, sizeof(char**) * index );
	*number = index + 1;

	for( int i=0; i<=index; i++ ) {
		put_memories( b[i] );
//		//a = m_concat( b[i], "\0" );
//		printf ( "index:%4d |%s|\r\n", i, b[i]);
	}
//	printf( "sprit ended.\r\n" );

	return b;
}

//
//
//
//
//
char* substring( char* c_a, int start, int length )
{
	char* l_buffer = (char*) malloc ( sizeof(char) * length );

	for ( int i=0; i <length; i++ ) {
		*( l_buffer + i ) = c_a[ start + i ];
	}

	*( l_buffer + length ) = '\0';

	return l_buffer;
}

//
//
//
//
//
int m_last_with_001 ( char* c_str, char* c_ref ) {

	int index = 0;

	int unmatch = 0;
	int ref_length = array_count( c_ref );
	int length = array_count( c_str );

	int last_index = 0;
	printf("c_str %s c_ref %s\r\n", c_str, c_ref);

	for ( int i=length -1; i >= 0; i-- ) {
		last_index = i;

		for ( int j=ref_length -1; j >= 0; j-- ) {
			printf("m_contains:|%3d|%3d|%c|%c| %d\r\n", c_str[i] , c_ref[j] , c_str[i] , c_ref[j], j);
			if ( c_str[i] != c_ref[ j ] ) {
				unmatch = 1;
				break;
			}

			i--;
			index = j;
		}

		i = last_index;

		if ( unmatch == 0 ) {
			return index + i;
		}
		else unmatch = 0;
	}

	return -1;
}

//
//
//
//
//
int m_last_with ( char* c_str, char* c_ref ) {

	int index = 0;

	int unmatch = 0;
	int ref_length = array_count( c_ref );
	int length = array_count( c_str );

	int last_index = 0;
	// printf("c_str %s c_ref %s\r\n", c_str, c_ref);

	for ( int i=length -1; i >= 0; i-- ) {
		last_index = i;

		for ( int j=ref_length -1; j >= 0; j-- ) {
			// printf("m_contains:|%3d|%3d|%c|%c| %d\r\n", c_str[i] , c_ref[j] , c_str[i] , c_ref[j], j);
			if ( c_str[i] != c_ref[ j ] ) {
				unmatch = 1;
				break;
			}

			i--;
			index = j;
		}

		i = last_index;

		if ( unmatch == 0 ) {
			return index + i;
		}
		else unmatch = 0;
	}

	return -1;
}

//
//
//
//
//
/* int m_contains ( char* c_str, char* c_ref ) {

	int unmatch = 0;
	int ref_length = array_count( c_ref );
	int length = array_count( c_str );
	for ( int i=length -1; i >= 0; i-- ) {
		for ( int j=ref_length -1; j >= 0; j-- ) {
			// sprintf("m_contains:|%d|%d|\r\n", c_str[i] , c_ref[j] );
			if ( c_str[i] != c_ref[ j ] ) {
				unmatch = 1;
			}
		}
		if ( unmatch == 0 ) return 1;
		else unmatch = 0;
	}

	return 0;
} */

//
//
//
//
//
/* char* m_trim( char* c_str ) {

	char* result = "\0";
	char* return_result = "\0";
	result = front_trim ( c_str );
	// return_result = back_trim ( result );

	return result;

	//free( result );
	//return return_result;
} */

//
//
//
//
//
/* char* back_trim( char* c_str ) {

	int skip = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	for ( int i=length -1; i >= 0; i-- ) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			if ( skip == 0 ) break; // means continue until it finds another letter except space.
			if ( skip == 1 ) return result;
			break;
		default:
			skip = 1;
			dummy[0] = c;
			result = m_concat ( (char *)dummy, (char *)result );
			break;
		}
	}

	return result;
}*/

//
//
//
//
//
/*char* front_trim( char* c_str ) {

	int skip = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	for ( int i=0; i< length; i++) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			if ( skip == 0 ) break; // means continue until it finds another letter except space.
			if ( skip == 1 ) {
				//printf( "result |%s|", result );
				//exit( -1 );
				return result;
			}
			break;
		default:
			skip = 1;
			dummy[0] = c;
			result = m_concat ( (char *)result, (char *)dummy );
			break;
		}
	}

	return result;
}*/

//
//
//
//
//
int alphabet ( char c ) {

	if ( c>= 'A' && c<='z' ) return 1;

	return -1;
}

//
//
//
//
//
int number ( char c ) {

	if ( c>= '0' && c<='9' ) return 1;

	return -1;
}



/*int main ( int argc, char *argv[] ) {

	FILE *fp;
	fp = fopen ( argv[1], "rb" );
	char dummy[1];

	m_size = 256;
	token = (char * )string_allocation ( m_size );


	for( int i=0; i<10; i++ ) {

		char c = fread ( dummy, 1, 1, fp);
		token = put_token ( dummy[0] );
//		printf( "%d %d\n", *token, token);
//		printf ("%s dummy=%s token[%d]=%d\n", dummy, token, i, token[i] );
	}

	return 0;
}
*/


//
//
//
//
//
int line_end_win ( char* c ) {

	char dummy[2];

	dummy[0] = c[0];
	dummy[1] = c[1];

	// we must cast array tp (char *)
	if ( m_compare( (char *)dummy, (char *)"\r\n"   ) == 1 ) return 1;

	return 0;
}

//
//
//
//
//
int line_end ( char c ) {

	if ( c == '\n' ) return 1;

	return 0;
}

//
//
//
//
//
int m_fread ( char* dummy, int a, FILE *fp) {
	fread ( dummy, 1, a, fp);
	char c = dummy[0];

	//printf("m_fread: %s c_num: %d line: %d raw: %d\n", dummy, c, m_line, m_raw );
	m_counter ( c );

	return 1;
}

//
//
//
//
//
int initialize_parse () {
	m_size = 256;
	token = (char * )string_allocation ( m_size );

	m_raw = 0;
	m_line = 0;

	return 0;
}

//
//
//
//
//
void clear_token() {

	free(token);
	m_cnt_tkn = 0;

	initialize_parse ();
}

//
//
//
//
//
char* put_token (char c) {
	char *dummy;
	// 20181231 commented out.
	// 20280420 problem solution temporarily.
	// 1. token[0] is line end.
	// 2. at least analyzer is trying to analyze program keyword ( means not skkipping ).
//	if ( m_cnt_tkn == 0 && c == '\n' ) {
//		printf( "m_mode: %d token[0] is line end. filename %s: line %d raw %d", m_mode, m_filename, m_line, m_raw );
//		exit ( -1 );
//	}

	m_cnt_tkn++;
	//m_counter ( c );

	if ( m_size <= m_cnt_tkn ) {
		m_size *= 2;
		dummy = (char * )string_allocation ( m_size );
		for ( int i=0; i< m_size/2; i++) {
			*( dummy + i ) = *( token + i );
		}
		free(token);
		token = dummy;
	}

	*( token + m_cnt_tkn - 1) = c;
	*( token + m_cnt_tkn ) = '\0';

/*
	for( int i=0; i<m_count; i++ ) {
		printf ( "c %d i %d token[%d]=%d token: %s\n", c, i, i, token[ i ], token );
	}
*/

//	printf ( "c %d m_count %d token[%d]=%d token: %s\n", c, m_count - 1, m_count - 1, token[ m_count - 1 ], token );
	return token;
}

//
//
//
//
//
void m_counter ( char c ) {

	switch ( c ) {
	case '\n':
		m_line++;
		m_raw = 0;
		break;
	}

	m_raw++;
	m_count++;
}

/*
char* string_read ( FILE *fp, int size ) {

	if ( size > m_size ) {
		m_size = size;
	}

	token = (char * )string_allocation ( m_size );
	//result = fread ( buffer, 1, size, fp );
}
*/

//
//
//
//
//
char* string_allocation (int size) {
	char * buffer;

	buffer = (char*) malloc ( sizeof(char) * size );

	return buffer;
}

