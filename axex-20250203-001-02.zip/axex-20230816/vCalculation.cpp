#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h> // ADD: 20200125

#include "array_counter.h"	// ADD: 20200125
#include "sender.h"			// ADD: 20200125
#include "Print.h"			// ADD: 20200125

#include "memories.h"			// ADD: 20200125

#include "log_001.h"

#include "vPoint.h"
#include "vLine.h"

#include "vCalculation.h"


//1: subtract o
//2: cross
//3: add      o
//4: dot      o

int dummy_vPoint_max = 0;
int dummy_vPoint_index = 0;

int dummy_vLine_max = 0;
int dummy_vLine_index = 0;

int debug_c = 0;

// x the below: 001 which is moved to the hearder.
//static vPoint** dummy_vPoint = nullptr;
//static vPoint* dummy_p = nullptr;
//static vPoint* dummy_pp = nullptr;


int once_memorized = 0;

void put_memories( vPoint* dummy_vPoint );
void put_memories_vLine( vLine* dummy_vLine );
vPoint* memorizevPoint( float a, float b, float c );
vLine* memorizevLine( vPoint* a, vPoint* b );

void print_point_memories ();
void print_memories_vLine ();

void put_points( vPoint* p );
void garbage_memories () ;
void free_point ( vPoint* p ) ;
void free_point_001 ( vPoint* p ) ;

void Put_Memories_vPoint ( vPoint* p_006 );
void Put_Memories_vLine ( vLine* l_003 );

// 20250130
vPoint** reallocation_array_vPoint ( vPoint** mem, int width, int width_more );


void Put_Memories_vPoint ( vPoint* p_006 ) {
	put_memories (p_006);
}

void Put_Memories_vLine ( vLine* l_003 ) {
	put_memories_vLine ( l_003 );
}

// 20210321
vLine* memorizevLine( vPoint* a, vPoint* b ) {
	if ( debug_c == 1 ) printf("memorizevLine( vPoint* a, vPoint* b ) starts.");
	if ( debug_c == 1 ) printf("a , b = |%p||%p|", a, b );
	a->print();
	b->print();
	dummy_vLine_p = new vLine ( a, b );
	if ( debug_c == 1 ) printf("memorized line |%p| = ", dummy_vLine_p );
	dummy_vLine_p->print();

	put_memories_vLine ( (vLine*)dummy_vLine_p );

	return dummy_vLine_p;
}


//
//
//
//
//
void free_point ( vPoint* p ) {
	if ( debug_c == 1 ) printf("free_point starts. |%p| dummy_vPoint_index|%d|\r\n", p, dummy_vPoint_index);

	dummy_vPoint_index--;
	if ( dummy_vPoint[dummy_vPoint_index] == nullptr ) {
		dummy_vPoint[dummy_vPoint_index] = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	}

	for( int i=dummy_vPoint_index; i>=0; i-- ) {
		if ( dummy_vPoint[i] == p ) {
			// flip
			vPoint* w_p = dummy_vPoint[dummy_vPoint_index];
			dummy_vPoint[i] = dummy_vPoint[dummy_vPoint_index];
			dummy_vPoint[dummy_vPoint_index] = w_p;
		}
	}

	if ( dummy_vPoint_index < 0 ) dummy_vPoint_index = 0;

	if ( debug_c == 1 ) printf("free_point ends. |%p| dummy_vPoint_index{%d}\r\n", p, dummy_vPoint_index);
	// exit(-1);
}

//
//
//
//
//
void free_point_001 ( vPoint* p ) {
	if ( debug_c == 1 ) printf("point |%p|\r\n", p);
	delete( p );
	if ( debug_c == 1 ) printf("delete |%p|\r\n", p);
	// debug 20200213
	//if ( p == nullptr ) exit(-1);
	//exit(-1);
	vPoint *pp = new vPoint();
	if ( debug_c == 1 ) printf("point |%p|\r\n", pp);
	delete(pp);
	if ( debug_c == 1 ) printf("point |%p|\r\n", pp);
	// exit(-1);

	if ( once_memorized ) delete(dummy_pp);

	if ( dummy_pp == nullptr && once_memorized ) {
		if ( debug_c == 1 ) printf("dummy_pp=%p\r\n", dummy_pp);
		exit(-1);
	}

	dummy_pp = new vPoint();
	once_memorized = 1;
}

// 
// int dummy_vPoint_max = 0;
// int dummy_vPoint_index = 0;
// vPoint** dummy_vPoint = nullptr;
// vPoint* dummy_p = nullptr;
// 
void put_points( vPoint* p ) {

	if ( dummy_vPoint_index >= dummy_vPoint_max ) {
		if ( dummy_vPoint_index == 0 ) dummy_vPoint_max = 8; // initialization
		dummy_vPoint_index *= 2;
		dummy_vPoint = (vPoint**) realloc ( dummy_vPoint, sizeof(vPoint*) * dummy_vPoint_max );
		if ( debug_c == 1 ) printf("dummy_vPoint_max = %d \r\n", dummy_vPoint_max );
	}

	dummy_vPoint[ dummy_vPoint_index ] = (vPoint*)p;
	dummy_vPoint_index++;
}


//	if ( debug_c == 1 ) printf
//
//
float vCalculation::dot ( vPoint p1, vPoint p2) {
	float dot;

	this->dot( p1.x,p1.y,p1.z, p2.x,p2.y,p2.z, &dot );

	return dot;
}


//
//
//
//
//
void vCalculation::dot ( float x1, float y1, float z1, float x2, float y2, float z2, float* dot ) {

	*dot = x1*x2 + y1*y2 + z1*z2;
}

//
//
//
//
//
vPoint* vCalculation::add ( vPoint* p1, vPoint* p2) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::add starts\r\n");
	vPoint* p3 = memorizevPoint( 0.0f, 0.0f, 0.0f);
	add( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );

	// comment out at 20191217
	// put_memories( p3 );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::add returns |%p| \r\n", p3);
	return p3;
}

//
//
//
//
//
void vCalculation::add ( vPoint* p1, vPoint* p2, vPoint* p3) {
	add( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
}


//
//
//
//
//
void vCalculation::cross ( vPoint* p1, vPoint* p2, vPoint* p3) {
	cross( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
}

//
//
//
//
//
vPoint* vCalculation::cross ( vPoint p1, vPoint p2) {

	vPoint* p3 = memorizevPoint( 0.0f, 0.0f, 0.0f );

	cross( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3->x), &(p3->y), &(p3->z) );

	return p3;
}

//
//
//
vPoint* vCalculation::cross ( vPoint* p1, vPoint* p2) {

	vPoint* p3 = memorizevPoint( 0.0f, 0.0f, 0.0f );

	cross( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );

	return p3;
}

// 0, 0, 1  x  1, 0, 0 = 0, -1, 0     -> -z1*x2
// 1, 0, 0  x  0, 0, 1 = 0,  1, 0     ->  x1*z2

// 0, 1, 0  x  1, 0, 0 = 0, 0,  1
// 1, 0, 0  x  0, 1, 0 = 0, 0, -1
//
void vCalculation::cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = z1*y2 - y1*z2;
	*y3 = x1*z2 - z1*x2;
	*z3 = y1*x2 - x1*y2;

}

//
//
//
//
int vCalculation::subtract ( vPoint* p1, vPoint* p2, vPoint *p3) {
	float x, y, z;

	if ( debug == 1 ) if ( debug_c == 1 ) printf("int vCalculation::subtract starts p1|%p| p2|%p| p3|%p|\r\n", p1, p2, p3);

	if ( debug == 1 ) if ( debug_c == 1 ) printf ("p1->x %f\r\n", p1->x );

	if( p3 == nullptr ) {
		if ( debug == 1 ) if ( debug_c == 1 ) printf("001: int vCalculation::subtract ends and set |%p| return -1.\r\n", p3);
		return -1;
	}

	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(x), &(y), &(z) );

	p3->setPoint( x, y, z );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("int vCalculation::subtract ends and set |%p| return 0.\r\n", p3);

	return 0;
}

//
//
//
//
vPoint* vCalculation::subtract ( vPoint* p1, vPoint* p2) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint* vCalculation::subtract starts p1|%p| p2|%p|\r\n", p1, p2);

	float x, y, z;

	vPoint* result = nullptr;
	result = (vPoint*) memorizevPoint( 0.0f, 0.0f, 1.0f);
	if ( debug == 1 ) if ( debug_c == 1 ) printf("result|%p|\r\n", result);
	result->print();

	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(x), &(y), &(z) );

// commented out 20200410
//	put_memories ( (vPoint*)result );

// Set Result
//	result->x = x;
//	result->y = y;
//	result->z = z;

	result->setPoint( x, y, z );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint* vCalculation::subtract ends and returns |%p|\r\n", result);
	return result;
}

//
vPoint* vCalculation::subtract_001 ( vPoint* p1, vPoint* p2) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint* vCalculation::subtract starts p1|%p| p2|%p|\r\n", p1, p2);

	float x, y, z;

	vPoint* result = nullptr;
	result = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f);

	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(x), &(y), &(z) );

// commented out 20200410
//	put_memories ( (vPoint*)result );

// Set Result
//	result->x = x;
//	result->y = y;
//	result->z = z;
	result->setPoint( x, y, z );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint* vCalculation::subtract ends and returns |%p|\r\n", result);
	return result;
}


//
//
//
//
//
void vCalculation::Print_Point_Memories () {

	print_point_memories ();
}

// Qualfied: we could use %p on if ( debug_c == 1 ) printf.
//
//
//
//
void print_point_memories () {

	vPoint* p = nullptr;

	if ( debug_c == 1 ) printf("void print_point_memories () starts.\r\n");

	if ( debug_c == 1 ) printf("dummy_vPoint_index %d\r\n", dummy_vPoint_index);
	for( int i=0; i<dummy_vPoint_index; i++ ) {
		p = dummy_vPoint[ i ];
		if ( debug_c == 1 ) printf ("i: %3d p: %p\r\n", i, p );
	}

	if ( debug_c == 1 ) printf("void print_point_memories () ends.\r\n");
}

// Recreated: 20200218
// Recreated: 20200414
// Modified: 20200505
//
//
vPoint* memorizevPoint( float a, float b, float c ) {
	if ( debug_c == 1 ) printf("memorizevPoint starts: %f %f %f dummy_vPoint_index %d dummy_vPoint_max %d\r\n", a, b, c, dummy_vPoint_index, dummy_vPoint_max);

	// Mallocation: initialize: 20200414
	if ( dummy_vPoint_max == 0 ) {
		if ( debug_c == 1 ) printf("dummy_vPoint_max = %d allocation starts.\r\n", dummy_vPoint_max);
		dummy_vPoint_max = 8;
		dummy_vPoint_index = 0;
		dummy_vPoint = (vPoint**) malloc ( sizeof(vPoint*) * dummy_vPoint_max );
		for (int index = 0; index < dummy_vPoint_max; index++)
			dummy_vPoint[index] = nullptr;
	//		dummy_vPoint[index] = new vPoint(0.0f, 0.0f, 0.0f);
		if ( debug_c == 1 ) printf("dummy_vPoint_max = %d allocation ends.\r\n", dummy_vPoint_max);
	}

	if ( debug_c == 1 ) printf("dummy_vPoint_index %d dummy_vPoint_max %d\r\n", dummy_vPoint_index, dummy_vPoint_max );

	// Rallocation:
	if (dummy_vPoint_index >= dummy_vPoint_max - 1) {
		if ( debug_c == 1 ) printf("Reallocation array only starts.\r\n");
		if ( debug_c == 1 ) printf("dummy_vPoint_max %d we found.\r\n", dummy_vPoint_max);
		dummy_vPoint_max *= 2;
		dummy_vPoint = (vPoint**) reallocation_array_vPoint ( dummy_vPoint, dummy_vPoint_max/2, dummy_vPoint_max);
		if ( debug_c == 1 ) printf("dummy_vPoint_max %d dummy_vPoint|%p| reallocated.\r\n", dummy_vPoint_max, dummy_vPoint);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( debug_c == 1 ) printf("Set nullptr from %d to %d. NULL is %p\r\n", dummy_vPoint_index, dummy_vPoint_max, NULL);
		if ( dummy_vPoint == NULL )	{
			if ( debug_c == 1 ) printf( "dummy_vPoint is NULL, so, exit.\r\n");
			exit(-1);
			exit(-1);
			exit(-1);
			exit(-1);
			exit(-1);
			exit(-1);
		}
		for (int index = dummy_vPoint_index; index < dummy_vPoint_max; index++) // Recognistion: 20200508
			dummy_vPoint[index] = nullptr;
		if ( debug_c == 1 ) printf("Reallocation array only ends.\r\n");
	}

	if ( debug_c == 1 ) printf("dummy_vPoint_index %d dummy_vPoint_max %d\r\n", dummy_vPoint_index, dummy_vPoint_max );

	if ( dummy_vPoint_index < dummy_vPoint_max ) {
		dummy_p = dummy_vPoint[dummy_vPoint_index];
		if ( dummy_p != nullptr ) {
			dummy_vPoint_index++;
			if ( debug_c == 1 ) printf("aReuse: %d/%d dummy_vPoint=%p\r\n", dummy_vPoint_index -1, dummy_vPoint_max, dummy_vPoint[dummy_vPoint_index - 1]);
			//exit(-1);
			dummy_vPoint[dummy_vPoint_index - 1]->setPoint( a, b, c);
			return dummy_vPoint[dummy_vPoint_index - 1];
		} else {
			// nullptr
			dummy_vPoint[dummy_vPoint_index] = new vPoint( a, b, c );
			dummy_vPoint_index++;
			if ( debug_c == 1 ) printf("aNew: %d/%d dummy_vPoint=%p\r\n", dummy_vPoint_index -1, dummy_vPoint_max, dummy_vPoint[dummy_vPoint_index - 1]);
			return dummy_vPoint[dummy_vPoint_index - 1];
		}
	} else {
			if ( debug_c == 1 ) printf("dummy_vPoint_index %d dummy_vPoint_max %d\r\n", dummy_vPoint_index, dummy_vPoint_max);
	}

	if ( debug_c == 1 ) printf("memorizevPoint ends: %f %f %f dummy_vPoint_index %d dummy_vPoint_max %d\r\n", a, b, c, dummy_vPoint_index, dummy_vPoint_max);
	return nullptr;
}


// 20250130
vPoint** reallocation_array_vPoint ( vPoint** mem, int width, int width_more ) {
	vPoint** m_vPoint;
	int i, a, memsize;

	if ( debug_c == 1 ) printf("vPoint** reallocation_array_vPoint ( vPoint** mem, int width, int width_more ) starts.\r\n");
	if ( debug_c == 1 ) printf("sizeof(int*) = %d\r\n", sizeof(int*));
	if ( debug_c == 1 ) printf("sizeof(double*) = %d\r\n", sizeof(double*));

	memsize = sizeof(vPoint*);

	a = wait_sharp_short_time();
	if ( debug_c == 1 ) printf(" 1: m_vPoint|%p| size %d mem|%p| from %d to %d.\r\n", m_vPoint, memsize, mem, width, width_more );

	m_vPoint = (vPoint**) malloc ( memsize * width_more );
	a = wait_sharp_short_time();
	if ( debug_c == 1 ) printf(" 2: m_vPoint|%p| size %d mem|%p| from %d to %d.\r\n", m_vPoint, memsize, mem, width, width_more );

	if ( m_vPoint == NULL ) {
		if ( debug_c == 1 ) printf("m_vPoint is NULL.\r\n");
		exit(-1);
	}

	a = wait_sharp_short_time();
	if ( debug_c == 1 ) printf(" 3: m_vPoint|%p| size %d mem|%p| from %d to %d.\r\n", m_vPoint, memsize, mem, width, width_more );

	for ( i = 0; i<width; i++ ) {
		m_vPoint[i] = (vPoint*) mem[i];
	}

	a = wait_sharp_short_time();
	if ( debug_c == 1 ) printf(" 4: m_vPoint|%p| size %d mem|%p| from %d to %d.\r\n", m_vPoint, memsize, mem, width, width_more );

	for ( i = width; i<width_more; i++ ) {
		m_vPoint[i] = (vPoint*) NULL;
	}

	a = wait_sharp_short_time();
	if ( debug_c == 1 ) printf(" 5: m_vPoint|%p| size %d mem|%p| from %d to %d.\r\n", m_vPoint, memsize, mem, width, width_more );

	free(mem);
	mem = NULL;
	a = wait_sharp_short_time();
	if ( debug_c == 1 ) printf(" 6: m_vPoint|%p| size %d mem|%p| from %d to %d.\r\n", m_vPoint, memsize, mem, width, width_more );

	if ( debug_c == 1 ) printf("vPoint** reallocation_array_vPoint ( vPoint** mem, int width, int width_more ) ends.\r\n");
	return m_vPoint;
}

void print_memories_vLine ( ) {
	if ( debug_c == 1 ) printf("print_memories_vLine starts. dummy_vLine|%p|\r\n", dummy_vLine);

	if ( debug_c == 1 ) printf("dummy_vLine_index %d / dummy_vLine_max %d\r\n", dummy_vLine_index, dummy_vLine_max );

	for ( int i =0; i<dummy_vLine_index; i++ ) {
		if ( debug_c == 1 ) printf("dummy_vLine[%d] = |%p| / %d\r\n", i, dummy_vLine[i], dummy_vLine_max);
		if ( dummy_vLine[i] != nullptr )
			dummy_vLine[i]->print();
	}
	if ( debug_c == 1 ) printf("print_memories_vLine ends.\r\n");
}


void put_memories_vLine ( vLine* result ) {
	if ( dummy_vLine_index == 0 ) {
		dummy_vLine_max = 8;
		dummy_vLine = (vLine**) malloc ( sizeof(vLine*) * dummy_vLine_max );
	}

	if ( dummy_vLine_index >= dummy_vLine_max - 1 ) {
		dummy_vLine_max = dummy_vLine_max * 2;
		dummy_vLine = (vLine**) realloc ( dummy_vLine, sizeof(vLine*) * dummy_vLine_max );
	}

	dummy_vLine[ dummy_vLine_index ] = result;
	dummy_vLine_index++;
}

//
//
//
//
void put_memories ( vPoint* result ) {

	if ( debug_c == 1 ) printf("Do not use: put_memories\r\n");
	exit(-1);


	if ( dummy_vPoint_index == 0 ) {
		dummy_vPoint_max = 8;
		dummy_vPoint = (vPoint**) malloc ( sizeof(vPoint*) * dummy_vPoint_max );
	}

	if ( dummy_vPoint_index >= dummy_vPoint_max - 1 ) {
		dummy_vPoint_max = dummy_vPoint_max * 2;
		dummy_vPoint = (vPoint**) realloc ( dummy_vPoint, sizeof(vPoint*) * dummy_vPoint_max );
	}

	dummy_vPoint[ dummy_vPoint_index ] = result;
	dummy_vPoint_index++;
}

//
//
//
//
//
void garbage_memories () {
	for( int i=0; i<dummy_vPoint_index; i++ ) {
		if ( debug_c == 1 ) printf("|%3d|%p|\r\n", i, dummy_vPoint[i] );
		if ( dummy_vPoint[i] == nullptr ) {
			if ( debug_c == 1 ) printf("we found freed memory.\r\n");
			exit(-1);
		}
	}

	// 20200126 temporalily we quit.
	if ( dummy_vPoint_index > 0 ) {
		if ( debug_c == 1 ) printf("dummy_vPoint_index=|%3d|\r\n", dummy_vPoint_index );
		//exit(-1);
	}
}

//
//
//
//
vPoint* vCalculation::subtract ( vPoint p1, vPoint p2) {
	vPoint *result;
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::subtract:\r\n" );
//	vPoint* a_result = nullptr;
//	result = (vPoint*) memorizevPoint( 0.0f, 0.0f, 0.0f);
//	subtract( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z) );

//	if ( debug == 1 ) if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::subtract ends: \r\n" );
//	return *result;

	result = memorizevPoint ( 0.0f, 0.0f, 0.0f );
	subtract(p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z));
//	return *(memorizevPoint( 0.0f, 0.0f, 0.0f));

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::subtract ends: %p\r\n", result );
	return result;
}

//
void vCalculation::subtract ( vPoint p1, vPoint p2, vPoint *result) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::subtract:\r\n" );

	subtract( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z));

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::subtract ends: %p\r\n", result );
}


//
//
//
//
void vCalculation::subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::subtract:111 starts.\r\n");
	if ( debug == 1 ) if ( debug_c == 1 ) printf("|%p|%p|%p| \r\n", x3,  y3, z3 );
	if ( debug == 1 ) if ( debug_c == 1 ) printf("|%f|%f|%f|%f|%f|%f| \r\n", x1,  y1, z1, x2, y2, z2 );
	*x3 = x1 - x2;
	*y3 = y1 - y2;
	*z3 = z1 - z2;
	if ( debug == 1 ) if ( debug_c == 1 ) printf("|%p|%p|%p| \r\n", x3,  y3, z3 );
	if ( debug == 1 ) if ( debug_c == 1 ) printf("|%p|=%f |%p|=%f |%p|=%f \r\n", x3, *x3,  y3, *y3, z3, *z3 );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::subtract:111 ends.\r\n");
}

//
//
//
//
//
void vCalculation::add ( vPoint p1, vPoint p2, vPoint* p3 ) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::add: starts. |%p| |%p| |%p|\r\n", &p1, &p2, p3);

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3->x), &(p3->y), &(p3->z) );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::add: sets |%p|.\r\n", p3);
}

//
//
//
//
//
vPoint* vCalculation::add ( vPoint p1, vPoint p2) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::add: starts. |%p| |%p|\r\n", &p1, &p2);

	vPoint* result = memorizevPoint( 0.0f, 0.0f, 0.0f);

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(result->x), &(result->y), &(result->z) );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint vCalculation::add: returns |%p|.\r\n", result);
	return result;
}

//
//
//
//
//
void vCalculation::add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = x2 + x1;
	*y3 = y2 + y1;
	*z3 = z2 + z1;

}

// expand
// scale
// strech
// enlarge
// magnification
vPoint* vCalculation::scalize ( vPoint* p1, float w_scale) {

//	vPoint* result = (vPoint*) malloc (sizeof(vPoint) * 1 );
	vPoint* result = memorizevPoint( 0.0f, 0.0f, 0.0f);

//	scale ( p1->x, p1->y, p1->z, w_scale, &(p1->x), &(p1->y), &(p1->z) );
	scale(p1->x, p1->y, p1->z, w_scale, &(result->x), &(result->y), &(result->z));

//	put_memories ( result );

	return result;
}

// expand
// scale
// strech
// enlarge
// magnification
int vCalculation::scalize ( vPoint* p1, float w_scale, vPoint* result ) {
	if ( result == nullptr ) {
		if ( debug == 1 ) if ( debug_c == 1 ) printf("012: result|%p|\r\n", result);
		exit(-1);
	}

	scale(p1->x, p1->y, p1->z, w_scale, &(result->x), &(result->y), &(result->z));

	return 0;
}

// expand
// scale
// strech
// enlarge
// magnification
int vCalculation::scalize ( vPoint p1, float w_scale, vPoint* result ) {
	if ( result == nullptr ) {
		if ( debug == 1 ) if ( debug_c == 1 ) printf("012: result|%p|\r\n", result);
		exit(-1);
	}

	scale(p1.x, p1.y, p1.z, w_scale, &(result->x), &(result->y), &(result->z));

	return 0;
}

//
//
//
//
//
vPoint* vCalculation::scale ( vPoint* p1, float w_scale, vPoint* result ) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint* vCalculation::scale |%p| |%f| |%p|\r\n",  p1, w_scale, result);

	scale ( p1->x, p1->y, p1->z, w_scale, &(result->x), &(result->y), &(result->z) );

//	put_memories ( result );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vPoint* vCalculation::scale |%p|\r\n", result);
	return result;
}


//
//
//
//
//
//
void vCalculation::scale ( vPoint* p1, float w_scale ) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::scale starts.\r\n");

	p1->x *= w_scale;
	p1->y *= w_scale;
	p1->z *= w_scale;

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::scale ends.\r\n");
}

//
//
//
//
//
vPoint* vCalculation::scale ( vPoint p1, float w_scale ) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::scale starts. |%p| %f\r\n", &p1, w_scale);

	vPoint* result = memorizevPoint( 0.0f, 0.0f, 0.0f );
	

	scale ( p1.x, p1.y, p1.z, w_scale, &(result->x), &(result->y), &(result->z) );

	if ( debug == 1 ) if ( debug_c == 1 ) printf("vCalculation::scale ends. return |%p|\r\n", &result);
	return result;
}

//
//
//
//
void vCalculation::scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3) {

	*x3 = scale * x1;
	*y3 = scale * y1;
	*z3 = scale * z1;

}

void vCalculation::normal ( vPoint* p1, vPoint* p2 ) {
	this->normal((p1->x) ,(p1->y) ,(p1->z) ,&(p2->x), &(p2->y), &(p2->z) );
}

//
//
//
//
//
void vCalculation::normal ( vPoint* p1 ) {

	double scale = p1->x*p1->x + p1->y*p1->y + p1->z*p1->z;
	scale = sqrt( scale );

	p1->x = (( double ) p1->x) / scale;
	p1->y = (( double ) p1->y) / scale;
	p1->z = (( double ) p1->z) / scale;
}

//
//
//
//
vPoint* vCalculation::normal ( vPoint p1 ) {

	vPoint* p2 = memorizevPoint( 0.0f, 0.0f, 0.0f );
	// double scal = 0.0;
	// scal = normal( p1.x, p1.y, p1.z, &p2.x, &p2.y, &p2.z );

	normal( p1.x, p1.y, p1.z, &(p2->x), &(p2->y), &(p2->z) );

	return p2;
}

//
//
//
//
double vCalculation::normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 ) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	double x3 = (( double ) x1) / scale;
	double y3 = (( double ) y1) / scale;
	double z3 = (( double ) z1) / scale;

	*x2 = x3;
	*y2 = y3;
	*z2 = z3;

	return scale;
}

//
//
//
//
double vCalculation::length ( vPoint lp ) {

	return length ( lp.x, lp.y, lp.z );
}

//
//
//
//
double vCalculation::length ( vPoint* lp ) {

	return length ( lp->x, lp->y, lp->z );
}

//
//
//
//
double vCalculation::length ( float x1, float y1, float z1) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	return scale;
}

//
//
//
//
//
vLine* vCalculation::put_line( vLine* be_set, vLine* l1 ) {
	be_set = l1;
	// the below error 
	// l1->p1->print();
	// the below error 
	// be_set->p1->print();

	return l1;
}

//
//
// copy all points and would liket to refer to points at 20190213
//
vLine** vCalculation::Lines_from_Mesh ( vPoint* points, int** numbering, int num_patches, int base_num_patches) {
	vLine** p_result = nullptr;
	vLine** result = nullptr;
	//20180214
	int c = num_patches;
	int d_number = 0;
	vPoint* end_to_start = nullptr;

	if ( debug == 1 ) if ( debug_c == 1 ) printf("num_patches %d base_num_patches %d\r\n", num_patches, base_num_patches);

	for( int i=0; i<c; i++ ) {
		int* num_p = *( numbering + i );
		//20180214
//		int d = sizeof( num_p ) / sizeof( int* );
		int d = base_num_patches;

		p_result = ( vLine** ) malloc ( sizeof(vLine**) * d );
		d_number += d;
		result = ( vLine** ) realloc ( result, sizeof( vLine** ) * d_number );

		for( int j=0; j<d; j++ ) {
			int number = *( num_p + j );
			vLine* p_line = *( p_result + j );
			put_point( p_line->p1, points + number );

			if ( j == 0 ) {
				end_to_start = points + number;
			} else {
				put_point( p_line->p2, points + number - 1 );
			}
		}

		vLine* last = *( p_result + d - 1 );
		put_point( last->p2, end_to_start );

		for( int j= d_number - d; j<d_number; j++ ) {
			put_line( *(result + j), *(p_result + j - d_number + d) );
		}
	}

	Print_Lines ( result, d_number );
	if ( debug == 1 ) if ( debug_c == 1 ) printf("end of Lines_from_Mesh d_number %d\r\n", d_number);

	// cast vPoint** -> vPoint*
//	put_memories( (vPoint*) result );

	return result;
}

//
//
//
//
//
void vCalculation::Print_Lines ( vLine** array, int num ) {

	for ( int i=0; i<num; i++ ) {
		vLine* line = *( array + i );
		line->print();
	}

}

//
//
//
//
//
void vCalculation::put_point( vPoint* lp1, vPoint* points_number ) {
	if ( debug == 1 ) if ( debug_c == 1 ) printf( "start of put_point\r\n" );
	points_number->print();
	lp1 = points_number;
	lp1->print();
	if ( debug == 1 ) if ( debug_c == 1 ) printf( "end of put_point\r\n" );
	// exit(-1);
}


