#ifndef _VCALCULATION_
#define _VCALCULATION_

extern void put_memories( vPoint* dummy_vPoint );

class vCalculation {

public:
	vPoint cross ( vPoint p1, vPoint p2);
	vPoint normal ( vPoint p1 );
	vPoint add ( vPoint p1, vPoint p2);
	vPoint subtract ( vPoint p1, vPoint p2);
	vPoint scale ( vPoint p1, float scale );
	double length ( vPoint lp );
	double length ( float x1, float y1, float z1);
	float dot ( vPoint p1, vPoint p2) ;
	// vLine* Get_Lines ( vPoint* points, int** numbering) ;
	// vLine* Lines_from_Mesh ( vPoint* points, int** numbering) ;
	vLine** Lines_from_Mesh ( vPoint* points, int** numbering, int num_patches, int base_num_patches) ;
	vPoint* scale ( vPoint* p1, float w_scale ) ;
	void add ( vPoint p1, vPoint p2, vPoint* p3 ) ;
	void add ( vPoint* p1, vPoint* p2, vPoint* p3) ;
	void cross ( vPoint* p1, vPoint* p2, vPoint* p3) ;
	vPoint* subtract ( vPoint* p1, vPoint* p2) ;
	double length ( vPoint* lp );
	vPoint* add ( vPoint* p1, vPoint* p2) ;

private:
	void cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	double normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 );
	void subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3);
	void scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3);
	void dot ( float x1, float y1, float z1, float x2, float y2, float z2, float* dot ) ;
	vLine* put_line( vLine* be_set, vLine* l1) ;
	vLine* Print_Lines ( vLine** array, int num ) ;
	void put_point( vPoint* lp1, vPoint* points_number ) ;




};

#endif
