#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vCalculation.h"
#include "vIntersection_001.h"

vIntersection_001::vIntersection_001 () {
}


vPoint* vIntersection_001::Intersect_001 ( vTriangle tri, vPoint eye, vPoint ray ) {

	if ( debug_msg == 1) printf("vPoint* vIntersection_001::Intersect ( vTriangle tri, vPoint eye, vPoint ray ) starts.\r\n");

	vCalculation *cal = nullptr;

	cal = new vCalculation ();

	if ( debug_msg == 1) printf("eye= ");
	eye.print();
	if ( debug_msg == 1) printf("ray= ");
	ray.print();

	if ( debug_msg == 1) printf("tri= ");
	tri.print();

	vPoint* n = tri.getNormal ();
	if ( debug_msg == 1) printf("normal= ");
	n->print();
	double d = -n->x*tri.p1.x - n->y*tri.p1.y - n->z * tri.p1.z;
	double depth = ( -d - n->x*eye.x - n->y*eye.y - n->z*eye.z ) / ( n->x*ray.x + n->y*ray.y + n->z*ray.z + 0.001);

	if ( debug_msg == 1) printf("i0 d=%f\r\n", d);
	if ( debug_msg == 1) printf("i0 depth=%f\r\n", depth);

	if ( depth < 0.0 ) this->OtherSide = 1;
	else this->OtherSide = 0;

	if ( debug_msg == 1) printf("this->OtherSide %d\r\n", this->OtherSide);

	vPoint* scale_ray = cal->scale( ray, depth);
	vPoint* intersection = cal->add( eye, *scale_ray);


	delete( cal );

	if ( debug_msg == 1) printf("vPoint* vIntersection_001::Intersect ( vTriangle tri, vPoint eye, vPoint ray ) ends.\r\n");
	return intersection;
}

// 20210609
double vIntersection_001::Depth ( vTriangle tri, vPoint eye, vPoint ray ) {

	if ( debug_msg == 1) printf("vPoint* vIntersection_001::Intersect ( vTriangle tri, vPoint eye, vPoint ray ) starts.\r\n");

	vCalculation *cal = nullptr;

	cal = new vCalculation ();

	if ( debug_msg == 1) printf("eye= ");
	eye.print();
	if ( debug_msg == 1) printf("ray= ");
	ray.print();

	vPoint* n = tri.getNormal ();
	double d = -n->x*tri.p1.x - n->y*tri.p1.y - n->z * tri.p1.z;
	double depth = ( -d - n->x*eye.x - n->y*eye.y - n->z*eye.z ) / ( n->x*ray.x + n->y*ray.y + n->z*ray.z );

	if ( debug_msg == 1) printf("depth=%f\r\n", depth);

	delete( cal );

	if ( debug_msg == 1) printf("vPoint* vIntersection_001::Depth ( vTriangle tri, vPoint eye, vPoint ray ) ends.\r\n");
	return depth;
}


// 20190202
// ray( x2, y2, z2 )
// eye( x3, y3, z3 )
// intersection( xi, yi, zi )
// eye + depth * ray = intersection( xi, yi, zi )
// ( x3, y3, z3 ) +  depth*(x2, y2, z2 ) =( xi, yi, zi )
// depth = ( a*x4 -a*x3 + b*y4 - b*y3 + c*z4 -c*z3 ) / (a*x2 + b*y2 + c*z2) 
// P1(x4, y4, z4)
// d = -a*x4 -b*y4 -c*z4

