#ifndef _READ_CSV__002_
#define _READ_CSV__002_
//...
extern int read_csv_000a_002 ();
extern int set_read_csv_000a_002 (char** argv, int argc);
extern int initialize_read_csv_000a_002 (char** argv, int argc);
#endif
