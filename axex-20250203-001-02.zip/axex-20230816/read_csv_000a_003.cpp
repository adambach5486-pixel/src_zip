#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_003.h"

extern char* filename_read_csv_000a_003_ = (char*)"read_csv_000a_003.txt";

int read_csv_000a_003 ();
int set_read_csv_000a_003 (char** argv, int argc);
int initialize_read_csv_000a_003 (char** argv, int argc);

int read_csv_000a_003 () {
	return 1;

}


int read_csv_000a_set_003 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_003 (char** argv, int argc) {
 	return 1;
 
}

