// ---
// ---
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "vVectorCG.h"
#include "vModelBufferController.h"

#include "vDisplayController.h"
#include "vDisplayController_001.h"
#include "vModelBufferController.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"
#include "jackson_animation_focus_003_02.h"
#include "jackson_animation_focus_003_03.h"
#include "jackson_animation_focus_003_04.h"
#include "jackson_animation_focus_003_05.h"



// --- Button of Header Start --- 

// 20260116
int Stack_Button_Focus (ANIMATION_FOCUS* r) ;
int Stack_Button_Focus ( int x, int y, int w, int h ) ;

int Pop_Button_Focus (ANIMATION_FOCUS* r) ;
int Initialize_Button_Focus () ;
int Reinitialize_Button_Focus () ;

// 20260116
int Print_Button_Focus () ;


// 20260116
int Set_Button_Container ( int x, int y, int w, int h );
int Devide_Button_Container ( int devide );

// --- Button of Header End --- 


// --- Button of Code Start --- 

// 20260116
int Devide_Button_Container ( int devide ) {
	int mod_w, mod_h, width, height;
	int i, a;
	int sx, sy;

	width = p_jackson->container.width/ devide;
	height = p_jackson->container.height;

	sx = p_jackson->container.start_x;
	sy = p_jackson->container.start_y;
	//mod_w = p_jackson->container.width - width * devide;
	//mod_h = p_jackson->container.height - height * devide;

	a = Stack_Button_Focus( sx, sy, width, height);

	return 0;
}

// 20260116
int Set_Button_Container ( int x, int y, int w, int h ) {
	p_jackson->container.start_x = x;
	p_jackson->container.start_y= y;
	p_jackson->container.width = w;
	p_jackson->container.height = h;

	return 0;
}

// 20260116
// 20250202
int Stack_Button_Focus ( int x, int y, int w, int h ) {
	int a;

	if ( p_jackson->button_max < 0 )
		a = Initialize_Button_Focus ();

	if ( p_jackson->button_index < 0 ) p_jackson->button_index = 0;

	p_jackson->flexible_button[p_jackson->button_index]->start_x = x;
	p_jackson->flexible_button[p_jackson->button_index]->start_y = y;
	p_jackson->flexible_button[p_jackson->button_index]->width = w;
	p_jackson->flexible_button[p_jackson->button_index]->height = h;
	p_jackson->button_index++;

	a = Reinitialize_Button_Focus ();

	return 0;
}

// 20260116
int Pop_Button_Focus (ANIMATION_FOCUS* r) {
	p_jackson->button_index--;

	if ( p_jackson->button_index < 0 ) {
		r = NULL;
		return -1;
	}

	if ( p_jackson->flexible_button == NULL ) return -1;

	r = p_jackson->flexible_button[p_jackson->button_index];

	if ( r->width < 10 || r->width > 100 ) return -1;
	if ( r->height < 10 || r->height > 100 ) return -1;

	if ( r->start_x < 0 || r->start_x >= p_jackson->canvas_focus.width ) return -1;
	if ( r->start_y < 0 || r->start_y >= p_jackson->canvas_focus.height ) return -1;

	return 1;
}

// 20260116
int Initialize_Button_Focus () {
	int i;

	p_jackson->button_index = 0;
	p_jackson->button_max = 8;
	p_jackson->flexible_button = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->button_max );
	if ( p_jackson->flexible_button == NULL ) return -1;
	for ( i = 0; i<p_jackson->button_max; i++ ) {
		p_jackson->flexible_button[i] = (ANIMATION_FOCUS*) malloc ( sizeof(ANIMATION_FOCUS) * 1 );
		if (p_jackson->flexible_button[i] == NULL) return -1;
	}
	return 0;
}

// 20260116
int Reinitialize_Button_Focus () {
	ANIMATION_FOCUS** temp;
	int i, a;

	if ( p_jackson->button_index >= p_jackson->button_max ) {
		temp = (ANIMATION_FOCUS**) p_jackson->flexible_button;
		p_jackson->button_max *= 2;
		p_jackson->flexible_button = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->button_max );
		if (p_jackson->flexible_button == NULL ) {
			return -1;
		}
	} else {
		return 0;
	}

	for ( i = 0; i<p_jackson->button_index; i++) {
		p_jackson->flexible_button[i] = (ANIMATION_FOCUS*) temp[i];
	}

	for ( i = p_jackson->button_index; i<p_jackson->button_max; i++ ) {
		p_jackson->flexible_button[i] = (ANIMATION_FOCUS*) malloc ( sizeof(ANIMATION_FOCUS) * 1 );
		if (p_jackson->flexible_button[i] == NULL) return -1;
	}

	free(temp);
	a = Print_Button_Focus ();
	return 0;
}

// p_jackson->button_max
// p_jackson->button_index
// button
int Print_Button_Focus () {
	int i;
	FILE *fp;

	printf("int Print_Button_Focus () starts.\r\n");
	fp = fopen ("004-Button-Allocation-001\.txt", "wb");
	fprintf(fp, "004-Button-Allocation-001\.txt:\r\n");


	if ( p_jackson->flexible_button == NULL ) {
		fprintf(fp, "p_jackson->flexible_button is NULL.\r\n");
		fclose(fp);
		return -1;
	}

	printf("index %d max %d\r\n", p_jackson->button_index, p_jackson->button_max );

	fprintf(fp, "index %d max %d\r\n", p_jackson->button_index, p_jackson->button_max );
	for ( i = 0; i < p_jackson->button_max ; i++ ) {
		printf("p_jackson->flexible_button[%d]|%p|\r\n", i, p_jackson->flexible_button[i]);
		if ( p_jackson->flexible_button[i] != NULL ) {
			fprintf( fp, "p_jackson->flexible_button[%d]|%p|", i, p_jackson->flexible_button[i]);
			fprintf( fp, ",%d", p_jackson->flexible_button[i]->start_x);
			fprintf( fp, ",%d", p_jackson->flexible_button[i]->start_y);
			fprintf( fp, ",%d", p_jackson->flexible_button[i]->width);
			fprintf( fp, ",%d)\r\n", p_jackson->flexible_button[i]->height);
// o		fprintf( fp, "p_jackson->flexible_button[%d]|%p|\r\n", i, p_jackson->flexible_button[i]);
//			fprintf( fp, "|%s|\r\n", p_jackson->flexible_button[i]->str_name);
//			fprintf( fp, "|%s|(%d,%d,%d,%d)\r\n", p_jackson->flexible_button[i]->str_name, p_jackson->flexible_button[i]->start_x, p_jackson->flexible_button[i]->start_y, p_jackson->flexible_button[i]->width, p_jackson->flexible_button[i]->height );
		}
		else {
			fprintf( fp, "NULL\r\n" );
		}
	}

	fprintf( fp, "End\r\n" );
	fclose(fp);
	printf("int Print_Button_Focus () ends.\r\n");
	return 0;
}

// --- Button of Code Start --- 

