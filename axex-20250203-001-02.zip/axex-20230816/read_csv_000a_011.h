#ifndef _READ_CSV__011_
#define _READ_CSV__011_
//...
extern int read_csv_000a_011 ();
extern int set_read_csv_000a_011 (char** argv, int argc);
extern int initialize_read_csv_000a_011 (char** argv, int argc);
#endif
