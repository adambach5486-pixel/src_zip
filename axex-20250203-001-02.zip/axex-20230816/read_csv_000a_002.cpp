#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_002.h"

extern char* filename_read_csv_000a_002_ = (char*)"read_csv_000a_002.txt";

int read_csv_000a_002 ();
int set_read_csv_000a_002 (char** argv, int argc);
int initialize_read_csv_000a_002 (char** argv, int argc);

int read_csv_000a_002 () {
	return 1;

}


int read_csv_000a_set_002 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_002 (char** argv, int argc) {
 	return 1;
 
}

