#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_011.h"

extern char* filename_read_csv_000a_011_ = (char*)"read_csv_000a_011.txt";

int read_csv_000a_011 ();
int set_read_csv_000a_011 (char** argv, int argc);
int initialize_read_csv_000a_011 (char** argv, int argc);

int read_csv_000a_011 () {
	return 1;

}


int read_csv_000a_set_011 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_011 (char** argv, int argc) {
 	return 1;
 
}

