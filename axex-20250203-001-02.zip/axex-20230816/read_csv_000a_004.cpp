#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_004.h"

extern char* filename_read_csv_000a_004_ = (char*)"read_csv_000a_004.txt";

int read_csv_000a_004 ();
int set_read_csv_000a_004 (char** argv, int argc);
int initialize_read_csv_000a_004 (char** argv, int argc);

int read_csv_000a_004 () {
	return 1;

}


int read_csv_000a_set_004 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_004 (char** argv, int argc) {
 	return 1;
 
}

