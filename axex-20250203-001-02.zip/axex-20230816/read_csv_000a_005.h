#ifndef _READ_CSV__005_
#define _READ_CSV__005_
//...
extern int read_csv_000a_005 ();
extern int set_read_csv_000a_005 (char** argv, int argc);
extern int initialize_read_csv_000a_005 (char** argv, int argc);
#endif
