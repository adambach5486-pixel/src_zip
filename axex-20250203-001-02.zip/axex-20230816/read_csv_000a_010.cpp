#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_010.h"

extern char* filename_read_csv_000a_010_ = (char*)"read_csv_000a_010.txt";

int read_csv_000a_010 ();
int set_read_csv_000a_010 (char** argv, int argc);
int initialize_read_csv_000a_010 (char** argv, int argc);

int read_csv_000a_010 () {
	return 1;

}


int read_csv_000a_set_010 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_010 (char** argv, int argc) {
 	return 1;
 
}

