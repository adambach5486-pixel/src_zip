#ifndef _JACSON_ANIMATION_FOCUS_003_02_H_
#define _JACSON_ANIMATION_FOCUS_003_02_H_

extern int Draw_Circle_Line_005 (float x1, float y1, float x2, float y2, float bold, int type, int first_type ) ;
extern int Draw_Line_and_Focus ();
extern int Draw_Line_and_Focus_thin ();
extern int Set_Debug_Sleep_003_02 (int value );
extern int Draw_Line_and_Focus_thin_axex ();

// 20250528
extern int Organize_Axex (int type);
extern int Print_Organize_Axex (vLine** lines, int num);
extern int Draw_Organize_Axex (vLine** lines, int num);

// 20250530
extern int Draw_Line_and_Focus_thin_axex_bones ();
extern int Draw_Organize_Bones_Line_005 (vPoint** points, int num, int debug);
// 20250611
extern int Change_Eye_thin_axex_bones ( int debug ) ;

// 20250615
extern int Print_Focuses ();

// 20250808
extern int Set_Navy_White_Blue ();
extern int Set_Navy_Pink ();
extern int Set_Navy_White_Green ();

// 20250824
extern int Spin_Eye_thin_axex_bones ();

// 20250918
extern int Calculate_Screen_UV_sub_level_002 ();
extern int Organize_Axex_Bones (int type, int debug );
extern int Spin_Eye_thin_axex_bones_sub_level_002 ();
extern int Initialize_Spin_Eye_thin_axex_bones ();
extern int Reinitialize_Spin_Eye_thin_axex_bones ();


// 20250906
extern int Caribration_Spin_Eye_thin_axex_bones () ;

// 20250907
extern int Caribration_Set_Eye ();

// 20250909
extern int Caribration_Intersection ();

extern int Caribration_Set_Eye_Right ();
extern int Caribration_Set_Eye_002 ();
extern int Caribration_Set_Eye_003 ();
extern int Caribration_Set_Eye_004 ();
extern int Caribration_Set_Eye_005 ();
extern int Caribration_Set_Eye_006 ();
extern int Caribration_Set_Eye_007 ();
extern int Caribration_Set_Eye_008 ();
extern int Caribration_Set_Eye_009 ();
extern int Caribration_Set_Eye_010 ();
extern int Caribration_Set_Eye_011 ();
extern int Caribration_Set_Eye_012 ();


#endif
