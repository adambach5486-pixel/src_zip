#ifndef _FILE_CONTROLER_H_

#define _FILE_CONTROLER_H_

//using namespace std;

class FileControler
{
	public:
		FileControler ( );
		void List_Files_001(char *strPath);
		void List_Files(char* lpcstr_path );
		void print_strings ();
		char** get_files ( char* str, int* file_num );
		char** get_files_001 ( char* str, int* file_num );
		char** get_files_011 ( char* str, int* file_num );
		char** get_files_012 ( char* str, int* file_num, int debug_num );
		int get_strings_number ();
		int print_char(char* p_char);
		int get_file_info ( char *lpcstr_path, char **result ) ;
		int get_file_info_012 ( char *lpcstr_path, char **result, int debug_num ) ;
		int windows_get_file_info () ;

	private:
		void Sub_List_Files () ;
		char* m_fullpath_001 ( char* strPath,  char* filename ) ;
		char* m_fullpath ( char* strPath, char* filename );

		char* to_directory(char* lpcstr_path, char* filename );
		char** put_string ( char* str ) ;
		char** get_strings ();
		char* fc_copyof ( char* str ) ;
		int is_attribute ( char* ffdc_filename, char* char_attr );

	public:
		void write_log ( char* str ) ;

	private:
		char** list_dummy_ary = nullptr;
		int list_dummy_ary_index = 0;

};

#endif
