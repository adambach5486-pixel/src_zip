#include <stdio.h>
#include <stdlib.h>


#include "read_csv_000a_009.h"

extern char* filename_read_csv_000a_009_ = (char*)"read_csv_000a_009.txt";

int read_csv_000a_009 ();
int set_read_csv_000a_009 (char** argv, int argc);
int initialize_read_csv_000a_009 (char** argv, int argc);

int read_csv_000a_009 () {
	return 1;

}


int read_csv_000a_set_009 (char** argv, int argc) {
 	return 1;
 
}

int read_csv_000a_initialize_009 (char** argv, int argc) {
 	return 1;
 
}

