#ifndef _JACSON_ANIMATION_FOCUS_003_05_H_
#define _JACSON_ANIMATION_FOCUS_003_05_H_

// 20260116
extern int Stack_Button_Focus (ANIMATION_FOCUS* r) ;
extern int Pop_Button_Focus (ANIMATION_FOCUS* r) ;
extern int Initialize_Button_Focus () ;
extern int Reinitialize_Button_Focus () ;

// 20260116
extern int Print_Button_Focus () ;


// 20260116
extern int Set_Button_Container ( int x, int y, int w, int h );
extern int Devide_Button_Container ( int devide );


#endif
