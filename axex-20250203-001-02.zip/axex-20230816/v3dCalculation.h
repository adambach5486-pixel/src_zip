#ifndef _V3DCALCULATION_
#define _V3DCALCULATION_

#include "vScreenCG.h"

class v3dCalculation {
	private:
		vScreenCG screen_005;
		vDisplayController display_001;

	public:
		int calculation_thread () ;
		int calculation_thread_002 () ;
		int calculation_thread_003 () ;
		int calculation_thread_004 () ;
		int calculation_thread_005 () ;
		int calculation_thread_006 () ;
		int calculation_thread_007 () ;
		int calculation_thread_008 () ;
		int calculation_thread_009 () ;
		int calculation_thread_010 ();
		int calculation_thread_011 ();
		int calculation_thread_012 ();
		int calculation_thread_013 ();
		int calculation_thread_014 ();
		int calculation_thread_015 ();
		int calculation_thread_016 ();
		int calculation_thread_017 ();
		int calculation_thread_018 ();
		int calculation_thread_019 ();
		int calculation_thread_020 ();
		int calculation_thread_021 ();
		int calculation_thread_022 ();
		int calculation_thread_023 ();
		int calculation_thread_024 ();
		int calculation_thread_025 ();
		int calculation_thread_026 ();
		int calculation_thread_027 ();
		int calculation_thread_028 ();
		int calculation_thread_029 ();
		int calculation_thread_030 ();
		int calculation_thread_031 ();
		int calculation_thread_032 ();
		int calculation_thread_033 ();
		int calculation_thread_034 ();
		int calculation_thread_035 ();
		int calculation_thread_036 ();
		int calculation_thread_037 ();
		int calculation_thread_038 ();
		int calculation_thread_039 ();
		int calculation_thread_040 ();
		int calculation_thread_041 ();
		int calculation_thread_042 ();
		int calculation_thread_043 ();
		int calculation_thread_044 ();
		int calculation_thread_045 ();
		int calculation_thread_046 ();
		int calculation_thread_047 ();
		int calculation_thread_048 ();
		int calculation_thread_049 ();
		int calculation_thread_050 ();
		int calculation_thread_051 ();
		int calculation_thread_052 ();
		int calculation_thread_053 ();
		int calculation_thread_054 ();
};

#endif
