#include <stdio.h>
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "wTextarea.h"
#include "clipboard.h"
#include "Print.h"	//ADD: 20191228

#include "print_param_001.h"

#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"
#include "vCurveCalculation.h"

#include "vIntersection_001.h"
#include "vIntersection.h"

#include "vScreenCG.h"
#include "vScreen.h"
//#include "vLine.h"
//#include "vCircle.h"

#include "vCalculation.h"

#include "vAxex_2D.h"
#include "vDisplayController.h"


#include "vPointStructure.h"
#include "vPointLinear.h"
#include "display_threeD.h"

#include "v3dCalculation.h"

#include "vReturnableParam.h"
//#include "print_scheme_001.h"

#include "file_numbering_001.h"
#include "file_numbering.h"

int main_007 ( int argc, char** argv ) ;
int main_006 ( int argc, char** argv ) ;
int main_005 ( int argc, char** argv ) ;
int main_004 ( int argc, char** argv ) ;
int main_003 ( int argc, char** argv ) ;
int main_002 ( int argc, char** argv ) ;
int main_001 ( int argc, char** argv ) ;
int main_v3d ( int argc, char** argv ) ;
int numbering(int argc, char** argv ) ;

int main ( int argc, char** argv ) ;
int set_no_print_socket_msg () ;

int main ( int argc, char** argv ) {
	int a;

	a = set_no_print_socket_msg () ;
	a = main_006 (argc, argv );

	return 0;
}


//
int main_007 ( int argc, char** argv ) {
	char* a_b;
	char* result_001;

	printf("main ends.\r\n");

	printf ("ascii |%p|\r\n", a_b );
	printf ("print_socket_msg = %d\r\n", print_socket_msg);
	printf ("High_Level_Error_MSG = %d\r\n", High_Level_Error_MSG);
	printf ("Low_Level_Error_MSG = %d\r\n", Low_Level_Error_MSG);

	result_001 = err_msg_002 ("ascii |%p|\r\n", a_b );

	print_memories_002();
	printf("result_001|%p|=|%s|\r\n", result_001, result_001);
	printf("main ends.\r\n");

	return 0;
}

int set_no_print_socket_msg () {
	printf("set_no_print_socket_msg starts.\r\n");

	print_socket_msg = 0;
	printf ("set print_socket_msg = %d\r\n", print_socket_msg);
	printf ("High_Level_Error_MSG = %d\r\n", High_Level_Error_MSG);
	printf ("Low_Level_Error_MSG = %d\r\n", Low_Level_Error_MSG);

	printf("set_no_print_socket_msg ends.\r\n");
	return 0;
}

int main_006 ( int argc, char** argv ) {
	char* a_b;
	char* result_001;

	printf("main_006 ends.\r\n");

	printf ("ascii |%p|\r\n", a_b );
	printf ("print_socket_msg = %d\r\n", print_socket_msg);
	printf ("High_Level_Error_MSG = %d\r\n", High_Level_Error_MSG);
	printf ("Low_Level_Error_MSG = %d\r\n", Low_Level_Error_MSG);

	err_msg_002 ("ascii |%p|", a_b );
	// x a_b = copyof_012("hamming bird");
	a_b = copyof_012("hamming bird");
	err_msg_002 ("ascii |%p| |%s|", a_b, a_b );

	err_msg_001 ("ascii |%p| |%s| dummy_ary_index|%d| dummy_ary_index_max|%d| ", a_b, a_b, dummy_ary_index, dummy_ary_index_max );

	aFree_005( a_b );

	result_001 = err_msg_001 ("ascii |%p| |%s| dummy_ary_index|%d| dummy_ary_index_max|%d| ", a_b, a_b, dummy_ary_index, dummy_ary_index_max );

	print_memories_002();

	printf("result_001|%p|=|%s|\r\n", result_001, result_001);

	printf("main_006 ends.\r\n");

	return 0;
}


//
int main_005 ( int argc, char** argv ) {
	char* a_b;

	printf("main_005 ends.\r\n");

	printf ("ascii |%p|\r\n", a_b );
	printf ("print_socket_msg = %d\r\n", print_socket_msg);
	printf ("High_Level_Error_MSG = %d\r\n", High_Level_Error_MSG);
	printf ("Low_Level_Error_MSG = %d\r\n", Low_Level_Error_MSG);

	err_msg_002 ("ascii |%p|", a_b );
	// x a_b = copyof_012("hamming bird");
	a_b = copyof_012("hamming bird");
	err_msg_002 ("ascii |%p| |%s|", a_b, a_b );
	err_msg_001 ("ascii |%p| |%s|", a_b, a_b );

	print_memories_002();
	printf("main_005 ends.\r\n");

	return 0;
}

//
int main_004 ( int argc, char** argv ) {
	char* a_b;

	printf("main_004 ends.\r\n");

	printf ("ascii |%p|\r\n", a_b );
	printf ("print_socket_msg = %d\r\n", print_socket_msg);
	printf ("High_Level_Error_MSG = %d\r\n", High_Level_Error_MSG);
	printf ("Low_Level_Error_MSG = %d\r\n", Low_Level_Error_MSG);
	printf("main_004 ends.\r\n");

	return 0;
}

//
int main_003 ( int argc, char** argv ) {
	char* a_b;
	printf("main_003 starts.\r\n");

//	a_b = (char*) copyof( (char*)"---" );
	printf ("ascii |%p|\r\n", a_b );
	err_msg_001 ("ascii |%p|\r\n", a_b );

	aFree_005 ( a_b );

	printf ("ascii |%p|\r\n", a_b );
	err_msg_001 ("ascii |%p|\r\n", a_b );
	printf("main_003 ends.\r\n");

	return 0;
}

//
int main_002 ( int argc, char** argv ) {
	printf("main_002 starts.\r\n");

	int a = numbering ( argc, argv);

	printf("main_002 ends.\r\n");

	return 0;
}

int main_v3d ( int argc, char** argv ) {
	printf("main starts.\r\n");

	v3dCalculation* calc = new v3dCalculation ();
	//calc->calculation_thread_019();
	//calc->calculation_thread_020();
	//calc->calculation_thread_021();
	//calc->calculation_thread_022();
	//calc->calculation_thread_023();
	// x calc->calculation_thread_024();
	// x calc->calculation_thread_025();
	// o calc->calculation_thread_026();
	// o  calc->calculation_thread_027();
	// x  calc->calculation_thread_028();
	// x  calc->calculation_thread_029();
	// x  calc->calculation_thread_030();
	    calc->calculation_thread_051();
	// o calc->calculation_thread_032();
//	calc->calculation_thread_033();
//	calc->calculation_thread_034();

//	calc->calculation_thread_015();
//	calc->calculation_thread_014();
//	calc->calculation_thread_013();
//	calc->calculation_thread_012();
//	calc->calculation_thread_011();
//	calc->calculation_thread_007();
//	calc->calculation_thread_006();
//	calc->calculation_thread_005();
//	calc->calculation_thread_004();
//	calc->calculation_threed_003();
//	calc->calculation_threed_002();
//	calc->calculation_threed();

//	Sleep(3000);


// o	calc->calculation_thread_035();
// o	calc->calculation_thread_036();
// o	calc->calculation_thread_037();
// o	calc->calculation_thread_038();
// o	calc->calculation_thread_039();
// x 	calc->calculation_thread_040();
// o 	calc->calculation_thread_041();
// o	calc->calculation_thread_042();
// o	calc->calculation_thread_043();
// o	calc->calculation_thread_044();
// o	calc->calculation_thread_045();
// o	calc->calculation_thread_046();
// o	calc->calculation_thread_047();
// o	calc->calculation_thread_048();
//		calc->calculation_thread_049();
// o	calc->calculation_thread_050();


//	calc->calculation_thread_051();
//	calc->calculation_thread_052();
//	calc->calculation_thread_053();

	print_point_memories ();
	print_memories_vLine ();

	printf("main ends.\r\n");
	return 0;
}


//
int numbering(int argc, char** argv ) { 
	printf("int numbering(int argc, char** argv ) starts.\r\n");
//	exit(-1);
//	printf("para %s %s\r\n", argv[1], argv[2] );
//	int a = find_numbering_011 (argv[1], atoi(argv[2]));
//	int a = find_numbering_011 (argv[1], 7);
//	int a = find_numbering_011 ( (char*) ".\\*\.txt", 7);
//	int a = find_numbering_012 ( (char*) ".\\*\.txt", 7);
//	int a = find_numbering_012 ( (char*) "*\.txt", 6);
//	int a = find_numbering_011 ( (char*) "*\.txt", 6);
//	int a = find_numbering_011 ( (char*) ".\\001-01\.txt", 6);
	int a = find_numbering_011 ( (char*) ".\\001*\.txt", 6);
	printf("int numbering(int argc, char** argv ) ends.\r\n");
	return 0;
}

// char* m_replace ( char* char_string, char* from_string, char* to_string ) ;
// 001-merge_test-20220108-001.txt
//
int main_001 () {
	FILE *fp;
	int a, sz;
	char* dummy_001 = NULL;
	char* dummy_002 = NULL;
	char* dummy_003 = NULL;
	int i;
	char code[1024];

	fp = (FILE*)fopen ("001-merge_test-20220108-001.txt", "r");
	fseek(fp, 0L, SEEK_END);
	sz = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	printf("sz %d\r\n", sz);
	dummy_001 = (char*) malloc ( sizeof(char) * sz );
	if ( dummy_001 == NULL ) {
		printf("dummy_001 is NULL.\r\n");
		exit(-1);
	}

//	fread ( aaa, 1, sz, fp);
	fread ( dummy_001, 1, sz, fp);
	fclose (fp);

	printf("%s\r\n", dummy_001);


	fp = (FILE*)fopen ("001-merge_test-20220108-002.txt", "r");
	fseek(fp, 0L, SEEK_END);
	sz = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	printf("sz %d\r\n", sz);
	dummy_002 = (char*) malloc ( sizeof(char) * sz );
	if ( dummy_002 == NULL ) {
		printf("dummy_002 is NULL.\r\n");
		exit(-1);
	}

	// ($$codeblock)
	fread ( dummy_002, 1, sz, fp);
	fclose (fp);
	printf("%s\r\n", dummy_002);


	fp = (FILE*)fopen ("001-merge_test-20220108-001-01.txt", "w");
	for ( i=0; i<100; i++ ) {
		sprintf( code, dummy_001, i, i, i );
		printf("%s\r\n", code );
		char* str = (char*)m_replace ( code, "($$codeblock)", dummy_002 );
		printf("%s\r\n", str );
		fprintf( fp, "%s\r\n", str);
	}

	fclose (fp);


	fp = (FILE*)fopen ("001-20230109-003.txt", "r");
	fseek(fp, 0L, SEEK_END);
	sz = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	printf("sz 001 %d\r\n", sz);
	dummy_003 = (char*) malloc ( sizeof(char) * sz );
	if ( dummy_003 == NULL ) {
		printf("dummy_003 is NULL.\r\n");
		exit(-1);
	}

	// ($$codeblock)
	fread ( dummy_003, 1, sz, fp);
	printf("dummy_003 %d |%s|\r\n", sizeof(dummy_003), dummy_003);
	fclose (fp);

	fp = (FILE*)fopen ("001-merge_test-20230109-003-01.txt", "w");
	for ( i=0; i<100; i++ ) {
		printf( dummy_003, i);
		fprintf( fp, dummy_003, i);
	}

	fclose (fp);
	printf("main ends.\r\n");
	return 0;
}

//
