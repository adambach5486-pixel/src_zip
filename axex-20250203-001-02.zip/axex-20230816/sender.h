#ifndef _SENDER_H_
#define _SENDER_H_
//
//
//
//
//
extern int sender_main ( int argc, char **argv) ;
extern int set_sender_default_parameters ( int *argc, char **argv );
extern int set_sender_default_parameters_001 ( int *argc, char **argv );

extern char* DEFAULT_SENDER_PARAM_1;
extern char* DEFAULT_SENDER_PARAM_2;
extern char* DEFAULT_SENDER_PARAM_3;


#endif
