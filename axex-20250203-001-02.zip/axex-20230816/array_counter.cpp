
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include <windows.h>

#include "Print.h"
#include "array_counter.h"


static char* dummy_allocation_001 = NULL;
char** dummy_ary = nullptr;
int dummy_ary_index = 0;
int dummy_ary_index_max = 0;
char** replace_dummy_ary = nullptr;


char* char_line_end = (char*)"\r\n";
//char* char_line_end_001 = (char*) "\r\n";

int array_count( char *ary );
char* concat( char *head, char *tail );
char* set_array(char *arry, int n, char c);
void print_string( char *head );
int m_compare ( char* tkn, char* m );

char* m_print_buffer( char* buffer);

char* front_trim( char* c_str ) ;
char* back_trim( char* c_str ) ;
char* m_trim( char* c_str ) ;
int m_start_with ( char *head, char *tail ) ;
int m_contains ( char* c_str, char* c_ref ) ;

char* m_substring ( char* string, int start, int length );



//int main ( int argc, char *argv[] ) {
//
//	int ac = array_count((char *)"abcdefg");
//
//	err_msg_006("count=%d\n", ac );
//
//	return 0;
//}

void print_memories ();
void print_memories_002 ();
char** put_memories ( char* str );
char** put_memories_002 ( char* str );

void slide_to_back ( char *msg, int i, int count ) ;
void place_char ( char *p_char, char c ) ;

char* m_replace ( char* char_string, char* from_string, char* to_string ) ;
void aFree ( char* str ) ;
void aFree_001 ( char* str ) ;
int sub_aFree ( char* str ) ;
void aFree_005 ( char* str ) ;
int get_last_index_005() ;



char* char_string ( int num_memories ) ;
char* char_string_002 ( int num_memories ) ;
char* char_string_010 ( int num_memories ) ;
char* char_string_012 ( int num_memories ) ;

void a_sleep_thread () ;
void a_sleep_thread_002 () ;

char* copyof ( char* str ) ;
char* copyof_001 ( char* str ) ;
char* copyof_002 ( char* str ) ;
char* copyof_010 ( char* str ) ;
char* copyof_012 ( char* str ) ;

void set_a_sleep_thread_time (int lt);
int a_sleep_thread_time = 10;

int debug_flag_array_counter = 1;
int set_debug_flag_array_counter ( int flg ) ;

int set_debug_flag_array_counter ( int flg ) {
	debug_flag_array_counter = flg;
	return 0;
}

void set_a_sleep_thread_time (int lt) {
	if (debug_flag_array_counter) printf("set_a_sleep_thread_time starts.\r\n");
	a_sleep_thread_time = lt; 
	if (debug_flag_array_counter) printf("set_a_sleep_thread_time ends.\r\n");
}

void a_sleep_thread () {
	if (debug_flag_array_counter) printf("a_sleep_thread starts.\r\n");
	Sleep(a_sleep_thread_time);
	if (debug_flag_array_counter) printf("a_sleep_thread ends.\r\n");
}

void a_sleep_thread_002 () {
	if (debug_flag_array_counter) printf("a_sleep_thread_002 starts.\r\n");
	Sleep(10);
	if (debug_flag_array_counter) printf("a_sleep_thread_002 ends.\r\n");
}

char* m_substring ( char* string, int start, int length ) {
	if (debug_flag_array_counter) printf("m_substring starts. %d %d |%s|\r\n", start, length, string );

	int ac = array_count( string );
	if (debug_flag_array_counter) printf("array count %d \r\n", ac );

	dummy_allocation_001 = (char*)malloc( sizeof(char) * ( length ) + 1 );
	put_memories( dummy_allocation_001 );

	for ( int i= start; i < start + length && i < ac; i++ ) {
		*(dummy_allocation_001 + i - start ) = *(string + i );
	}

	*(dummy_allocation_001 + length) = '\0';

	// 20241218
	// print_memories ();
	if (debug_flag_array_counter) printf("m_substring ends.\r\n");
	return dummy_allocation_001;
}


void clean_null_array() {

	replace_dummy_ary = ( char**) malloc ( sizeof( char* ) * dummy_ary_index );

	int index = 0;
	for( int i=0; i< dummy_ary_index; i++) {
		if ( dummy_ary[i] == nullptr ) {
			replace_dummy_ary[ index ] = dummy_ary[i];
			index++;
		}
	}

	free( dummy_ary );

	dummy_ary = replace_dummy_ary;
}

//
//
//
// '\r': 13
// '\n': 10
void place_char ( char *p_char, char c ) {
	char* result_001;
	// result_001 = if (debug_flag_array_counter) printf( "start of place_char ");
	// o result_001 = if (debug_flag_array_counter) printf( "%d %d %d", p_char, 0, c );
	// x result_001 = if (debug_flag_array_counter) printf( "%d %c %d", p_char, *p_char, c );
	//   4249052 3 13
	// x result_001 = if (debug_flag_array_counter) printf( "%d %c %d", p_char, *p_char, c );
	// print_memories( p_char ) ;
	// result_001 = if (debug_flag_array_counter) printf( "%d %d %d %d", p_char, '\n', '\r', c );
	*p_char = (char) c;
	// o *result_001 = (char) c;
	//   *p_char = *result_001;
	// result_001 = if (debug_flag_array_counter) printf( "end of place_char ");
}

//
//
//
//
//
void slide_to_back ( char *msg, int start_i, int count ) {
	char *result_001;
	char c;
	char back_c;

	// result_001 = if (debug_flag_array_counter) printf( "slide_to_back: start ");
	for( int i = start_i; i<count - 1; i++ ) {
		// result_001 = if (debug_flag_array_counter) printf( "slide_to_back: loop satrt i=%d count %d ", i , count);
		// 003
		if ( i == start_i ) {
			c = *( msg + i );
		} else {
			c = back_c;
		}

		back_c = *( msg + i + 1 );
		// result_001 = if (debug_flag_array_counter) printf( "|%3d|", c );	// 001
		place_char ( msg + i + 1, c );				// 002
		// exit(-1);
		// place_char ( msg + i + 1, c ); // slide 1 to back and ensured to place.
		// result_001 = if (debug_flag_array_counter) printf( "slide_to_back: loop end   i=%d count %d c=%3d c=%c", i , count, c, c );
	}

	//004
	place_char ( msg + count, '\0' );
	// result_001 = if (debug_flag_array_counter) printf( "slide_to_back: end ");
}

//
//
//
//
//
char* m_replace ( char* char_string_m,
	char* from_string, char* to_string ) {
	char c1, c2, c11;
	int index_max = 0;

	if (debug_flag_array_counter) printf("char* m_replace ( char* char_string_m, char* from_string, char* to_string ) starts.\r\n");

	int count = array_count( char_string_m );
	int a_f = array_count( from_string );
	int a_t = array_count( to_string );
	int a_c = 0;
	index_max = ( count + a_t - 1 );

	char* char_string_2 = char_string_010 ( sizeof (char)* index_max );

	if (debug_flag_array_counter) printf("char_string_2 was allocated p|%p| size|%d|.\r\n", char_string_2, index_max );
	/*for ( int i=0; i<3; i++) {
		if (char_string_2 != NULL ) {
			if (debug_flag_array_counter) printf(" it can not allocate memories enough, so, it is sleeping in one second,\r\n");
			sleep(1);
			break;
		}
	}*/

	if (char_string_2 == NULL ) {
		if (debug_flag_array_counter) printf("m_replace can not allocate memories enough, so , it exit(-1).\r\n");
		exit(-1);
	}

	c2 = 0;
	int cnt_replace = 0;
	for ( int i = 0; i<count; i++ ) {
		if (debug_flag_array_counter) printf("loop starts: \r\n");
		c1 = *( char_string_m + i ) ;
		a_c = 0;
		for ( int j=0; j<a_f && j <count; j++ ) {
			c11 = *( char_string_m + i + j ) ;
			c2 = *( from_string + j ) ;
			if ( c11 != c2 ) break;
			a_c++;
		}

		if (debug_flag_array_counter) printf("i|%d| c1|%d|=|%c| a_c=%d a_f=%d c2|%d||%c|\r\n", i, c1, c1, a_c, a_f, c2, c2 );
		if ( a_c == a_f && cnt_replace >= 0) {
			// match
			int to = i + a_f;
			for( int k=0; k<a_t; k++ ) {
				if (debug_flag_array_counter) printf("replace string k=|%d|%c|\r\n", k, *( to_string + k ));
				int put_index_001 = + i + k + cnt_replace*(a_t- a_f );
				if ( index_max <= put_index_001 ) {
					index_max *= 2;
					char_string_2 = (char*) realloc ( char_string_2, sizeof(char) * index_max );
				}
				*( char_string_2 + put_index_001 ) = 
				  *( to_string + k );
			}
			i = to - 1;
			cnt_replace++;
		} else {
			int put_index_002 = i + cnt_replace*(a_t- a_f );
			if ( index_max <= put_index_002 ) {
				index_max *= 2;
				char_string_2 = (char*) realloc ( char_string_2, sizeof(char) * index_max );
			}
			*( char_string_2 + put_index_002 ) = c1;
		}
		if (debug_flag_array_counter) printf("loop ends: \r\n");
	}
	*( char_string_2 + count + cnt_replace*( a_t - a_f ) ) = '\0';
	if (debug_flag_array_counter) printf("char_string_m |%s| ends.\r\n", char_string_m );
	if (debug_flag_array_counter) printf("m_replaced |%p||%s| ends.\r\n", char_string_2, char_string_2 );

	return char_string_2;
}

//
void aFree ( char* str ) {
	int a;
	if (debug_flag_array_counter) printf("void aFree ( char* str ) |%p| starts.\r\n", str);

	for (int i=0; 1; i++ ) {
		a = sub_aFree ( str );
		if ( a == -1 ) break;
	}

	if (debug_flag_array_counter) printf("void aFree ( char* str ) |%p| ends.\r\n", str);
	return;
}

void aFree_001 ( char* str ) {
	int a;
	if (debug_flag_array_counter) printf("void aFree_001 ( char* str ) |%p| starts.\r\n", str);

	for (int i=0; 1; i++ ) {
		a = sub_aFree ( str );
		if ( a == -1 ) break;
	}

	if (debug_flag_array_counter) printf("void aFree_001 ( char* str ) |%p| ends.\r\n", str);
	return;
}

int get_last_index_005() {
	if (debug_flag_array_counter) printf("aint get_last_index_005() starts.\r\n");
	if (debug_flag_array_counter) printf("aint get_last_index_005() ends.\r\n");
	return dummy_ary_index;
}

// 	dummy_ary_index--;
//	free( dummy_ary[i] );
void aFree_005 ( char* str ) {
	char* w = NULL;
	int i;
	if (debug_flag_array_counter) printf("aFree_005 ( char* str ) starts.|%d| ", dummy_ary_index);
	if (debug_flag_array_counter) printf("dummy_ary_index %d", dummy_ary_index );
	if ( dummy_ary_index <= 0 ) return;

	if (debug_flag_array_counter) printf("dummy_ary_index |%d| last|%p| free|%p| ", dummy_ary_index, dummy_ary[ dummy_ary_index - 1 ], str );
	for ( i=0; i<dummy_ary_index; i++) {
		if (  str == dummy_ary[i] ) {
			if (debug_flag_array_counter) printf("index i=%d dummy_ary[i]=|%p|", i , dummy_ary[i] );
			w = dummy_ary[i];
			dummy_ary[i] = dummy_ary[ dummy_ary_index - 1 ];
			dummy_ary[ dummy_ary_index - 1 ] = w;
			break;
		}
	}

	if ( w != NULL) {
		free( w );
		dummy_ary_index--;
	}
	if (debug_flag_array_counter) printf("dummy_ary_index |%d| last|%p| free|%p| i|%d| w|%p|", dummy_ary_index, dummy_ary[ dummy_ary_index - 1 ], str, i, w );
	if (debug_flag_array_counter) printf("aFree_005 ( char* str ) ends. ");
}


//
int sub_aFree ( char* str ) {
	int stored_index = -1;
	if (debug_flag_array_counter) printf("sub_aFree starts.\r\n");
	if (debug_flag_array_counter) printf("We are going to free |%d| from array [%d]\r\n", str, dummy_ary_index );

	for ( int i=0; i<dummy_ary_index; i++) {
		if (debug_flag_array_counter) printf ("i %d/ %d\r\n", i, dummy_ary_index );
//		if ( m_compare ( str, dummy_ary[i] ) == 1 ) {
		if (  str == dummy_ary[i] ) {
			stored_index = i;
			if (debug_flag_array_counter) printf("free |%p| |%4d/%4d| |%s|%s|\r\n", dummy_ary[i], stored_index, dummy_ary_index, dummy_ary[i], str );
			free( dummy_ary[i] );
			dummy_ary[i] = NULL;
			if (debug_flag_array_counter) printf("free %d |%p|\r\n", i, dummy_ary[i] );
			Sleep(25);
			break;
		}
	}

	if (debug_flag_array_counter) printf("001 stored_index %d/\r\n", stored_index);
	if (stored_index == -1) {
		if (debug_flag_array_counter) printf("sub_aFree ends. there is no free.\r\n");
		return -1;
	}

	if (debug_flag_array_counter) printf("002 stored_index %d/\r\n", stored_index);
	for ( int i=stored_index; i<dummy_ary_index -1; i++) {
		if (debug_flag_array_counter) printf ("i %d/ %d stored_index %d\r\n", i, dummy_ary_index, stored_index );
		dummy_ary[ i ] = dummy_ary[ i + 1 ];
	}

	if (debug_flag_array_counter) printf("003 dummy_ary_index %d/ -> ", dummy_ary_index);
	dummy_ary_index--;
	if (debug_flag_array_counter) printf("004 dummy_ary_index %d/\r\n", dummy_ary_index);
	if (debug_flag_array_counter) printf("sub_aFree ends. return 1.\r\n");

	return 1;
}

//
//
//
//
//
char** put_memories ( char* str ) {

	if (debug_flag_array_counter) printf("char** put_memories ( char* str ) starts. index %d: index_max %d\r\n", dummy_ary_index, dummy_ary_index_max);

	if ( dummy_ary_index == 0 ) {
		dummy_ary_index_max = 8;
		dummy_ary = (char **) malloc( sizeof(char*) * dummy_ary_index_max );
		for ( int i=0; i<dummy_ary_index_max; i++ ) {
			dummy_ary[ i ] = NULL;
		}
		dummy_ary[ 0 ] = str;
		dummy_ary_index = 1;
	} else {
		dummy_ary_index++;
		if ( dummy_ary_index >= dummy_ary_index_max) {
			dummy_ary_index_max *= 2;
			dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index_max );
		}
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

	if (debug_flag_array_counter) printf("char** put_memories ( char* str ) ends.\r\n");
	return dummy_ary;
}

char** put_memories_002 ( char* str ) {

	if (debug_flag_array_counter) printf("char** put_memories_002 ( char* str ) starts. index %d: index_max %d\r\n", dummy_ary_index, dummy_ary_index_max);

	if ( dummy_ary_index == 0 ) {
		dummy_ary_index_max = 8;
		dummy_ary = (char **) malloc( sizeof(char*) * dummy_ary_index_max );
		for ( int i=0; i<dummy_ary_index_max; i++ ) {
			dummy_ary[ i ] = NULL;
		}
		dummy_ary[ 0 ] = str;
		dummy_ary_index = 1;
	} else {
		dummy_ary_index++;
		if ( dummy_ary_index >= dummy_ary_index_max) {
			dummy_ary_index_max *= 2;
			dummy_ary = (char **) realloc( dummy_ary, sizeof(char*)*dummy_ary_index_max );
		}
		dummy_ary[ dummy_ary_index - 1 ] = str;
	}

	if (debug_flag_array_counter) printf("char** put_memories_002 ( char* str ) ends.\r\n");
	return dummy_ary;
}

//
//
//
//
//
void print_memories () {
	if (debug_flag_array_counter) printf("void print_memories () starts.\r\n");

	for ( int i=0; i<dummy_ary_index; i++) {
		if (debug_flag_array_counter) printf("p|%p|:dummy_ary[%d]=|%s|\r\n", dummy_ary[i], i, dummy_ary[i] );
	}

	if (debug_flag_array_counter) printf("void print_memories () ends.\r\n");
}

void print_memories_002 () {
	if (debug_flag_array_counter) printf("void print_memories_002 () starts.\r\n");

	for ( int i=0; i<dummy_ary_index; i++) {
		if (debug_flag_array_counter) printf("p|%p|:dummy_ary[%d]=|%s|\r\n", dummy_ary[i], i, dummy_ary[i] );
	}

	if (debug_flag_array_counter) printf("void print_memories_002 () ends.\r\n");
}

//
//
//
//
//
//
char* m_print_buffer( char* buffer)
{
	char ALetter[1];
	int a = level_error_msg;

	level_error_msg = 6;

	for( int i=0; 1; i++ ) {
		ALetter[0] = buffer[i];

		if ( buffer[i] == '\0' ) break;

		if (debug_flag_array_counter) printf("i: %2d : %4d ALetter |%s| |%2d|%2d|%2d|\r\n", i, buffer[i], ALetter, '\r', '\n', '\0');
	}

	level_error_msg =  a;
}

//
//
//
//
//
//
int array_count( char *ary )
{
	char c;
	if (debug_flag_array_counter) printf("start function: array_count:\r\n");

	if ( ary == nullptr ) {
		if (debug_flag_array_counter) printf("end function: array_count: return -1\r\n");
		return -1;
	}

	int count = 0;
	for ( ;; ) {
		c = *ary;
		if ( c == '\0' ) {
			break;
		}
		ary++;
		count++;
	}

	if (debug_flag_array_counter) printf("end function: array_count: return %d\r\n", count);
	return count;
}

//
//
//
//
//
//
int m_compare ( char* tkn, char* m ) {

	int a = level_error_msg;
	level_error_msg = 6;
	if (debug_flag_array_counter) printf("function: m_compare:");

	int count_t = array_count( tkn );
	int count_m = array_count( m );

//	if (debug_flag_array_counter) printf(" %d | %d | %s | %s \r\n", count_t, count_m, tkn, m );

	if ( count_t != count_m ) {
		level_error_msg =  a;
		return -1;
	}

	// match;
	for ( int i=0; i< count_t; i++ ) {
		char c_t = tkn[i];
		char c_m = m[i];
		if ( c_t != c_m ) {
			level_error_msg =  a;
			return -1;
		 }
	}

	level_error_msg =  a;
	return 1;
}

//
//
//
//
//
int m_start_with ( char *head, char *tail ) {
	int nh, nt, min;
	char c1, c2;

	nh = array_count( head );
	nt = array_count( tail );
	min = nh;
	if ( min > nt ) {
		min = nt;
	}

	for ( int i=0; i<min; i++ ) {
		c1 = *(head + i ) ;
		c2 = *(tail + i ) ;
		if ( c1 != c2 ) {
			return 0;
		}
	}

	return 1;
}

//
//
//
//
//
//
//
char* m_concat( char *head, char *tail ) {
	int nh, nt;
	static int alloc = 0;
	char* c_head;
	char* result = NULL;
	char* l_dummy_allocation_001 = NULL;

	if (debug_flag_array_counter) printf("char* m_concat( char *head, char *tail ) starts.\r\n");

	nh = array_count( head );
	nt = array_count( tail );
	if ( nh < 0 ) nh = 0; 
	if ( nt < 0 ) nt = 0; 
	if (debug_flag_array_counter) printf("array_count: nh %d nt %d | %s %s \r\n", nh, nt, head, tail);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		} else {
			break;
		}
	}

	if ( alloc == 0 ) {
		alloc = 1;
		for ( int i=0; i<100; i++) {
			l_dummy_allocation_001 = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
			if ( l_dummy_allocation_001 != NULL ) break;

			sleep(1);
			char* d_a = (char *) malloc( 1 );
			free(d_a);
		}
		alloc = 0;
	}

	if (l_dummy_allocation_001==NULL) {
		if (debug_flag_array_counter) printf("l_dummy_allocation_001 is null.\r\n");
		exit(-1);
	}

	for( int i=0; i< nh; i++ ) {
		*( l_dummy_allocation_001 + i ) = *(head + i);
	}

	for( int i=0; i< nt; i++ ) {
		if (debug_flag_array_counter) printf("function m_concat: i %d\r\n", i);
		*( l_dummy_allocation_001 + nh + i ) = *(tail + i);
	}

	// 2 + 2 = 4 p[4] = "\n"
	*( l_dummy_allocation_001 + nh + nt ) = '\0';
	// 20241218
	result = copyof_012 (l_dummy_allocation_001);
//	put_memories( result );
	if (debug_flag_array_counter) printf("011: result|%p|=|%d| l_dummy_allocation_001|%p|=|%d|\r\n", result, array_count(result), l_dummy_allocation_001, array_count(l_dummy_allocation_001) );

	free(l_dummy_allocation_001);
//	if (debug_flag_array_counter) printf("012: result|%p|=|%s| l_dummy_allocation_001|%p|\r\n", result, array_count(result), l_dummy_allocation_001 );

	if (debug_flag_array_counter) printf("char* m_concat( char *head, char *tail ) ends.\r\n");
	return result;
}

//
//
//
//
//
//
void print_string( char *head )
{
	int nh;
	char aa[] = { '\0', '\0' };
	int a = level_error_msg;

	level_error_msg = 6;

	nh = array_count( head );
	for( int i=0; i<nh; i++ ) {
		aa[0] = *(head + i);
		if (debug_flag_array_counter) printf( "|%s|%3d|\n", (char*)aa, aa[0] );
	}

	level_error_msg =  a;
}

//
// do not use realloc in under sublootin.
// better solution usually by use of macro of realloc in C.
//
// use global value for allocation.
char* concat( char *head, char *tail )
{
	int nh, nt;
	static int alloc = 0;
	char ch, ct;
	char* c_head;

	int a = level_error_msg;
	level_error_msg = 6;

	nh = array_count( head );
	nt = array_count( tail );
	// o if ( nh + nt == 6 ) exit(-1);
	if (debug_flag_array_counter) printf("array_count: %d %d\n", nh, nt);

	for ( int j=0; j< 1000; j++ ) {
		if ( alloc == 1 ) {
			sleep(1000);
		}
		break;
	}
	if (debug_flag_array_counter) printf("alloc=%d\n", alloc);

	if ( alloc == 0 ) {
		alloc = 1;
//		c_head = (char *) realloc( head , sizeof( char ) * ( nh + nt + 1) );
		c_head = (char *) realloc( head , 100 );

		dummy_allocation_001 = (char *) malloc( sizeof(char) * ( nh + nt + 1 ) );
//		dummy_allocation_001 = (char *) malloc( sizeof(char *) * ( nh + nt + 1 ) );
//		dummy_allocation_001 = (char *) malloc( 100 * ( nh + nt + 1 ) );

//		*( head + nh + nt) = '\0';
		// x *(head) = 0;
		// o head = tail;
		if (debug_flag_array_counter) printf("allocation blocks(head)=%d\n", sizeof( head ) );
		if (debug_flag_array_counter) printf("allocation blocks(*head)=%d\n", sizeof( *head ) );
//		if (debug_flag_array_counter) printf("allocation blocks(array_count(head))=%d\n", array_count(head) );

		if (debug_flag_array_counter) printf("allocation blocks(c_head)=%d\n", sizeof( c_head ) );
		if (debug_flag_array_counter) printf("allocation blocks(tail)=%d\n", sizeof( tail ) );

		// x *(head + 3 ) = ' ';
		//set_array( head, 3, ' ');
		if (debug_flag_array_counter) printf("allocation blocks(array_count(head))=%d\n", array_count(head) );


//		*( dummy_allocation_001 + nh + nt ) = '\0';
		*( dummy_allocation_001 + 1 ) = '\0';
		if (debug_flag_array_counter) printf("allocation blocks( dummy_allocation_001 )=%d\n", sizeof( dummy_allocation_001 ) );
		if (debug_flag_array_counter) printf("allocation blocks( array_count( dummy_allocation_001 ) ) = %d\n", array_count(dummy_allocation_001) );

		alloc = 0;
	}

// o	head = tail;
// x	*head = *tail;
// o	ch = *head;
//	exit(-1);

	head += nh;
	for( int i=0; i<nt; i++ ) {
		// x head[ nh + i ] = tail[ i ];
		// x head[ 0 ] = tail[ i ];
		// x *(head + nt + i) = *( tail + i);
		// x *(head + nt + i) = *( tail);
		// x *(head + nt + i) = 0;
		// o head = tail;
		// x *head = *tail;
		// x *head = 0;
		// x *(head) = 0;

		ch = *head;
		ct = *tail;

		// o *(head + 3) = ct;
		// x *( head + nh + i ) = ct;
		// x *head = ct;

		head = tail;

		tail++;
		head++;
	}

	level_error_msg =  a;

	return head;
}

//
//
//
//
//
//
char* set_array(char *arry, int n, char c) {

	static char *returnable;

	int a = level_error_msg;
	level_error_msg = 6;

	returnable = arry;
	arry++;
	*arry = c;
	////arry = c;
	//arry = returnable;

	level_error_msg =  a;

	return returnable;
}

// alloc's
//
//
char* char_string ( int num_memories ) {
	if (debug_flag_array_counter) printf("char* char_string ( int num_memories ) starts. dummy_allocation_001=%p\r\n", dummy_allocation_001);
// 20210731
//	dummy_allocation_001 =NULL;
// 20241218
//	print_memories();
	for ( int i =0; i<10; i++) {
		if (debug_flag_array_counter) printf("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		if (debug_flag_array_counter) printf("dummy_allocation_001|%p|\r\n", dummy_allocation_001);
		if ( dummy_allocation_001 != NULL ) {
			break;
		}
		a_sleep_thread ();
	}
	put_memories( dummy_allocation_001 );
	if (debug_flag_array_counter) printf("char* char_string ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}

char* char_string_012 ( int num_memories ) {
	char* dummy_allocation_001_01 = NULL;
	if (debug_flag_array_counter) printf("char* char_string_012 ( int num_memories ) starts. num_memories=%d dummy_allocation_001_01=%p\r\n", num_memories, dummy_allocation_001_01);
// 20210731
//	dummy_allocation_001_01 =NULL;
//	print_memories_002();
	for ( int i =0; i<10; i++) {
		if (debug_flag_array_counter) printf("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001_01);
		dummy_allocation_001_01 = (char*) malloc( sizeof(char) * num_memories );
		if (debug_flag_array_counter) printf("dummy_allocation_001_01|%p|\r\n", dummy_allocation_001_01);
		if ( dummy_allocation_001_01 != NULL ) {
			break;
		}
		a_sleep_thread ();
	}
	put_memories_002( dummy_allocation_001_01 );
	if (debug_flag_array_counter) printf("char* char_string_012 ( int num_memories ) ends.\r\n");
	return dummy_allocation_001_01;
}

char* char_string_002 ( int num_memories ) {
	if (debug_flag_array_counter) printf("char* char_string_002 ( int num_memories ) starts. dummy_allocation_001=%p\r\n", dummy_allocation_001);
// 20210731
//	dummy_allocation_001 =NULL;
// 20241218
//	print_memories_002();
	for ( int i =0; i<10; i++) {
		if (debug_flag_array_counter) printf("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		if (debug_flag_array_counter) printf("dummy_allocation_001|%p|\r\n", dummy_allocation_001);
		if ( dummy_allocation_001 != NULL ) {
			break;
		}
		a_sleep_thread ();
	}
	put_memories_002( dummy_allocation_001 );
	if (debug_flag_array_counter) printf("char* char_string_002 ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}


// alloc's
//
//
char* char_string_010 ( int num_memories ) {
	if (debug_flag_array_counter) printf("char* char_string_010 ( int num_memories ) starts. dummy_allocation_001=|%p|\r\n", dummy_allocation_001);
// 20210731
	dummy_allocation_001 =NULL;
	for ( int i =0; i<10; i++) {
		if (debug_flag_array_counter) printf("character i %d/10 num_memories %d about|%p|\r\n", i, num_memories, dummy_allocation_001);
		dummy_allocation_001 = (char*) malloc( sizeof(char) * num_memories );
		if ( dummy_allocation_001 != NULL ) {
			if (debug_flag_array_counter) printf("dummy_allocation_001 is not NULL, so, allocation is well.\r\n");
			for ( int j=0; j<num_memories; j++ ) {
				if (debug_flag_array_counter) printf("j %d\r\n", j);
				dummy_allocation_001[j] = (char)' ';
			}
			if (debug_flag_array_counter) printf("break...\r\n");
			break;
		} else {
			if (debug_flag_array_counter) printf("char* char_string_010 ( int num_memories ) exit because dummy_allocation_001 is NULL actually |%p|.\r\n", dummy_allocation_001);
			exit(-1);
		}
		a_sleep_thread ();
	}
	if (debug_flag_array_counter) printf("dummy_allocation_001=|%p| |%s| array count=%d\r\n", dummy_allocation_001, dummy_allocation_001, array_count(dummy_allocation_001));
	if (debug_flag_array_counter) printf("char* char_string_010 ( int num_memories ) ends.\r\n");
	return dummy_allocation_001;
}


// alloc's
//
//
char* copyof ( char* str ) {
	int ac;
	char* dummy_allocation_001_01 = NULL;
	if (debug_flag_array_counter) printf("char* copyof ( char* str ) starts.\r\n");
	ac = array_count(str);
	if (debug_flag_array_counter) printf("array_count %d\r\n", ac );
	dummy_allocation_001_01 = (char*)malloc( sizeof(char) * (ac + 1) );
	a_sleep_thread ();
	if ( dummy_allocation_001_01 == NULL ) {
		if (debug_flag_array_counter) printf("dummy_allocation_001_01 is null.\r\n");
		exit(-1);
	}
	if (debug_flag_array_counter) printf("dummy_allocation_001_01 point|%p|\r\n", dummy_allocation_001_01 );
	put_memories( dummy_allocation_001_01 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001_01[i] = str[i];
	}

	dummy_allocation_001_01[ac] = '\0';

	if (debug_flag_array_counter) printf("char* copyof ( char* str ) ends.\r\n");
	return dummy_allocation_001_01;
}

char* copyof_001 ( char* str ) {
	if (debug_flag_array_counter) printf("char* copyof_001 ( char* str ) starts.\r\n");
	int ac = array_count(str);
	if (debug_flag_array_counter) printf("array_count %d\r\n", ac );
	dummy_allocation_001 = char_string ( ac + 1 );
	a_sleep_thread ();
	if ( dummy_allocation_001 == NULL ) {
		if (debug_flag_array_counter) printf("dummy_allocation_001 is null.\r\n");
		exit(-1);
	}
	if (debug_flag_array_counter) printf("dummy_allocation_001 point|%p|\r\n", dummy_allocation_001 );
//	put_memories( dummy_allocation_001 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001[i] = str[i];
	}

	dummy_allocation_001[ac] = '\0';

	if (debug_flag_array_counter) printf("char* copyof_001 ( char* str ) ends.\r\n");
	return dummy_allocation_001;
}

char* copyof_012 ( char* str ) {
	int ac;
	char* dummy_allocation_001_01 = NULL;
	if (debug_flag_array_counter) printf("char* copyof_012 ( char* str ) starts.\r\n");
	ac = array_count(str);
	if (debug_flag_array_counter) printf("array_count %d\r\n", ac );
	dummy_allocation_001_01 = char_string_012 ( ac + 1 );
	a_sleep_thread_002 ();
	if ( dummy_allocation_001_01 == NULL ) {
		if (debug_flag_array_counter) printf("dummy_allocation_001_01 is null.\r\n");
		exit(-1);
	}
	if (debug_flag_array_counter) printf("dummy_allocation_001_01 point|%p|\r\n", dummy_allocation_001_01 );
	put_memories( dummy_allocation_001_01 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001_01[i] = str[i];
	}

	dummy_allocation_001_01[ac] = '\0';
	if (debug_flag_array_counter) printf("str |%p| dummy_allocation_001_01 |%p|=|%s|\r\n", str, dummy_allocation_001_01, dummy_allocation_001_01 );
	if (debug_flag_array_counter) printf("char* copyof_012 ( char* str ) ends.\r\n");
	return dummy_allocation_001_01;
}

char* copyof_010 ( char* str ) {
	int ac;
	char* dummy_allocation_001_01 = NULL;
	if (debug_flag_array_counter) printf("char* copyof_010 ( char* str ) starts.\r\n");
	ac = array_count(str);
	if (debug_flag_array_counter) printf("array_count %d\r\n", ac );
	dummy_allocation_001_01 = char_string_010 ( ac + 1 );
	a_sleep_thread_002 ();
	if ( dummy_allocation_001_01 == NULL ) {
		if (debug_flag_array_counter) printf("dummy_allocation_001_01 is null.\r\n");
		exit(-1);
	}
	if (debug_flag_array_counter) printf("dummy_allocation_001_01 point|%p|\r\n", dummy_allocation_001_01 );
//	put_memories( dummy_allocation_001_01 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001_01[i] = str[i];
	}

	dummy_allocation_001_01[ac] = '\0';
	if (debug_flag_array_counter) printf("str |%p| dummy_allocation_001_01 |%p|=|%s|\r\n", str, dummy_allocation_001_01, dummy_allocation_001_01 );
	if (debug_flag_array_counter) printf("char* copyof_010 ( char* str ) ends.\r\n");
	return dummy_allocation_001_01;
}

char* copyof_002 ( char* str ) {
	if (debug_flag_array_counter) printf("char* copyof_002 ( char* str ) starts.\r\n");
	int ac = array_count(str);
	if (debug_flag_array_counter) printf("array_count %d\r\n", ac );
	dummy_allocation_001 = char_string_002 ( ac + 1 );
	a_sleep_thread_002 ();
	if ( dummy_allocation_001 == NULL ) {
		if (debug_flag_array_counter) printf("dummy_allocation_001 is null.\r\n");
		exit(-1);
	}
	if (debug_flag_array_counter) printf("dummy_allocation_001 point|%p|\r\n", dummy_allocation_001 );
//	put_memories( dummy_allocation_001 );

	for ( int i=0; i<ac; i++) {
		dummy_allocation_001[i] = str[i];
	}

	dummy_allocation_001[ac] = '\0';
	if (debug_flag_array_counter) printf("str |%p| dummy_allocation_001 |%p|\r\n", str, dummy_allocation_001 );
	if (debug_flag_array_counter) printf("char* copyof_002 ( char* str ) ends.\r\n");
	return dummy_allocation_001;
}



//
//
//
//
//
char* m_trim( char* c_str ) {

	char* result = "\0";
	char* return_result = "\0";

	if (debug_flag_array_counter) printf("m_trim: notrim |%s| starts.\r\n", c_str);

	result = front_trim ( c_str );
	if (debug_flag_array_counter) printf("front_trim |%s|\r\n", result);
	return_result = back_trim ( result );
	if (debug_flag_array_counter) printf("back_trim |%s|\r\n", return_result);

	aFree( result );

	if (debug_flag_array_counter) printf("m_trim ends.\r\ns");
	return return_result;
}


//
//
//
//
//
char* back_trim( char* c_str ) {

	int skip = 0;
	int count = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	if (debug_flag_array_counter) printf("back_trim starts.\r\n");

	for ( int i=length -1; i >= 0; i-- ) {
		c = c_str[i];
		if (debug_flag_array_counter) printf("c |%c|%d| / |%s|\r\n", c, c, c_str);
		switch ( c ) {
		case ' ':
			count++;
			break;
		default:
			if (debug_flag_array_counter) printf("count %d in back_trim.\r\n", count);
			char* returnable = m_substring ( c_str, 0, length - count);
			if (debug_flag_array_counter) printf("back_trim |%s|\r\n", returnable);
			return returnable;
		}
	}

	if (debug_flag_array_counter) printf("back_trim ends.|%s|\r\n", result);
	return result;
}

//
//
//
//
//
char* front_trim( char* c_str ) {

	int skip = 0;
	int count = 0;
	int f_continue = 0;
	char* result = "\0";
	char c;
	char dummy[] = { '\0', '\0' };
	int length = array_count( c_str );

	int a = level_error_msg;
	level_error_msg = 6;

	for ( int i=0; i< length; i++) {
		c = c_str[i];
		switch ( c ) {
		case ' ':
			count++;
			break;
		default:
			if (debug_flag_array_counter) printf("count %d in front_trim.\r\n", count);
			return m_substring( c_str, count, length - count );
			break;
		}
	}

	level_error_msg = a;

	return result;
}

//
//
//
//
//
int m_contains ( char* c_str, char* c_ref ) {

	int unmatch = 0;
	int ref_length = array_count( c_ref );

	int a = level_error_msg;
	level_error_msg = 6;

	int length = array_count( c_str );
	for ( int i=length -1; i >= 0; i-- ) {
		if ( c_str[i] == c_ref[ ref_length -1 ])
			for ( int j=ref_length -1; j >= 0 && i >= 0; j-- ) {
				// sif (debug_flag_array_counter) printf("m_contains:|%d|%d|\r\n", c_str[i] , c_ref[j] );
				if (debug_flag_array_counter) printf("m_contains:|%d|%d|%c|%c\r\n", c_str[i] , c_ref[j], c_str[i] , c_ref[j] );
				if ( c_str[i] != c_ref[ j ] ) {
					unmatch = 1;
					break;
				}
				if ( j == 0 ) unmatch = 2;
				i--;
			}

		if ( unmatch == 2 ) return 1;
		else unmatch = 0;
	}

	level_error_msg = a;

	return 0;
}

