#ifndef _FILEWRITER_001_
#define _FILEWRITER_001_
//...
extern int filewriter_001 ();
extern int set_filewriter_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_001 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
