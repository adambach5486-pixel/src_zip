#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vPoint.h"
#include "vJoint.h"


int vJoint::set_pos ( float x, float y, float z ) {
	return 0;
}

