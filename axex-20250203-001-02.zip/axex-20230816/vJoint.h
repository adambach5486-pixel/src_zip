#ifndef _V_JOINT_H_
#define _V_JOINT_H_

class vJoint {
	public:

	private:
		vPoint** pos = nullptr;
		int pos_max = 16;
		int pos_index = 0;

	public:
		int set_pos ( float x, float y, float z );

	private:

};

#endif
