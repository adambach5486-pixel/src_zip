#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include "vPoint.h"
#include "vLine.h"

#include "vCalculation.h"


int dummy_vPoint_max = 0;
int dummy_vPoint_index = 0;
vPoint** dummy_vPoint = nullptr;

void put_memories( vPoint* dummy_vPoint );

float vCalculation::dot ( vPoint p1, vPoint p2) {
	float dot;

	this->dot( p1.x,p1.y,p1.z, p2.x,p2.y,p2.z, &dot );

	return dot;
}

//
//
//
//
//
void vCalculation::dot ( float x1, float y1, float z1, float x2, float y2, float z2, float* dot ) {

	*dot = x1*x2 + y1*y2 + z1*z2;
}

//
//
//
//
//
vPoint* vCalculation::add ( vPoint* p1, vPoint* p2) {
	vPoint* p3 = new vPoint();
	add( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
	put_memories( p3 );

	return p3;
}

//
//
//
//
//
void vCalculation::add ( vPoint* p1, vPoint* p2, vPoint* p3) {
	add( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
}


//
//
//
//
//
void vCalculation::cross ( vPoint* p1, vPoint* p2, vPoint* p3) {
	cross( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &(p3->x), &(p3->y), &(p3->z) );
}

//
//
//
//
//
vPoint vCalculation::cross ( vPoint p1, vPoint p2) {

	vPoint p3;

	cross( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3.x), &(p3.y), &(p3.z) );

	return p3;
}

// 0, 0, 1  x  1, 0, 0 = 0, -1, 0     -> -z1*x2
// 1, 0, 0  x  0, 0, 1 = 0,  1, 0     ->  x1*z2

// 0, 1, 0  x  1, 0, 0 = 0, 0,  1
// 1, 0, 0  x  0, 1, 0 = 0, 0, -1
//
void vCalculation::cross ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = z1*y2 - y1*z2;
	*y3 = x1*z2 - z1*x2;
	*z3 = y1*x2 - x1*y2;

}

//
//
//
//
vPoint* vCalculation::subtract ( vPoint* p1, vPoint* p2) {

	vPoint* result = nullptr;
	result = new vPoint ();
	subtract( p1->x, p1->y, p1->z, p2->x, p2->y, p2->z, &result->x, &result->y, &result->z );

	put_memories ( (vPoint*)result );

	return result;
}

//
//
//
//
void put_memories ( vPoint* result ) {

	if ( dummy_vPoint_index == 0 ) {
		dummy_vPoint_max = 8;
		dummy_vPoint = (vPoint**) malloc ( sizeof(vPoint*) * dummy_vPoint_max );
	}

	dummy_vPoint_index++;
	if ( dummy_vPoint_index >= dummy_vPoint_max -1 ) {
		dummy_vPoint_max = dummy_vPoint_max * 2;
		dummy_vPoint = (vPoint**) realloc ( dummy_vPoint, sizeof(vPoint*) * dummy_vPoint_max );
	}

	dummy_vPoint[ dummy_vPoint_index ] = result;

}

//
//
//
//
vPoint vCalculation::subtract ( vPoint p1, vPoint p2) {

	vPoint result;
	subtract( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &result.x, &result.y, &result.z );

	return result;
}

//
//
//
//
void vCalculation::subtract ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = x1 - x2;
	*y3 = y1 - y2;
	*z3 = z1 - z2;

}

//
//
//
//
//
void vCalculation::add ( vPoint p1, vPoint p2, vPoint* p3 ) {

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &(p3->x), &(p3->y), &(p3->z) );
}

//
//
//
//
//
vPoint vCalculation::add ( vPoint p1, vPoint p2) {

	vPoint result;

	add( p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, &result.x, &result.y, &result.z );

	return result;
}

//
//
//
//
//
void vCalculation::add ( float x1, float y1, float z1, float x2, float y2, float z2, float* x3, float* y3, float* z3) {

	*x3 = x2 + x1;
	*y3 = y2 + y1;
	*z3 = z2 + z1;

}

//
//
//
//
//
vPoint* vCalculation::scale ( vPoint* p1, float w_scale ) {

	vPoint* result = nullptr;
	result = new vPoint();

	scale ( p1->x, p1->y, p1->z, w_scale, &(result->x), &(result->y), &(result->z) );

	return result;
}


//
//
//
//
//
vPoint vCalculation::scale ( vPoint p1, float w_scale ) {

	vPoint result;

	scale ( p1.x, p1.y, p1.z, w_scale, &result.x, &result.y, &result.z );

	return result;
}

//
//
//
//
void vCalculation::scale ( float x1, float y1, float z1, float scale, float* x3, float* y3, float* z3) {

	*x3 = scale * x1;
	*y3 = scale * y1;
	*z3 = scale * z1;

}

//
//
//
//
vPoint vCalculation::normal ( vPoint p1 ) {

	vPoint p2;
	double scale;

	scale = normal( p1.x, p1.y, p1.z, &p2.x, &p2.y, &p2.z );

	return p2;
}

//
//
//
//
double vCalculation::normal ( float x1, float y1, float z1, float* x2, float* y2, float* z2 ) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	double x3 = (( double ) x1) / scale;
	double y3 = (( double ) y1) / scale;
	double z3 = (( double ) z1) / scale;

	*x2 = x3;
	*y2 = y3;
	*z2 = z3;

	return scale;
}

//
//
//
//
double vCalculation::length ( vPoint lp ) {

	return length ( lp.x, lp.y, lp.z );
}

//
//
//
//
double vCalculation::length ( vPoint* lp ) {

	return length ( lp->x, lp->y, lp->z );
}

//
//
//
//
double vCalculation::length ( float x1, float y1, float z1) {

	double scale = x1*x1 + y1*y1 + z1*z1;
	scale = sqrt( scale );

	return scale;
}

//
//
//
//
//
vLine* vCalculation::put_line( vLine* be_set, vLine* l1 ) {
	be_set = l1;
	// the below error 
	// l1->p1->print();
	// the below error 
	// be_set->p1->print();
}

//
//
// copy all points and would liket to refer to points at 20190213
//
// vLine* vCalculation::Lines_from_Mesh ( vPoint* points, int** numbering) {
vLine** vCalculation::Lines_from_Mesh ( vPoint* points, int** numbering, int num_patches, int base_num_patches) {
	vLine** p_result = nullptr;
	vLine** result = nullptr;
	//20180214
	// int c = sizeof( numbering ) / sizeof( int** );
	int c = num_patches;
	int d_number = 0;
	vPoint* end_to_start;

	// int num_patches = 0;
	// int base_num_patches = 0;
	// int num_patch_lines = 0;

	printf("num_patches %d base_num_patches %d\r\n", num_patches, base_num_patches);

	for( int i=0; i<c; i++ ) {
		int* num_p = *( numbering + i );
		//20180214
//		int d = sizeof( num_p ) / sizeof( int* );
		int d = base_num_patches;

		p_result = ( vLine** ) malloc ( sizeof(vLine**) * d );
		d_number += d;
		result = ( vLine** ) realloc ( result, sizeof( vLine** ) * d_number );

		for( int j=0; j<d; j++ ) {
			int number = *( num_p + j );
			vLine* p_line = *( p_result + j );
			put_point( p_line->p1, points + number );

			if ( j == 0 ) {
				end_to_start = points + number;
			} else {
				put_point( p_line->p2, points + number - 1 );
			}
		}

		int e = 0;
		vLine* last = *( p_result + d - 1 );
		put_point( last->p2, end_to_start );

		for( int j= d_number - d; j<d_number; j++ ) {
			put_line( *(result + j), *(p_result + j - d_number + d) );
		}
	}

	Print_Lines ( result, d_number );

	printf("end of Lines_from_Mesh d_number %d\r\n", d_number);
//	exit(-1);

	return result;
}

vLine* vCalculation::Print_Lines ( vLine** array, int num ) {

	for ( int i=0; i<num; i++ ) {
		vLine* line = *( array + i );
		line->print();
	}

}

//
//
//
//
//
void vCalculation::put_point( vPoint* lp1, vPoint* points_number ) {
	printf( "start of put_point\r\n" );
	points_number->print();
	lp1 = points_number;
	lp1->print();
	printf( "end of put_point\r\n" );
	// exit(-1);
}

