

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "something_word.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vTriangle.h"
#include "vBox.h"

#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "vReturnableParam.h"

#include "wEvent.h"
#include "wButton.h"
#include "wButtonController.h"
#include "wCanvasController.h"

#include "vDisplayController_003.h"



int vDisplayController_003::SetCanvas ( wCanvasController *l_canvas ) {
	this->canvas = l_canvas;
}

int vDisplayController_003::DisplayBones_002 () {
	vPoint w1, w2, w3, zero;
	float x, y, v_dot, len;
	float rand_b[3];
	vPoint* eye = nullptr;

	printf("vDisplayController_003:: DisplayBones_002 () starts.\r\n");

	eye = new vPoint();
	eye->setPoint( 1000.0f, 1000.0f, -1000.0f);
	vPoint* U= new vPoint ( 160.0f, 0.0f, 0.0f );
	vPoint* V= new vPoint ( 0, 90.0f, 0 );
	screen_006.put_U ( *U );
	screen_006.put_V ( *V );

	vPoint* up = memorizevPoint( -10.0f, 10.0f, 0.0f );
	screen_006.put_Up ( *up );

	screen_006.setWidth ( 640 );
	screen_006.setHeight ( 480 );
	screen_006.setEye ( *eye );
	screen_006.LookAt ( *(new vPoint( 0.0f, 0.0f, 0.0f )) );

	screen_006.Set_HowFarFromEye ( 320.0f );
	screen_006.printParams();

	printf("screen_006.HowFarFromEye=%f\r\n", screen_006.HowFarFromEye);

	screen_006.calculation_up_UV();

	if ( this->canvas == nullptr ) {
		printf("this->canvas is nullptr.\r\n");
		exit(-1);
	}


	srand(time(NULL));   // Initialization, should only be called once.
	zero.setPoint (  0.0f,  0.0f, 0.0f );
	bones_002[0]->setPoint (  0.0f,  0.0f,    0.0f );
	bones_002[1]->setPoint (  50.0f,  50.0f,   50.0f );
	this->Calc.subtract( bones_002[1], bones_002[0], &w1 );
	for ( int j=2; j<10; j++ ) {
		for ( int i=0; i<3; i++ ) {
			int r = rand();      // Returns a pseudo-random integer between 0 and RAND_MAX.
			float rand_a = ((double)r) / RAND_MAX;
			rand_b[i] = 10.0f + rand_a * 100.0f;
		}

		w2.setPoint ( rand_b[0], rand_b[1], rand_b[2] );
		v_dot = this->Calc.dot ( w1, w2 );
		if ( v_dot < 0.0f ) {
			this->Calc.subtract( zero, w2, &w2 );
		}
		this->Calc.add( bones_002[ j -1 ], w2, &w3 );
		if ( (len = this->Calc.length( w2 )) > 1000.0f || len < 10.0f ) {
			printf("scale len %f is too big.\r\n", len);
			for ( int i=0; i<3; i++ ) {
				printf("rand_b %d %f\r\n", i, rand_b[i]);
			}
			bones_002[j-1]->print();
			bones_002[j]->print();
			w2.print();
			w3.print();
			exit(-1);
		}
		bones_002[ j ]->setPoint( w3.x, w3.y, w3.z );
		w1.setPoint( w2.x, w2.y, w2.z );
	}

	this->canvas->AXEX_2D_002_Index = 0;
	for ( int j=0; j<10; j++ ) {
		printf("code block set loop %d starts.\r\n", j);
		int a = screen_006.get_cooordinate_on_screen ( bones_002[j], &x, &y );
		this->canvas->Set_vAxex_2D( x, y );
//		this->canvas->AXEX_2D_002_Index++;
		printf("code block set loop %d / index %d ends.\r\n", j, this->canvas->AXEX_2D_002_Index);
	}

	for ( int j=0; j<10; j++ ) {
		printf("bones_002 print %d starts.\r\n", j);
		bones_002[j]->print();
		printf("bones_002 print %d ends.\r\n", j);
	}

	bones_max_index = 10;
	printf("bone_max_index=%d\r\n", bones_max_index);

	printf("convert on the screen num %d\r\n", this->canvas->AXEX_2D_002_Index );
	printf("vDisplayController_003:: DisplayBones_002 () ends.\r\n");
//	exit(-1);
	return 0;
}

int vDisplayController_003::PrintBones ( ) {
	float x, y;
	vCalculation calc;
	printf("int vDisplayController_003::PrintBones () starts.\r\n");

	printf("bones_002 bones_max_index %d: \r\n", this->bones_max_index );
	for ( int i =0; i<this->bones_max_index; i++ ) {
		this->bones_002[i]->print();
	}

	printf("int vDisplayController_003::PrintBones () ends.\r\n");
	exit(-1);
	return 0;
}

int vDisplayController_003::PrintBones ( vPoint** p_bones, int num ) {
	printf("int vDisplayController_003::PrintBones ( vPoint** p_bones, int num ) starts.\r\n");
	bones_002 = (vPoint**)p_bones;
	bones_max_index = num;
	printf("int vDisplayController_003::PrintBones ( vPoint** p_bones, int num ) ends.\r\n");
	return 0;
}

