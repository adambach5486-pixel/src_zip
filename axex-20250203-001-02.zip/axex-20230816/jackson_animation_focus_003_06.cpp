// ---
// ---
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>

#include <windows.h>
#include "Print.h"
#include "array_counter.h"
#include "parse.h"
#include "aToken.h"
#include "memories.h"

#include "vVectorCG.h"

#include "wEvent.h"
#include "cg_schema.h"

#include "log_001.h"

#include "image_layer_001.h"
#include "settle_grid_001.h"

#include "vVectorCG.h"
#include "vModelBufferController.h"

#include "vDisplayController.h"
#include "vDisplayController_001.h"
#include "vModelBufferController.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"
#include "jackson_animation_focus_003_02.h"
#include "jackson_animation_focus_003_03.h"
#include "jackson_animation_focus_003_04.h"
#include "jackson_animation_focus_003_05.h"



// --- Object1 of Header Start --- 

// 20260116
int Stack_Object1_Focus (ANIMATION_FOCUS* r) ;
int Pop_Object1_Focus (ANIMATION_FOCUS* r) ;
int Initialize_Object1_Focus () ;
int Reinitialize_Object1_Focus () ;

// 20260116
int Print_Object1_Focus () ;


// 20260116
int Set_Object1_Data1_Container ( int x, int y, int w, int h );
int Devide_Object1_Data1_Container ( int devide );

// --- Object1 of Header End --- 


// --- Object1 of Code Start --- 

// 20260116
int Devide_Object1_Data1_Container ( int devide ) {
	int mod_w, mod_h, width, height;
	int i;

	width = p_jackson->data1_container.width/ devide;
	height = p_jackson->data1_container.height/ devide;

	mod_w = p_jackson->data1_container.width - width * devide;
	mod_h = p_jackson->data1_container.height - height * devide;

	return 0;
}

// 20260116
int Set_Object1_Data1_Container ( int x, int y, int w, int h ) {
	p_jackson->data1_container.start_x = x;
	p_jackson->data1_container.start_y= y;
	p_jackson->data1_container.width = w;
	p_jackson->data1_container.height = h;

	return 0;
}

// 20260116
int Stack_Object1_Focus (ANIMATION_FOCUS* r) {
	int a;

	p_jackson->flexible_button[p_jackson->button_index] = r;
	p_jackson->button_index++;

	a = Reinitialize_Object1_Focus ();
	return 0;
}

// 20260116
int Pop_Object1_Focus (ANIMATION_FOCUS* r) {
	r = p_jackson->flexible_button[p_jackson->button_index];
	p_jackson->button_index--;
	return 0;
}

// 20260116
int Initialize_Object1_Focus () {
	p_jackson->button_index = 0;
	p_jackson->button_max = 8;
	p_jackson->flexible_button = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->button_max );
	if ( p_jackson->flexible_button == NULL ) return -1;
	return 0;
}

// 20260116
int Reinitialize_Object1_Focus () {
	ANIMATION_FOCUS** temp;
	int i, a;

	if ( p_jackson->button_index >= p_jackson->button_max ) {
		temp = (ANIMATION_FOCUS**) p_jackson->flexible_button;
		p_jackson->button_max *= 2;
		p_jackson->flexible_button = (ANIMATION_FOCUS**) malloc ( sizeof(ANIMATION_FOCUS*) * p_jackson->button_max );
		if (p_jackson->flexible_button == NULL ) {
			return -1;
		}
	}

	for ( i = 0; i<p_jackson->button_index; i++) {
		p_jackson->flexible_button[i] = (ANIMATION_FOCUS*) temp[i];
	}

	free(temp);

	a = Print_Object1_Focus ();
	return 0;
}

// p_jackson->button_max
// p_jackson->button_index
// button
int Print_Object1_Focus () {
	int i;
	FILE *fp;

	fp = fopen ("004-Object1-Allocation-001\.txt", "wb");

	if ( p_jackson->flexible_button == NULL ) {
		fprintf(fp, "p_jackson->flexible_button is NULL.\r\n");
		fclose(fp);
		return -1;
	}

	fprintf(fp, "index %d max %d\r\n", p_jackson->button_index, p_jackson->button_max );
	for ( i = 0; i < p_jackson->button_max ; i++ ) {
		if ( p_jackson->flexible_button[i] != NULL ) {
			fprintf( fp, "|%s|(%d,%d,%d,%d)\r\n", p_jackson->flexible_button[i]->str_name, p_jackson->flexible_button[i]->start_x, p_jackson->flexible_button[i]->start_y, p_jackson->flexible_button[i]->width, p_jackson->flexible_button[i]->height );
		}
		else {
			fprintf( fp, "|%s|(%d,%d,%d,%d)\r\n", p_jackson->flexible_button[i]->str_name, p_jackson->flexible_button[i]->start_x, p_jackson->flexible_button[i]->start_y, p_jackson->flexible_button[i]->width, p_jackson->flexible_button[i]->height );
		}
	}

	fclose(fp);
	return 0;
}

// --- Object1 of Code Start --- 

