#ifndef _PRINT_PARAM_001_H_
#define _PRINT_PARAM_001_H_

#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <stdlib.h>

extern int initialize_print_param_001 ();
extern int set_no_print_socket_msg_001 () ;

#endif

