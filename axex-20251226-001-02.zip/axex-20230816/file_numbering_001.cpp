#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <stdio.h>
#include <stdlib.h>

#include "array_counter.h"
#include "list_directory.h"
#include "parse.h"
#include "numbering.h"

#include "file_numbering.h"



int find_numbering_012 (char* filename, int debug_num);

int print_param_012 (char* filename, int debug_num) {

	printf("int print_param (char* filename, int debug_num) starts.\r\n");

	printf("int print_param (char* filename, int debug_num) ends.\r\n");
	return 0;
}

int find_numbering_012 (char* filename, int debug_num)
{
	FileControler *fc = nullptr;
	char key_code[1];
	int number;
	int success;
	static char* print_word = NULL;

	printf("int find_numbering_012 (char* filename, int debug_num) starts.\r\n");

	printf("001: filename: %s debug_num %d\r\n", filename, debug_num);

	printf("int find_numbering_012 (char* filename, int debug_num) ends.\r\n");
	return 0;
}

//	char** file_info = (char**) malloc ( sizeof(char*) * 3 );
//	int success = this->get_file_info ( lpcstr_path, file_info );
// lpcstr_path
// int FileControler::get_file_info ( char *lpcstr_path, char **result ) 

