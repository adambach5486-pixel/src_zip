// https://github.com/WaitrudWeber/source_zip/blob/master/winmain-20190109.zip
// https://docs.microsoft.com/en-us/windows/desktop/dataxchg/using-the-clipboard

//------------------------------------------------------------------------------
// Proposal 001
//------------------------------------------------------------------------------
#include <tchar.h>
#include <windows.h>
#include <windowsx.h>
//  #include <cstring>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

//#include <realloc_001.h>
//#include <malloc_001.h>


// x #include <atlstr.h>

// x #include <strsafe.h>
// x #pragma comment(lib, "User32.lib")

// https://stackoverflow.com/questions/10970617/there-is-no-strsafe-hProcess-in-mingw-what-to-use-instead
// #include <strsafe.h>

//#include <mmdeviceapi.h>

#include "resource.h"

#include "array_counter.h"
#include "parse.h"
#include "numbering.h"
#include "memories.h"

#include "clipboard.h"

#include "button.h"

// For display of 3D,
#include "vPoint.h"
#include "vLine.h"
#include "vCircle_2D.h"
#include "vTriangle.h"
#include "vCalculation.h"

#include "vAxex_2D.h"

#include "vIntersection.h"
#include "vScreen.h"
#include "vScreenCG.h"

#include "display_threeD.h"
#include "vPointStructure.h"

#include "vSoundBuffer_001.h"
#include "vReturnableParam.h"

#include "vModelBufferController.h"


#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "image_layer_001.h"

#include "wEvent.h"
#include "wEventListener.h"
#include "wJavaStructure.h"

#include "wButton.h"
#include "wButtonController.h"
#include "wController.h"

#include "wTextarea.h"
#include "wTextareaController.h"

#include "something_word.h"
#include "thread_print.h"


#include "wDisplayController.h"
//#include "wParamSynse_003.h"
#include "wCanvasController.h"

#include "cg_schema.h"

#include "vDisplayController.h"
#include "vDisplayController_002.h"
#include "vDisplayController_001.h"

#include "log_001.h"

#include "csv_text_001.h"
#include "settle_grid_001.h"

#include "read_csv_002.h"
#include "read_csv_004.h"
#include "read_csv_005.h"

#include "read_csv_000a_014.h"
#include "read_csv_000a_013.h"

#include "control_image_layer_010.h"
#include "control_image_layer_009.h"

#include "function_name.h"

#include "jackson_animation_focus_003.h"
#include "jackson_animation_focus_003_01.h"
#include "jackson_animation_focus_003_02.h"

#include "jackson_animation_focus_003_ut.h"


#include "wJackson_animation_focus_003c_01.h"
#include "wJackson_animation_focus_003.h"

#include "winmainthread_005a_009.h"
#include "winmainthread_005a_004.h"
#include "winmainthread_005a_003.h"
#include "winmainthread_005a_002.h"
#include "winmainthread_005a_001.h"
#include "winmainthread_005a_000.h"
#include "winmainthread_005a_007.h"
#include "winmainthread_005a_008.h"
#include "winmainthread_005a_005.h"
#include "winmainthread_005a_006.h"

#include "winmainthread_001.h"
#include "winmainthread_002.h"
#include "winmainthread_005.h"


int model_vModelBufferController ();


