#ifndef _FILEWRITER_004_
#define _FILEWRITER_004_
//...
extern int filewriter_004 ();
extern int set_filewriter_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_004 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
