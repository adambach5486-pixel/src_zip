#include "vPoint.h"
#include "vPointStructure.h"

vPointStructure::vPointStructure () {
}

void vPointStructure::Set_Anchor( vPoint* anchor) {
	this->Anchor = anchor;
}

//
// 0<= t <= 1
//
vPoint vPointStructure::additional_position( vPoint c1, vPoint c2, float t ) {
}

