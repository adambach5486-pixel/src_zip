#ifndef THREAD_PRINT_H
#define THREAD_PRINT_H

// #ifndef SERVER_H
// #define SERVER_H

extern int thread_dispose;
extern int multithread_print () ;
extern char* threadprint_buffer( char* buffer);
#endif
