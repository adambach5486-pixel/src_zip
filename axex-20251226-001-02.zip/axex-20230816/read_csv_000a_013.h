#ifndef _READ_CSV__013_
#define _READ_CSV__013_

typedef struct {
	FILE *fp;
	FILE *file_start;
	int index;
	int file_end_index;
} STRUCT_FILE;

//...
extern int read_csv_000a_013 ();
extern int set_read_csv_000a_013 (char** argv, int argc);
extern int initialize_read_csv_000a_013 (char** argv, int argc);
extern int caribration_memoreies_013 ();

extern int memories_width_013 ( int from_w_i, int width, int height, char*** mem ) ;
extern int memories_height_013 ( int width, int height, char*** mem ) ;
extern char**	realloc_char_002_01_013 ( char** restr, int num ) ;
extern char***	realloc_char_003_01_013 ( char*** restr, int num ) ;

extern int set_realloc_char_delay (int lsec) ;


#endif
