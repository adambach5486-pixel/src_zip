#ifndef _JACSON_ANIMATION_FOCUS_003_01_H_
#define _JACSON_ANIMATION_FOCUS_003_01_H_

// 20250317
extern int Initialize_Refresh_Focus_Focus_Rects_01 ();
extern int Reinitialize_Refresh_Focus_Focus_Rects_01 ();
extern int Stack_Focus_Rect_01 (ANIMATION_FOCUS* r) ;
extern ANIMATION_FOCUS* Pop_Focus_Rect_01 ();
extern int Print_Refresh_Focus_Focus_Rects_01 ();

// 20250407
extern int Initialize_Refresh_Several_Focus ();
extern int Reinitialize_Refresh_Several_Focus ();
extern int Stack_Oneof_Several_Focus (ANIMATION_FOCUS* r) ;
extern ANIMATION_FOCUS* Pop_Oneof_Several_Focus ();
extern int Print_Refresh_Several_Focus ();

// 20250425
extern int Stack_Oneof_Several_Focus_Large (ANIMATION_FOCUS* r, int c,int cy, int multi) ;



extern int Set_Debug_Sleep_003_01 (int value ) ;

// 20250905
extern int Caribration_Draw_Focus () ;

extern int Debug_File_Zero_For_Stack ();

#endif
