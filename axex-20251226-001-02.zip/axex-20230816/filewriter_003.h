#ifndef _FILEWRITER_003_
#define _FILEWRITER_003_
//...
extern int filewriter_003 ();
extern int set_filewriter_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
extern int initialize_filewriter_003 (char* stored_buffer, char* fnc_name, int i, char* buffer_function);
#endif
