#include <tchar.h>
#include <windows.h>
#include <windowsx.h>

#include <ctime>

#include <stdio.h>
#include <stdlib.h>

#include "Print.h"
#include "array_counter.h"
#include "parse.h"

#include "log_001.h"

#include "read_csv_004.h"
#include "read_csv_005.h"

#include "csv_text_002.h"

//
//
int CSVTEXT_002::csv_text_001() {

	return 0;
}

//
int CSVTEXT_002::set_log_001 (Logging* llog) {

	this->logging = (Logging*)llog;

	return 1;
}

//
// param[0] b mode 0. first
//
int CSVTEXT_002::csv_text_once_006( int* index, int* file_end, char** param, int num ) {
	int i;
	int a, b, c, d;
	char dummy[255];
	char** value =NULL;
	int raw, line;

	this->read_file_open () ;

	fseek( this->rfp, *index, SEEK_SET);
	fread ( dummy, 1, 5, this->rfp );
	dummy[1] = 0;

	for (i=0; i<num_litteratures; i++ )
		if ( m_compare( (char*)dummy, litteratures[i] ) == 1 ) {
			a = i;
			break;
		}

	b = atoi(param[0]);
	raw = atoi(param[1]);
	line = atoi(param[2]);

	switch (a) {
	case 1:
		raw++;
		break;
	case 2:
		break;
	case 3:
		break;
	case 4:
		break;
	case 5:
		line++;
		break;
	default:
		break;
	}

	switch (b) {
	case 1:
		break;
	case 2:
		break;
	default:
		break;
	}

	switch (c) {
	case 1:
		break;
	case 2:
		break;
	default:
		break;
	}

	sprintf( param[1], "%d", raw);
	sprintf( param[2], "%d", line);

	this->read_file_close () ;
	return 1;
}

//
int CSVTEXT_002::set_read_file_name (char* rfn) {
	char print_buf[255];
	this->read_file_name = (char*) csvcopyof_005 ( rfn );
	sprintf( print_buf, "csv read file name %s\r\n", this->read_file_name );
	dlog_001 = this->logging->update_log ( this->file_name );

	return 1;
}

int CSVTEXT_002::csv_read ( ) {
	char print_buf[255];
	char dummy[255];
	int i, j;

	this->read_file_open ();

	sprintf( print_buf, "csv index |%d|\r\n", this->csv_index );
	sprintf( print_buf, "csv rfp |%p|\r\n", (FILE*) this->rfp );
	dlog_001 = this->logging->update_log ( print_buf );

	fseek( this->rfp, this->csv_index, SEEK_SET);

	sprintf( print_buf, "csv rfp |%p| in seek.\r\n", (FILE*)this->rfp );
	dlog_001 = this->logging->update_log ( print_buf );

	//
	for ( i =0; i<10; i++ ) {
		fread ( dummy, 1, 5, this->rfp );
		sprintf( print_buf, "dummy: |%s|\r\n", dummy );
		dlog_001 = this->logging->update_log ( print_buf );
		for ( j =0; j<5; j++ ) {
			sprintf( print_buf, "dummy[j]=c|%c|\r\n", dummy[j] );
			dlog_001 = this->logging->update_log ( print_buf );
		}
		this->csv_index += 5;
	}

	sprintf( print_buf, "this->csv_index=|%d|\r\n", this->csv_index );
	dlog_001 = this->logging->update_log ( print_buf );

	sprintf( print_buf, "csv rfp |%p| in read.\r\n", (FILE*)this->rfp );
	dlog_001 = this->logging->update_log ( print_buf );

	this->read_file_close ();

	return 1;
}

//
int CSVTEXT_002::csv_save ( char* filename, char** param_d, int num_width, int num_height ) {
	char print_buf[255];
	int i, j;

	dlog_001 = this->logging->update_log ( filename );

	this->file_name = (char*) csvcopyof_005 ( (char*) filename );
	dlog_001 = this->logging->update_log ( this->file_name );

	sprintf( print_buf, "csv memories adress %p\r\n", (char**)param_d );
	dlog_001 = this->logging->update_log ( print_buf );

	sprintf( print_buf, "csv num width %d\r\n", num_width );
	dlog_001 = this->logging->update_log ( print_buf );

	this->write_file_open ();

	for ( j=0; j<num_height; j++ ) {
		for ( i=0; i<num_width; i++ ) {
			fprintf( this->wfp, "\"" );
			fprintf( this->wfp, param_d[i + num_width * j ] );
			fprintf( this->wfp, "\"," );
		}
		fprintf( this->wfp, "\r\n" );
	}

	this->write_file_close ();

	return 1;
}

// write and read (  )
//
int CSVTEXT_002::write_file_close () {
	char print_buf[255];

	fclose(this->wfp);
	this->wfp = NULL;

	sprintf( print_buf, "fclose fopen w %p\r\n", this->wfp );
	dlog_001 = this->logging->update_log ( print_buf );

	return 1;
}

int CSVTEXT_002::write_file_open () {
	char print_buf[255];

	this->wfp = (FILE*) fopen( this->read_file_name, "wb");

	sprintf( print_buf, "fopen w %p\r\n", this->wfp );
	dlog_001 = this->logging->update_log ( print_buf );

	return 1;
}

// read_filename and write_file_name ( )
//
int CSVTEXT_002::read_file_open () {
	char print_buf[255];

	this->rfp = (FILE*) fopen( this->read_file_name, "rb");

	sprintf( print_buf, "fopen r %p\r\n", this->rfp );
	dlog_001 = this->logging->update_log ( print_buf );

	return 1;
}

//
int CSVTEXT_002::read_file_close () {
	char print_buf[255];

	fclose(this->rfp);
	this->rfp = NULL;

	sprintf( print_buf, "fclose fopen r %p\r\n", this->rfp );
	dlog_001 = this->logging->update_log ( print_buf );

	return 1;
}

//
int CSVTEXT_002::csv_text_once_001( FILE *fp, int index, int file_end, char** param, int num ) {
	int num_001;
	char* l_dummy;

	num_001 = array_count ( param[0] ) ;
	l_dummy = char_string(num_001);
	fseek( fp, index, SEEK_SET);
	for ( int i= index; i<file_end; i++) {
		fread ( l_dummy, 1, num_001, fp );
		if ( m_compare( param[0], l_dummy ) == 1 ) {
			printf("index %d i %d / file_end %d %s\r\n", index, i, file_end, l_dummy);
			exit(-1);
		}
	}

	return 1;
}

//
int CSVTEXT_002::csv_text_once_002( FILE *fp, int index, int file_end, char** param, int num ) {

	return 1;
}

//
int CSVTEXT_002::csv_text_once_003( FILE *fp, int index, int file_end, char** param, int num ) {

	return 1;
}

//
int CSVTEXT_002::csv_text_once_004( FILE *fp, int index, int file_end, char** param, int num ) {

	return 1;
}

//
int CSVTEXT_002::csv_text_once_005( FILE *fp, int index, int file_end, char** param, int num ) {

	return 1;
}

/*

//
//
//
char* get_string ( STRUCT_FILE structure_fp, int num ) {
	long diff;
	char c;

	printf("char* get_string ( STRUCT_FILE structure_fp, int num ) starts.\r\n");

	diff = (long)structure_fp.fp - (long)structure_fp.file_start;

	// set
	//(long)structure_fp.file_start + (long)structure_fp.index;
	//	fseek(fp,0,SEEK_END);
	//	fseek(fp,0,SEEK_CUR);

	printf("struct_fp.fp |%d| struct_fp.index |%d| num |%d|\r\n", structure_fp.fp , structure_fp.index, num);

	char* l_dummy = char_string(num);
	fseek( structure_fp.fp, structure_fp.index, SEEK_SET);

	fread ( l_dummy, 1, num, structure_fp.fp );

	printf("struct_fp.fp |%d|  : ", structure_fp.fp );

	printf("char* get_string ( STRUCT_FILE structure_fp, int num ) ends.\r\n");

	return l_dummy;
}

//
char* get_string_001 ( STRUCT_FILE structure_fp, int num ) {
	long diff;
	char c;
	char l_dummy[255];

	printf("char* get_string_001 ( STRUCT_FILE structure_fp, int num ) starts.\r\n");

	diff = (long)structure_fp.fp - (long)structure_fp.file_start;

	// set
	//(long)structure_fp.file_start + (long)structure_fp.index;
	//	fseek(fp,0,SEEK_END);
	//	fseek(fp,0,SEEK_CUR);

	printf("struct_fp.fp |%d| struct_fp.index |%d| num |%d|\r\n", structure_fp.fp , structure_fp.index, num);

	fseek( structure_fp.fp, structure_fp.index, SEEK_SET);
	fread ( l_dummy, 1, num, structure_fp.fp );

	printf("struct_fp.fp |%d|\r\n", structure_fp.fp );

	char* return_value = copyof_012(l_dummy);

	return_value[num] ='\0';
	printf("return_value|%p|=|%s| l_dummy|%p|=|%s|\r\n", return_value, return_value, l_dummy, l_dummy );
	printf("char* get_string_001 ( STRUCT_FILE structure_fp, int num ) ends.\r\n");

	return return_value;
}



*/

/*
int Analyzer::filesize( FILE *fp ) {

	fseek(fp, 0L, SEEK_END);
	int sz = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	return sz;
}


*/