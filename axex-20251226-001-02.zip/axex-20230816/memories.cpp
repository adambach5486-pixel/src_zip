#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h> // ADD: 20200125


// 20250104
int debug_param_msg_num = 300;
int debug_print_msg = 1;

int debug_print_msg_sleep_01 = -1;
int wait_sharp_short_time_01 = -1;


// 20241204
int debug_print_msg_param ();

// 20250615
int debug_param = 0;


int set_debug_param_msg_num ( int num);
int wait_sharp_short_time () ;
int set_wait_sharp_short_time (int num);

int debug_print_msg_sleep ();
int set_debug_print_msg_sleep (int sl );

// 20250615
int set_debug_param (int dp );
// 20250615
int print_debug_param () ;


//
int wait_sharp_short_time () {
	int i;
	if ( wait_sharp_short_time_01 == -1 ) return -1;

	for (i=0; i<10; i++ ) {
		printf("#");
		Sleep(66);
	}
	printf("\r\n");
	return 0;
}


int set_wait_sharp_short_time (int num) {
	wait_sharp_short_time_01 = num;
	return 0;
}


// 20241204
int debug_print_msg_param () {
	static int debug_param = 0;

	if ( debug_param >= debug_param_msg_num ) {
		debug_print_msg = 0;
		return debug_print_msg;
	}

	if ( debug_param % 200 == 0 ) {
		printf("debug %d/%d\r\n", debug_print_msg, debug_param);
		Sleep(1000);
	}

	debug_param++;

	return debug_print_msg;
}

int set_debug_param_msg_num ( int num) {

	printf("debug_param_msg_num %d -> ", debug_param_msg_num );
	printf("num %d -> ", num );
	debug_param_msg_num = num;
	printf("debug_param_msg_num %d\r\n", debug_param_msg_num );

	debug_print_msg = 1;
	printf("debug_print_msg:%d\r\n", debug_print_msg);
	return 0;
}

int debug_print_msg_sleep () {
	if ( debug_print_msg_sleep_01 < 0 ) return -1;

	return 1;
}

int set_debug_print_msg_sleep (int sl ) {
	debug_print_msg_sleep_01 = sl;
	return 1;
}

// 20250615
int set_debug_param (int dp ) {
	debug_param = dp;
}

// 20250615
int print_debug_param () {

	printf("print_debug_param: %d / %d\r\n", debug_param, debug_param_msg_num );

	return 0;
}

